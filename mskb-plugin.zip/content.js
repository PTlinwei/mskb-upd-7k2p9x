// ============================================================
// 妙手上架助手 V26.11.25.28
// V26.11.25.28: 安装目录固定到 D:\妙手上架助手\plugin（不再放系统盘用户目录），安装与更新前清理目录里非白名单文件，避免 _patch_*.py 这类以下划线开头的残留文件导致 Chrome 拒绝加载；更新助手与更新核心的目录定位同步改到 D 盘。
// V26.11.25.28: ①去掉本机/同网段更新源（本机 8080 更新服务停用），更新只走公网 ghfast → gh-proxy → jsDelivr → raw，异地与本机行为一致；②面板/说明/注释里的「同事」统一改为「用户」。
// V26.11.20.26: 修「异地更新」两处细节——①弹窗里的「手动下载新版 zip」改用服务端下发的直链（默认 ghfast 公网地址），不再写死 192.168.1.81，外地打不开内网也能手动下载；②本机更新助手与 更新核心.ps1 对同网段源改为 6 秒短超时，异地用户点「立即更新」不用先等 45 秒×2 才落到公网镜像。
// V26.11.20.25: 修复「异地也能更新」——插件包与 version.json 已托管到公开仓库（PTlinwei/mskb-upd-7k2p9x），更新源顺序改为「同网段更新服务(2秒超时) → ghfast → gh-proxy → jsDelivr → raw」，不在同一局域网的用户也能查到新版并点「立即更新（自动完成）」；jsDelivr 排到最后，避免其 @main 缓存读不到当天发布的新版。
// V26.11.20.24: 弹窗里直接更新——「立即更新（自动完成）」由后台调用本机更新助手（127.0.0.1:8790）下载并覆盖插件目录，覆盖成功后后台把扩展重载一次、并把采集箱页面刷新一次，用户不用再打开「更新插件.bat」；助手没装/没跑时弹窗给出明确提示（双击一次「更新插件.bat」装好，以后都可点按钮自动更新）。另提供「手动下载新版 zip」兜底。
// V26.11.20.23: 强制更新改为「直接弹窗」——打开采集箱页面即向更新服务查 version.json，服务端版本更高且 force 时，在页面中央弹出遮罩弹窗（标题「插件必须更新才能继续使用」，显示最新版本/当前版本 + 三步操作：双击「更新插件.bat」→按 Y 重启 Chrome→点「我已更新，重新检查」），弹窗不带关闭按钮、点遮罩也不消失，「开始处理」同时继续锁死；点「我已更新，重新检查」会立即复查并清掉节流，追平即自动关弹窗；另提供「手动下载新版 zip」。每 5 分钟自动复查一次，仍在旧版就再次弹出。面板顶部红条保留作二次提醒。拉不到 version.json 时不弹窗、不锁人。
// V26.11.20.22: 新增「强制更新」——打开采集箱面板即向本机更新服务读 version.json（同网段优先，连不上再走备用CDN），服务端版本高于本机时面板顶部显示红条「已发布新版本 Vx，当前版本已停用」，并直接锁死「开始处理」按钮（点开始也会被拦下并提示先更新）；更新方式仍是双击「更新插件.bat」。拉不到版本信息时不拦人（断网/服务没开不会把人锁死）。后台 background.js 由原来的 requestUpdateCheck（仅策略/商店安装有效）改为直接请求 version.json，解压版同样生效；manifest 增加更新服务域名的 host_permissions。
// V26.11.20.21: 修复「载入子账号」漏人——扫描人员名单不再“连续两页没新面孔就提前停”，改为按接口 total 翻完全部未发布页（上限40页/2000条）；人员名兼容 ownerSubAccountAliasName/subAppAccountAliasName/ownerSubAccountName/subAppAccountName/ownerAliasName；扫描不再只限“已选预发布店铺”，避免部分人的商品没选店铺就整批看不到；载入后打印扫描页数/商品数/识别人数/各人未发布数，统计为0的人单独提示。
// V26.11.20.20: 新增「自动更新提示」(配合 Chrome 企业策略安装)：面板顶部新增更新黄条，打开采集箱页面后自动检查(5分钟节流)，发现新版显示「发现新版本 vX，点立即更新」；点击后由后台 background.js 调 chrome.runtime.requestUpdateCheck 触发 Chrome 后台下载，下载完成(onUpdateAvailable)自动刷新页面；若 Chrome 尚未切换版本，刷新后提示「完全退出 Chrome 再打开」。解压加载版本无 update_url，检查不生效属正常。新增 background.js(service worker)，manifest 增加 background 声明。
// V26.11.20.19: 修复主图兜底把同一张主图做成两个规格(截图 Negro+1/Negro+2 同图)。①根因：SKU全无匹配时兜底取产品主图前2张且只按完整URL去重，同一张图的不同尺寸/参数链接被当成两张→两个同图规格；②兜底改为只取第1张主图，并新增 dedupeMainImgUrls 按图片基名(getImgBase)去重、剔除已有来源图；③判色选池(t-shirt与引流)增加基名去重，SKU图与主图命中同一张只保留1个规格并打[去重]日志；④帆布引流主图也按基名去重。SKU有图且判出多色时行为不变。
// V26.11.20.18: 新增离线授权激活（内部专用，防外传）。面板顶部「授权」区显示本机机器码(持久UUID+平台/时区/语言/核数哈希)，粘贴管理员签发的授权码(MSKB1.载荷.签名)后离线验签(ECDSA P-256，插件只内置公钥)；绑定机器码+有效期，未授权/过期/机器码不符时「开始处理」直接拦截，zip流出去在别的电脑上跑不起来。授权码本地记忆，换版本无需重新激活；到期需重新签发。签发工具只在管理员本地(不入包)。发布店铺/单主图/引流/定制逻辑不变。
// V26.11.20.17: 新增「发布店铺」下拉+「载入店铺」按钮，解决只能按商品默认第一个预发布店铺发布、无法指定店铺的问题。选中某个预发布店铺后：扫描只圈定 collectBoxDetailShopList 里已选该店铺的未发布商品，pubShopId 固定为该店铺，保存/发布全部落到该店铺；未选(自动)保持原逻辑(每个商品用自己第一个预发布店铺)。扫描顺序仍是该店铺下从未发布的第一个商品开始，数量=设定值。选择本地记忆；指定店铺下无商品时日志明确提示。单主图/引流/定制全部兼容。
// V26.11.20.16: 新增「单主图」选项(定制后独立勾选，可与引流/定制同时)。有些员工采集时只采集到主图、商品没有任何细节图，勾选后「主图链接」改为必填：必须自己填入细节图直链(≥1条 http/https)，插入第1张原主图后；未填或全无效时整批不启动，运行中也在保存/发布前兜底拦截，绝不发布无细节图的商品。主图链接在单主图模式下对油画等全部品类生效(原仅服装/帆布袋)；判色/规格槽/标题链路与.14一致，不新增AI。vm断言全绿。
// V26.11.20.14: 修复童装杏色Albaricoque浅杏款被像素误判white成Blanco+1上架。kids专属前置名称过滤(CAT_EXTRA_NO_PRINT_RE.kids)补全杏/米杏词族：albaricoque阴阳单复数、almendra/almendrado杏仁色(补ALMENDRA漏词)、chabacano(墨)、damasco(南美)、melocotón(西)、durazno桃杏色、apricot、nude、crema、marfil、color carne肤色、blanco/color hueso骨白；裸hueso/carne因可能是骨头/肉类印花描述不加裸词。仅合并进getNoPrintRe('kids')，帆布袋bag合法米色(beige/crema/marfil)与其他品类正则不变；0新增AI。vm断言285项。
// V26.11.20.13: 修复童装粉色SKU被误杀+纯色货号款被像素快判当印花上架(常态仍0新增AI，仅像素弱信号才进AI)。①根因：kids前置noPrint正则rosa分支后缀全可选且无词边界，子串命中rosa/rosado/rosada/rosados/rosadas/rosas全部词形，在名称判色前误杀，与童装允许pink白名单矛盾；改为rosa(s)/rosado(a)(s)必须带明确纯色后缀(sólido/a、puro/a、liso/a、sin estampado)才按纯色过滤，裸词与粉色印花名放行；②kids识别表pink补全阴阳单复数rosas/rosados/rosadas(原仅三形)，名称清洗正则同步，识别后统一命名Rosa(多张Rosa+1递增)不再退化成序号；③pixelQuickJudge quick返回前新增胸口中心40%印花密度复核(异类RGB像素占比≥5%且亮度标准差≥26)，否决褶皱/领口/木纹背景造成的centerDiff假印花，货号名纯色款(01/1/11)不再被硬判hasPrint:true，弱信号落AI由选池hasPrint硬条件拦截。vm断言248项。
// V26.11.20.12: 按员工最新订正调整名称层互斥矩阵(仍0 AI调用，判色/.8 skuMap链路不变)。①童装kids移除T恤tshirt与T恤CVC(cvc)排他——童装T恤/CVC即本品，现仅排卫衣两类(hoodie/crew/sweatGeneral/knitOuter)+短裤shorts+套装setwear(长裤裙包帽鞋等补充族与infantil/niño本品豁免保留)；②圆领卫衣crewneck按新清单新增排短裤shorts/bermuda(.11按上轮清单不排短裤，本版翻转)，完整排他=T恤/CVC/套装/短裤/童装/连帽(rival层)；③vm断言215项全绿。
// V26.11.20.11: 按员工9大上架品类互斥清单重做名称层跨品类词库(仍0 AI调用)。①词族拆分 cvc/hoodie/crew/sweatGeneral/knitOuter/tshirt/shorts/pantsLong/skirts/setwear/kids/bagsOther/caps/shoes/underwear/dress/accessories；②模式矩阵 foreignModeProfile：连帽卫衣top_h排T恤/T恤CVC/短裤/套装/童装/圆领卫衣(另补长裤裙配饰)，圆领卫衣crewneck排T恤/CVC/套装/童装/连帽卫衣(按清单【不排短裤】)，短裤排卫衣两类/T/CVC/套装/童装，套装排卫衣两类/T/CVC/短裤/童装，童装排卫衣两类/T/CVC/短裤/套装，CVC补齐卫衣两类/普通T恤词(名称带cvc字样豁免)/短裤/套装/童装/裙/配饰，普通T恤top_t维持.10全量排他，帆布袋沿用(不排包名)，油画不启用；③两层判定：rival对立款式层(top_h的crew↔crewneck的hoodie)不被sudadera共称豁免、但同条含本款式明确词(ownStyle)时放过；跨大类exclude命中时若同条含本品强词own(童装infantil/套装conjunto/CVC字样/卫衣sudadera/短裤shorts等)则豁免，防 camiseta infantil、conjunto camiseta+shorts、playera CVC 交叉命名被误杀；④修复 tshirt 正则无左边界会匹配 sweatshirt 后缀“tshirt”导致T恤本品豁免在卫衣词上反转的bug，补Unicode字母边界与复数；⑤buildForeignChecker每款预编译正则。局限不变：只查采集SKU规格名，OSS返回null(skuList=0)或纯货号/纯颜色名时词库无作用对象。
// V26.11.20.10: 成本优先，回滚.9“品类敏感模式每张过AI复核”(AI调用量/耗时过高)，判色主链路恢复到V26.11.20.8：像素快筛命中即采用、名称直通恢复，不再强制AI品类复核。替代方案=新增名称层「跨品类排他词库」(零AI调用)：按当前模式构造非本品词族，采集SKU规格名命中即nameSkip，面板日志写“非本品类词(命中词)[过滤]”。T恤/CVC(top_t/cvc)排sudadera/hoodie/crewneck/sweatshirt等卫衣及长裤/短裤/裙/套装/童装/包/帽/鞋/内衣/连衣裙/配饰；卫衣top_h排T恤词与裤装等但放行sudadera/hoodie(本品)，纯圆领crewneck模式额外排明确连帽词(hoodie/con capucha)但不排sudadera(圆领连帽共称)；短裤保留shorts/bermuda、排长裤/裙/卫衣；套装保留T恤+短裤与conjunto、排卫衣/长裤；童装保留童装/T恤、排卫衣/裤装；帆布袋保留bolsa、排服装；油画无品类不启用。仅作用于采集SKU规格名，插件输出槽与手选自定义图豁免。局限：规格名为纯货号(如A7328)且图片是卫衣时名称词库拦不到，仍走.8像素/AI原链路。
// V26.11.20.9: 修复T恤模式把同货源混入的卫衣SKU当黑/白T恤上架(实测圆领+连帽卫衣被命名Negro+7/+8)。根因：像素快筛只判颜色/印花却硬编码category=tshirt，选池catOk又被r.quick/r.nameJudge/forceColor直接绕过品类白名单。现：①像素结果不再给品类(category='')；②品类敏感模式(T恤/CVC/卫衣/童装/短裤/套装/帆布袋)像素命中后仍调AI复核品类，AI失败标记categoryUnverified不放行(无品类约束的油画才像素直通)；③catOk仅豁免插件自建槽/用户显式自定义图，其余统一走抽出的categoryAllowed(top仅tshirt，明确排除hoodie/crewneck)；④top模式取消other→tshirt容错，防止卫衣被AI判other后救回；⑤名称直通结果按目标模式构造合规品类；⑥AI prompt强化“长袖厚针织/帽/罗纹收口=卫衣，不因黑底印花判T恤”；过滤日志加“品类不符/AI品类复核失败”原因。
// V26.11.20.8: 修复自动克隆规格后保存报“SKU【Negro+4-S】不存在”——克隆/补出的新颜色槽(isNew)此前只加了 attrValue，skuMap 没有对应「颜色×尺码」SKU 行；现保存前由 ensureClonedSkus 自动学习真实 skuMap key 的维度顺序(兼容 ;尺寸;颜色; 与 ;颜色;尺寸; 及无尺码单维)，深拷贝正常来源 SKU 行为每个新槽×每个尺码补齐缺失行(isDelete=0，已有行不覆盖，样本跳过引流盲盒槽/定制槽)；无任何 SKU 样本可复制时回退剔除克隆槽保原有规格正常保存，不再整款失败；新增 [诊断SKU] 日志输出补行数/key维度/样本key。
// V26.11.20.7: 明确引流自动克隆规格的模板位——纯引流固定克隆第2个规格(index1/序号02，不足2槽先以第1规格补齐)；引流+定制固定克隆第3个规格(index2/首个来源槽，不足3槽先补，跳过盲盒槽与定制槽)。移除旧 colors[2]||colors[1]||colors[0] 回退(规格不足时会误拿定制槽当模板、复制 diseño personalizado/__mskbCustom)，克隆体显式 delete __mskbCustom；普通模式克隆逻辑不变。
// V26.11.20.6: 修复同一商品多个不同印花SKU被批量“跳过(已有图通过)[省AI]”丢失——移除 aiFilterSourceList 的 quickPass 跨图短路(旧逻辑前1-2张像素通过后，其余来源图在判色前直接 aiSkipped、不进选池)；现每张来源图都走 本地像素快筛→(像素不足时)AI精判，合格者全部进 pool，普通/引流/定制分槽按 pool 全量占槽/克隆规格，不再中途丢弃；判定并发仍限2。
// V26.11.20.5: 全品类过滤采集SKU名 joya/joyas(西语珠宝首饰类混入规格)——新增 COMMON_SKU_NAME_BLOCK_RE；服装/帆布袋判色名称层第一道拦截(日志标“无关品类词”)，删多余规格前汇合兜底第二道覆盖油画普通分支与模板漏网槽(插件定制槽豁免)，全品类+普通/引流/定制生效；命中仅删该SKU规格，全命中则整款跳过。
// V26.11.20.4: 帆布袋规格命名调整——白色与米色(beige/crema/marfil/ivory/米白/米黄/杏色等)最终规格值统一命名 Blanco(米色不再写 Beige)；多个白/米来源槽在同组内连续递增 Blanco1/Blanco2…(白+米混排连号，避免规格值重名)，仅1个有效来源槽用裸名 Blanco；判色层仍保留 beige 识别与白/米放行，本次仅改写入的规格显示名。
// V26.11.20.3: ①新增「定制」模式(引流后独立勾选,可与引流同时)——引流锁规格1、定制图锁规格2并命名diseño personalizado；普通+定制=槽1来源/槽2定制/余下来源从槽3顺延，定制固定图不判色、链接与勾选本地记忆；油画忽略定制。②帆布袋允许白+米(beige含西语阴阳单复数)，其它颜色词含阴阳在名称层全过滤；采集SKU名的设计定制词(diseño personalizado/personalizado/custom design等)全过滤，但插件自建第二规格精确豁免(模板回退按名跳过)；同色多张规格名递增 Blanco1/Blanco2、Beige1/Beige2(仅帆布袋，其他品类沿用+1)。③修复允许色下不同色印花被整图平均RGB近似(<5)误去重——改为仅按URL身份(origin+pathname)去重。
// V26.11.20.2: 帆布袋叶子类目cid=904456加入CID_MAP(ptype=bag/gender=unisex)，命中cid直接稳定识别为帆布袋，不再依赖AI看图
// V26.11.20.1: 新增「帆布袋」品类(油画后单选，仅白色，规则参考CVC)——独立ptype=bag与mxbag/mxbag_y模式，名称→像素→AI判色仅留白带印花，支持引流盲盒/主图链接/规格槽克隆，标题走清洗不加油画前缀；AI品类枚举新增bag(帆布袋/手提布袋)，other+印花容错修正bag
// V26.11.7.3: 新增套装掩膜快判——白上衣连通块+黑/灰短裤连通块双重验证，仅数白块内部墨迹判印花，背景排除、单T不误放
// V26.11.7.2: 套装名称含无印花词(blanco sin estampado等)直接过滤；移除白上衣像素快判(彩色背景误判印花)，白款改名称过滤+AI
// V26.11.7.1: 修复白上衣像素快判误放纯色套装——收紧为深色/高饱和墨迹、中心集中、名称无印花守卫，证据不足转AI
// V26.11.6.2: 套装白上衣像素专用快判(采样上半部分白衣占比+印花墨迹，省AI)；日志新增「全部日志/失败汇总」标签，失败汇总只显示发布失败条目
// V26.11.6.1: 白款套装容错——T恤同框有短裤(bottom_color黑白灰/非长裤)修正回套装；AI整体色other时近白像素占比/白上衣分色兜底修正white；版本号统一由PLUGIN_VERSION常量管理
// V26.10.28.3: 套装名称层重构(单T/单裤/彩色直接过滤)；套装AI分上衣/短裤颜色命名；长袖/长裤套装过滤；套装像素判出印花即放行，判不出进AI
// V26.10.28.2: AI判色失败时插件面板直接显示具体原因(HTTP状态/API错误/非JSON/异常)；版本号改为实时日期+字母
// V20261017x: 判色环节加实时进度日志——AI判色中(每张图)、判色结果(每张图留/过滤)
// V20261017w: 引流模式01号位=引流款图；02起SKU图全部进选池判色(含第1个规格)，回退V20261017v
// V20261017v: 引流模式SKU第1个规格完全自定义直接采用，不判色；其余规格正常判色
// V20261017u: 移除占位图名称判断——来源SKU图名称(用户ERP模板自填)直接走正常判色
// V20261017t: 占位图名称(参考图/占位图/solo consultas等)直接过滤不走AI；引流款图本就不走AI
// V20261017s: 修复套装名称"白T+黑短裤"被误判单裤过滤——上衣词识别裸T
// V20261017r: 套装名称判定简化——其它颜色词过滤、单T单裤过滤、黑白灰直接放行、无颜色词走AI
// V20261017q: 套装名称判定补全——彩色套装(其它颜色词)直接过滤，不是颜色词走AI
// V20261017p: 套装名称专用判定——完整套装名(上衣+短裤或含套装词)+允许色直接放行；单T/单裤直接过滤；纯色无标识走AI严谨判断；删除旧版judgeColorByName
// V20261017o: 套装品类收紧——只认合体套装图(set)，单T/单裤(shorts/tshirt)过滤；保留套装多件套豁免
// V20261017n: 童装模式品类容错收紧——只认kids/tshirt(短袖)，长袖款(hoodie/crewneck)过滤
// V20261017m: T恤/CVC模式品类容错收紧——只认tshirt(短袖)，长袖款(hoodie/crewneck)过滤
// V20261017k: 修AI返回整串枚举导致判other失效——解析处归一化+白名单改黑
// V20261017h++++++: 套装模式(other+有印花→自动改黑)之前漏了set条件，补上
// V20261017h+++++: 童装过滤词加 blue/beige/green/brown/purple（blue排除light/baby/sky blue）
// V20261017h++++: 童装过滤词加 lila/purpura（西语紫色）
// V20261017h+++: 童装追加过滤 fuchsia/fucsia/magenta/紫/橙/黄/绿/藏蓝/棕/卡其/深灰等非允许色
// V20261017h++: 日志"01盲盒"改为"01引流款"
// V20261017h+: 修童装品类过滤——AI判tshirt/hoodie/crewneck也算通过
// V20261017h: 修复 judgeColorByName 重复定义导致 CAT_COLOR_NAME is not defined 报错
// V20261017g: 布局改为左列标签固定+右列选项换行（标签不被选项挤到）
// V20261017f: 修复标签竖排问题——标签与选项同行，固定宽度，不再独占一行
// V20261017e: 款式合并——男女童并入男女混合，男女混合移到最后（通用/男款/女款/男童/女童/男女混合）
// V20261017d: 新增「T恤CVC」品类——只收黑色带印花，其他颜色全过滤；
//             纯色过滤词 + 名称颜色定色词改成按品类独立（kids/cvc 单独一套）
// V20261017c: 童装CID_MAP补全——男童cid=802952、女童cid=804232，款式按cid硬过滤
// V20261017b: 新增「童装」品类——款式加男童/女童/男女童；颜色按色板收
//             黑/白/浅蓝/粉/红，其他颜色过滤；普通/引流模式与其他服装通用
// V20261017a: AI判色超时20s→30s，失败自动重试1次（修3460249981主图超时被误判失败）
// V20261017: 补英文 no print / without print / no graphic 过滤词（原漏了，导致"No print Black"被放行）
// V20261016a: 套装名称过滤词库扩充——西语加 color único/color unicolor/
//             camiseta de color/pantalones cortos de color/camiseta sola/shorts solos；
//             中文加 单T恤/单短裤/彩色T恤/彩色短裤/单色；英语加 solo t-shirt/solo shorts
// V20261016:  所有服装品类统一逻辑——名称定色直接通过，名称判不了才走AI；
//             名称含纯色/无印花/sin estampado/plain 直接跳过不调AI；
//             AI判other但品类正确+有印花→自动修正为黑色；
//             中心50%区域像素采样，避免蓝天/背景干扰颜色判断；
//             forceColor正确传递（原bug写死null）；
//             品牌/违禁词库101个（IP/动漫/名人/乐队/球队联盟名保留不删）
// ============================================================
(function () {
  'use strict';
  if (window.__MSKB_LOADED__) return;
  window.__MSKB_LOADED__ = true;

  // ---------------- 配置 ----------------
  var PREFIXES = [
    'ภาพพิมพ์ผ้าใบ', 'ผ้าใบติดผนัง', 'รูปติดผนัง', 'ภาพวาดผ้าใบ',
    'กรอบรูปผ้าใบ', 'canvas print', 'ภาพตกแต่งผนัง', 'รูปภาพศิลปะ',
    'โปสเตอร์', 'โปสเตอร์ติดผนัง', 'poster'
  ];
  var YINLIU_IMG_URL = 'https://earth-rt.chengji-inc.com/picture/1486172/2026-07-15/9d779d7f-02d4-4819-90ec-83c12cdb9e08.png';
  // 插件显示版本号（唯一权威来源，面板标题/加载日志统一引用；更新版本时改这里 + manifest.json）
  var PLUGIN_VERSION = 'V26.11.25.28';

  // ================= 离线授权（内部专用，防外传） =================
  // 只内置公钥，无法签发；私钥仅存在于管理员本地签发工具（不入包、不外发）。
  var LIC_PUBKEY_B64 = 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEfP9Z9IhPanqh5YcovQwHrI2LMJnQEzwWqfgV0OR1gX1sliJ3I1coP3DZ6XXvMeISjxeRxh47zaP2XYeqr1xB2w==';
  var LIC_PREFIX = 'MSKB1.';
  var LIC_OK = false;
  var LIC_INFO = { name: '', expire: '', machine: '' };
  function licB64uToBytes(b64u) {
    var b = String(b64u || '').replace(/-/g, '+').replace(/_/g, '/');
    var pad = b.length % 4;
    if (pad) b += new Array(5 - pad).join('=');
    var bin = atob(b), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function licToday() {
    var d = new Date();
    function p(n) { return n < 10 ? '0' + n : '' + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  // 机器码：持久UUID + 平台/时区/语言/核数 哈希；复制整个扩展目录到别的电脑一般也变码
  function licMachineCode() {
    var mid = '';
    try { mid = localStorage.getItem('mskb_mid') || ''; } catch (e) { }
    if (!mid) {
      mid = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
      try { localStorage.setItem('mskb_mid', mid); } catch (e) { }
    }
    var tz = '';
    try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { }
    var s = mid + '|' + (navigator.platform || '') + '|' + tz + '|' + (navigator.language || '') + '|' + (navigator.hardwareConcurrency || 0);
    var h1 = 0x811c9dc5, h2 = 0x1000193;
    for (var i = 0; i < s.length; i++) {
      var ch = s.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 16777619) >>> 0;
      h2 = Math.imul(h2 + ch, 2654435761) >>> 0;
    }
    var raw = (h1.toString(36) + h2.toString(36)).toUpperCase();
    while (raw.length < 12) raw += 'A';
    raw = raw.slice(0, 12);
    return 'MSKB-' + raw.slice(0, 4) + '-' + raw.slice(4, 8) + '-' + raw.slice(8, 12);
  }
  function licParse(code) {
    var c = String(code || '').replace(/[\s\r\n]+/g, '');
    if (c.indexOf(LIC_PREFIX) !== 0) return null;
    var rest = c.slice(LIC_PREFIX.length), dot = rest.lastIndexOf('.');
    if (dot < 1 || dot > rest.length - 2) return null;
    return { payload: rest.slice(0, dot), sig: rest.slice(dot + 1) };
  }
  // 离线验签：ECDSA P-256 + SHA-256，签名覆盖载荷原文（机器码/姓名/到期日）
  async function licVerify(code, machine) {
    try {
      var p = licParse(code);
      if (!p) return { ok: false, reason: '授权码格式不对（应为 MSKB1.载荷.签名）' };
      if (!(window.crypto && crypto.subtle)) return { ok: false, reason: '当前页面不支持加密校验，请在 https 后台页面激活' };
      var der = licB64uToBytes(LIC_PUBKEY_B64.replace(/=+$/, ''));
      var key = await crypto.subtle.importKey('spki', der, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      var okSig = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, licB64uToBytes(p.sig), licB64uToBytes(p.payload));
      if (!okSig) return { ok: false, reason: '签名无效（不是本插件授权工具签发，或授权码被改动过）' };
      var txt = new TextDecoder().decode(licB64uToBytes(p.payload));
      var j = JSON.parse(txt);
      if (!j || !j.m) return { ok: false, reason: '授权内容缺失机器码' };
      if (String(j.m).toUpperCase() !== String(machine).toUpperCase()) return { ok: false, reason: '授权码不是本机（机器码不符）' };
      if (j.e && String(j.e) < licToday()) return { ok: false, reason: '授权已过期（到期 ' + j.e + '）' };
      return { ok: true, payload: j };
    } catch (e) {
      return { ok: false, reason: '校验异常: ' + ((e && e.message) ? e.message : e) };
    }
  }
  async function licApply(code, silent) {
    var m = licMachineCode();
    var r = await licVerify(code, m);
    if (!r.ok) {
      if (!silent) log('授权失败：' + r.reason, 'err');
      return r;
    }
    try { localStorage.setItem('mskb_lic', String(code).replace(/[\s\r\n]+/g, '')); } catch (e) { }
    LIC_OK = true;
    LIC_INFO = { name: (r.payload.n || ''), expire: (r.payload.e || ''), machine: m };
    if (!silent) log('授权成功：' + (LIC_INFO.name || '未署名') + '，有效期至 ' + (LIC_INFO.expire || '长期'), 'ok');
    licPaint();
    return { ok: true, payload: r.payload };
  }
  function licPaint() {
    var st = $('mskb-lic-status');
    if (st) {
      if (LIC_OK) {
        st.textContent = '已授权' + (LIC_INFO.name ? '：' + LIC_INFO.name : '') + (LIC_INFO.expire ? '（至 ' + LIC_INFO.expire + '）' : '');
        st.style.color = '#0d8a7a';
      } else {
        st.textContent = '未授权 / 已失效';
        st.style.color = '#c0392b';
      }
    }
    var mc = $('mskb-mcode');
    if (mc) mc.value = licMachineCode();
    if (btnStart && !running) btnStart.disabled = (!LIC_OK) || UPD_FORCE;
  }
  async function licBoot() {
    var saved = '';
    try { saved = localStorage.getItem('mskb_lic') || ''; } catch (e) { }
    if (saved) {
      var r = await licApply(saved, true);
      if (r.ok) log('授权有效：' + (LIC_INFO.name || '未署名') + '，到期 ' + (LIC_INFO.expire || '长期') + '（机器码 ' + LIC_INFO.machine + '）', 'ok');
      else log('授权无效（' + r.reason + '）：请粘贴新的授权码后重新激活，未激活无法开始处理', 'warn');
    } else {
      log('未授权：把面板「授权」区里的机器码发给管理员换取授权码，激活后才能开始处理', 'warn');
    }
    licPaint();
  }

  // ================= 版本检查（强制更新）：读更新服务的 version.json，解压版同样有效 =================
  var UPD_KEY_LAST = 'mskb_upd_last';
  var UPD_FORCE = false;        // true = 有新版本必须先更新，锁住「开始处理」
  var UPD_LATEST = '';          // 服务端最新版本号
  var UPD_NOTE = '';            // 服务端附带的说明
  var UPD_ZIPURL = '';          // 服务端给的新版 zip 直链（异地用户手动下载用）
  function updAvailable() {
    return !!(typeof chrome !== 'undefined' && chrome && chrome.runtime && chrome.runtime.sendMessage);
  }
  function updSetBar(text, btnText, showBtn, tone) {
    var bar = $('mskb-updbar'), txt = $('mskb-updtext'), btn = $('mskb-updbtn');
    if (!bar || !txt) return;
    if (!text) {
      bar.style.display = 'none';
      bar.style.background = '#fff8e5';
      bar.style.borderColor = '#f0c36d';
      bar.style.color = '#8a5a00';
      return;
    }
    bar.style.display = 'flex';
    if (tone === 'danger') {
      bar.style.background = '#fdecea'; bar.style.borderColor = '#e07b6f'; bar.style.color = '#a02a1a';
    } else {
      bar.style.background = '#fff8e5'; bar.style.borderColor = '#f0c36d'; bar.style.color = '#8a5a00';
    }
    txt.textContent = text;
    if (btn) {
      btn.style.display = showBtn ? '' : 'none';
      if (btnText) btn.textContent = btnText;
      btn.disabled = false;
    }
  }
  var UPD_POP_ID = 'mskb-updpop';
  function updClosePopup() {
    var m = document.getElementById(UPD_POP_ID);
    if (m && m.parentNode) m.parentNode.removeChild(m);
  }
  // 强制更新弹窗：盖在页面中央，无关闭按钮、点遮罩不消失（只能更新后复查通过才自动关）
  function updShowPopup(latest, note) {
    var host = document.body || document.documentElement;
    if (!host) return;
    if (document.getElementById(UPD_POP_ID)) return;   // 已显示则不重建（避免每次 auto 检查闪一下）
    var mask = document.createElement('div');
    mask.id = UPD_POP_ID;
    mask.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;background:rgba(15,18,24,.55);display:flex;align-items:center;justify-content:center;padding:16px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif';
    mask.innerHTML =
      '<div style="width:min(540px,94vw);max-height:88vh;overflow:auto;background:#fff;border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.4);border-top:5px solid #d9363e;padding:22px 24px 18px;box-sizing:border-box;color:#232323">' +
        '<div style="font-size:19px;font-weight:700;color:#c0271f;line-height:1.35">⚠ 插件必须更新才能继续使用</div>' +
        '<div style="margin:11px 0 0;font-size:13px;line-height:1.75;color:#555">检测到新版本 <b style="color:#c0271f">' + updVerLabel(latest) + '</b>，你当前的 <b>' + PLUGIN_VERSION + '</b> 已停用：采集、判色、保存、发布全部锁住，更新完才能继续。</div>' +
        (note ? '<div style="margin:9px 0 0;font-size:12.5px;line-height:1.6;color:#8a5a00;background:#fff8e5;border:1px solid #f0c36d;border-radius:8px;padding:8px 10px">' + note + '</div>' : '') +
        '<div style="margin:14px 0 0;font-size:13px;line-height:1.95;color:#333">' +
          '<div><b>1.</b> 点下面 <b>「立即更新（自动完成）」</b>：自动下载新版并覆盖到你的插件目录</div>' +
          '<div><b>2.</b> 更新完本页会<b>自动刷新</b>，刷新后即为新版本，弹窗自然消失</div>' +
          '<div><b>3.</b> 若提示「更新助手没在运行」，双击一次 <b>更新插件.bat</b> 装好（只需一次），以后都点按钮即可</div>' +
        '</div>' +
        '<div style="margin:12px 0 0;font-size:12px;line-height:1.6;color:#555;background:#f7f8fa;border:1px solid #e5e7eb;border-radius:8px;padding:8px 10px" id="mskb-updpop-status">等待更新…</div>' +
        '<div style="margin:14px 0 0;display:flex;gap:10px;flex-wrap:wrap;align-items:center">' +
          '<button id="mskb-updpop-btn" style="padding:10px 18px;font-size:14px;font-weight:600;color:#fff;background:#d9363e;border:0;border-radius:8px;cursor:pointer">立即更新（自动完成）</button>' +
          '<button id="mskb-updpop-zip" style="padding:9px 14px;font-size:13px;color:#555;background:#f4f5f7;border:1px solid #dcdfe5;border-radius:8px;cursor:pointer">手动下载新版 zip</button>' +
        '</div>' +
        '<div style="margin:10px 0 0;font-size:11.5px;line-height:1.6;color:#999">自动更新失败时用「手动下载新版 zip」解压覆盖插件目录，再到 Chrome 扩展页点该插件的「重新加载」。</div>' +
      '</div>';
    host.appendChild(mask);
    var btn = mask.querySelector('#mskb-updpop-btn');
    var st = mask.querySelector('#mskb-updpop-status');
    function setStatus(t, tone) {
      if (!st) return;
      st.textContent = t;
      if (tone === 'err') { st.style.background = '#fdecea'; st.style.borderColor = '#e07b6f'; st.style.color = '#a02a1a'; }
      else if (tone === 'ok') { st.style.background = '#eaf7ee'; st.style.borderColor = '#8fd0a3'; st.style.color = '#1e6b34'; }
      else { st.style.background = '#f7f8fa'; st.style.borderColor = '#e5e7eb'; st.style.color = '#555'; }
    }
    if (btn) btn.addEventListener('click', function () {
      btn.disabled = true; btn.textContent = '正在更新…';
      setStatus('正在下载新版并覆盖插件文件（约 5～20 秒），完成后本页会自动刷新…', '');
      try { chrome.runtime.sendMessage({ type: 'MSKB_APPLY_UPDATE' }, function (r) {
        if (chrome.runtime.lastError) {
          btn.disabled = false; btn.textContent = '立即更新（自动完成）';
          setStatus('更新助手没响应：双击一次「更新插件.bat」装好（只需一次），再点这里。', 'err');
          return;
        }
        if (r && r.ok) {
          btn.textContent = '更新完成，正在刷新…';
          setStatus('已更新到 ' + updVerLabel(r.version) + '，本页马上自动刷新。', 'ok');
        } else {
          btn.disabled = false; btn.textContent = '立即更新（自动完成）';
          setStatus('更新失败：' + ((r && r.error) ? r.error : '未知原因'), 'err');
        }
      }); } catch (e) {
        btn.disabled = false; btn.textContent = '立即更新（自动完成）';
        setStatus('调用更新助手失败：' + (e && e.message ? e.message : e), 'err');
      }
    });
    var zb = mask.querySelector('#mskb-updpop-zip');
    if (zb) zb.addEventListener('click', function () {
      var u = UPD_ZIPURL || 'https://ghfast.top/https://raw.githubusercontent.com/PTlinwei/mskb-upd-7k2p9x/refs/heads/main/mskb-plugin.zip';
      try { window.open(u, '_blank'); } catch (e) { }
    });
  }
  function updCurVersion() {
    try { if (updAvailable() && chrome.runtime.getManifest) return chrome.runtime.getManifest().version; } catch (e) { }
    return '20' + PLUGIN_VERSION.replace(/^V/, '');
  }
  // 版本号展示：manifest 是 2026.11.20.22，界面上统一用 V26.11.20.22（与 PLUGIN_VERSION 一致）
  function updVerLabel(v) {
    var s = String(v || '').replace(/^v/i, '');
    s = s.replace(/^20(?=\d\d\.)/, '');
    return s ? 'V' + s : '';
  }
  function updApplyForce(force, latest, note, zipurl) {
    UPD_FORCE = !!force;
    UPD_LATEST = latest || '';
    UPD_NOTE = note || '';
    UPD_ZIPURL = zipurl || '';
    if (UPD_FORCE) {
      updSetBar('已发布新版本 ' + updVerLabel(latest) + '（当前 ' + PLUGIN_VERSION + '）已停用：点弹窗里的「立即更新（自动完成）」，或双击「更新插件.bat」' + (note ? '｜' + note : ''), '我已更新，重新检查', true, 'danger');
      updShowPopup(latest, note);
    } else {
      updSetBar('', '', false);
      updClosePopup();
    }
    licPaint();   // 统一在 licPaint 里按 授权 + 强制更新 状态控制「开始处理」
  }
  function updAsk(cb) {
    try {
      chrome.runtime.sendMessage({ type: 'MSKB_CHECK_UPDATE' }, function (r) {
        if (chrome.runtime.lastError) { cb({ ok: false, error: chrome.runtime.lastError.message }); return; }
        cb(r || {});
      });
    } catch (e) { cb({ ok: false, error: (e && e.message) ? e.message : String(e) }); }
  }
  function checkUpdate(auto) {
    if (!updAvailable()) { if (!auto) log('检查更新不可用：当前环境没有扩展后台', 'warn'); return; }
    var now = Date.now(), last = 0;
    try { last = Number(localStorage.getItem(UPD_KEY_LAST) || 0) || 0; } catch (e) { }
    if (auto && now - last < 5 * 60 * 1000) return;   // 自动检查 5 分钟节流
    try { localStorage.setItem(UPD_KEY_LAST, String(now)); } catch (e) { }
    if (!auto) updSetBar('正在检查更新…', '检查中…', false);
    updAsk(function (r) {
      if (!r.ok) {
        // 拉不到版本信息（服务没开/不在同一网段）→ 不拦人，只提示一句
        if (!auto) { updSetBar('', '', false); toast('查不到更新服务，请确认本机更新服务在运行'); }
        return;
      }
      if (r.outdated) {
        var isForce = r.force !== false;
        if (isForce) {
          log('发现新版本 ' + updVerLabel(r.latest) + '，当前 ' + PLUGIN_VERSION + ' 已被停用：请双击「更新插件.bat」更新后重启 Chrome', 'err');
          if (!auto) toast('必须先更新到 ' + updVerLabel(r.latest));
          updApplyForce(true, r.latest, r.note, r.zip);
        } else {
          updSetBar('发现新版本 ' + updVerLabel(r.latest) + '（当前 ' + PLUGIN_VERSION + '），可双击「更新插件.bat」升级', '我已更新，重新检查', true);
          log('发现新版本 ' + updVerLabel(r.latest) + '（不强制），双击「更新插件.bat」即可升级', 'warn');
        }
      } else {
        if (UPD_FORCE) { log('已更新到 ' + PLUGIN_VERSION + '，新版本要求已解除', 'ok'); }
        updApplyForce(false, '', '', '');
        if (!auto) { toast('已是最新版本'); log('版本检查：已是最新（' + PLUGIN_VERSION + '）', 'ok'); }
      }
    });
  }
  function bindUpdateUI() {
    if (!updAvailable()) return;
    var btn = $('mskb-updbtn');
    if (btn) {
      btn.addEventListener('click', function () {
        try { localStorage.removeItem(UPD_KEY_LAST); } catch (e) { }
        checkUpdate(false);
      });
    }
  }
  function updCheckPending() { /* 解压版没有 Chrome 更新机制，改为上面的 version.json 检查 */ }

  var OSS_BASE = 'https://earth-rt.chengji-inc.com/';
  // 叶子类目ID(cid) → {品类, 性别} 映射表。查到直接用，查不到再 fallback AI 看图。
  // 品类：canvas油画 / bag帆布袋(白+米,仅带印花) / tshirt T恤 / sweatshirt 卫衣(连帽+圆领同一类目) / shorts 短裤 / set 套装
  // 性别：male男 / female女 / unisex通用
  var CID_MAP = {
    '601213': { ptype: 'sweatshirt', gender: 'male' },    // 男连帽/圆领卫衣
    '601295': { ptype: 'sweatshirt', gender: 'female' },  // 女连帽/圆领卫衣
    '601226': { ptype: 'tshirt', gender: 'male' },        // 男T恤
    '601302': { ptype: 'tshirt', gender: 'female' },      // 女T恤
    '601196': { ptype: 'shorts', gender: 'unisex' },       // 短裤
    '601210': { ptype: 'set', gender: 'unisex' },         // T恤短裤套装
    '802952': { ptype: 'kids', gender: 'boy' },          // 男童
    '804232': { ptype: 'kids', gender: 'girl' },         // 女童
    '904456': { ptype: 'bag', gender: 'unisex' }         // 帆布袋(白/米·带印花)/手提布袋 cid=904456
    // 后续若帆布袋有男女款或其他叶子类目cid：先把上一行末尾补逗号，再照下式新增（去掉行首//）：
    // ,'<帆布袋cid>': { ptype: 'bag', gender: 'unisex' }  // 帆布袋/手提布袋
  };
  var API = {
    shopOptions: '/api/platform/tiktok/move/move_collect/getSelectShopPageOptions',
    search: '/api/platform/tiktok/move/collect_box/searchCollectBoxDetail',
    detail: '/api/platform/tiktok/move/collect_box/getCollectItemInfo',
    save: '/api/platform/tiktok/move/collect_box/saveShopCollectItemInfo',
    publish: '/api/platform/tiktok/move/move_collect/saveMoveCollectTask'
  };

  // ---- T恤黑白判定配置 ----
  var BLACK_WORDS = ['black', 'negro', 'negra', 'noir', 'ดำ', '黑'];
  var WHITE_WORDS = ['white', 'blanco', 'blanc', 'ขาว', '白']; // 白色关键词（黑白模式识别白色）
  // 非纯黑/纯白修饰词：命中则名字不直接判定（深灰/奶白/藏蓝/米色等模糊色）
  var NON_PURE_WORDS = ['gray', 'grey', 'เทา', 'charcoal', 'cream', 'ครีม', 'นวล',
    'ivory', 'beige', 'เบจ', 'navy', 'off-white', 'off white', 'ล้วน'];
  // 彩色词：颜色名命中则直接过滤（红/蓝/绿/黄/粉/紫/橙/棕/金/银等）
  var COLORFUL_WORDS = [
    'green', 'verde', 'เขียว', '绿',
    'red', 'rojo', 'แดง', '红', '酒红',
    'blue', 'azul', 'น้ำเงิน', '蓝', '藏青',
    'yellow', 'amarillo', 'เหลือง', '黄',
    'pink', 'rosa', 'ชมพู', '粉',
    'purple', 'morado', 'ม่วง', '紫',
    'orange', 'naranja', 'ส้ม', '橙',
    'brown', 'marron', 'cafe', 'น้ำตาล', '棕', '卡其', '杏',
    'khaki', 'เหลืองอ่อน', 'gold', 'dorado', 'ทอง', '金',
    'silver', 'plateado', 'เงิน', '银',
  ];
  // canvas 判色阈值（仅用于颜色名是编号等无法判断时，阈值拉满严格判黑）
  var COLOR_GRAY_RATIO_MIN = 0.25;
  var COLOR_BLACK_MAX = 80;
  var COLOR_DARK_RATIO_MIN = 0.30;

  // ---------------- 工具 ----------------
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function shuffle(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function charLen(s) { return Array.from(s || '').length; }
  function $(id) { return document.getElementById(id); }
  function first(arr) { return (arr && arr.length) ? arr[0] : null; }
  // 写入链路会吞掉引号内的字面量 [0]，用拼接构造带索引的参数名
  var IDX0 = '[' + 0 + ']';

  // ---- 品牌/违禁词过滤（四模式统一）----
  // 只删：品牌商标 / 采集来源卖家品牌 / 违禁极限词；
  // IP·动漫·名人·乐队·球队联盟是流量词，一律不放入、不删除（jordan 因绑定名人亦不放）。
  var DEFAULT_BRAND_WORDS = [
    'nike', 'adidas', 'puma', 'reebok', 'champion', 'carhartt', 'dickies', 'levis', "levi's",
    'tommy hilfiger', 'the north face', 'northface', 'supreme', 'stussy', 'bape', 'off-white', 'off white',
    'vans', 'converse', 'new balance', 'fila', 'under armour', 'lacoste', 'ralph lauren', 'calvin klein',
    'gucci', 'louis vuitton', 'chanel', 'prada', 'dior', 'balenciaga', 'givenchy', 'versace', 'burberry',
    'hermes', 'rolex', 'oakley', 'ysl', 'fendi', 'michael kors', 'zara', 'uniqlo',
    'renaissance', 'เรนาซองค์', 'เรนาซองซ์', 'pyramid', 'ปิรมิด', 'seikai', 'sekai', 'lofthome',
    'ohayo', 'bujoy', 'arzopa', 'marshall', 'stockwell', 'kilburn', 'willen', 'aditivo', 'maad', 'rock off',
    'best seller', 'bestselling', 'no.1', '#1', '100% authentic', '100% genuine', 'guaranteed', 'ดีที่สุด',
    // 西语面料/款式描述词 + 尺码编号类（v2.1 追加）
    'hombre 004', 'hombres 007', 'hombre007', 'ush00', 'ushoo', '007',
    'pene', 'gyatt', 'pen is', 'steroids',
    'doble cara', 'personalización según imagen', 'personalizadas', 'personalización',
    'conjunto de 2', 'brodería', 'paja', 'dios', 'cono', 'según', 'imagen',
    'algodón', 'poliéster', 'elastano', 'spandex',
    '80 %', '80%', '100 %', '100%', '95% algodón', '5% elastano', '95% algodón 5% spandex', '|'
  ];
  var brandStripRe = null;
  function escRegExp(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function buildBrandStripRe(words) {
    var seen = {}, uniq = [];
    (words || []).forEach(function (w) {
      w = String(w == null ? '' : w).trim().toLowerCase();
      if (w && !seen[w]) { seen[w] = 1; uniq.push(w); }
    });
    uniq.sort(function (a, b) { return b.length - a.length; }); // 短语优先
    if (!uniq.length) return null;
    var alt = uniq.map(function (w) {
      var e = escRegExp(w);
      var ascii = /^[\x00-\x7f]+$/.test(w); // ASCII 要词边界，泰/中直接匹配
      return ascii ? '(?<![a-z0-9])' + e + '(?![a-z0-9])' : e;
    }).join('|');
    return new RegExp(alt, 'gi');
  }
  // 剔除品牌/违禁词并清理残留标点（保留正常括号）
  function stripBrandBanned(title) {
    var t = String(title || '');
    var re = brandStripRe || buildBrandStripRe(DEFAULT_BRAND_WORDS);
    if (!re) return t;
    t = t.replace(re, ' ');
    t = t.replace(/[（(]\s*[)）]/g, ' ');
    t = t.replace(/\s+(?=[)）】])/g, '');
    t = t.replace(/(?<=[(（【])\s+/g, '');
    t = t.replace(/\s*[-–—,，、/]{2,}\s*/g, ' ');
    t = t.replace(/(^|[\s(（【])[-–—,，、/]+/g, '$1');
    t = t.replace(/[-–—,，、/]+(?=\s|$|[)）】])/g, ' ');
    t = t.replace(/\s{2,}/g, ' ');
    t = t.replace(/^[\s,，、\-–—:：;；]+|[\s,，、\-–—:：;；]+$/g, '').trim();
    return t;
  }

  function fixTitle(title) {
    var pre = shuffle(PREFIXES).slice(0, 2);
    var t = title || '';
    t = t.replace(/ขนาด\s*[\d.]+\s*[xX×]\s*[\d.]+.*?นิ้ว(\s*\(A\d+\))?/g, '');
    t = t.replace(/[\d.]+\s*[xX×]\s*[\d.]+\s*(นิ้ว|inch|cm|ซม\.)?(\s*\(A\d+\))?/g, '');
    t = t.replace(/\bSize\b.*/gi, '');
    t = stripBrandBanned(t); // 品牌商标/来源品牌/违禁词
    t = t.replace(/\s+/g, ' ').trim();
    t = pre.join(' ') + ' ' + t;
    while (charLen(t) > 255) {
      var i = t.lastIndexOf(' ');
      if (i < 0) break;
      t = t.slice(0, i);
    }
    return t;
  }

  // T恤标题：只删尺寸词 + 删100%纯棉词，保留原标题（不加前缀）
  function cleanTshirtTitle(title) {
    var t = String(title || '');
    // 尺寸词（与帆布画同一套已验证正则）
    t = t.replace(/ขนาด\s*[\d.]+\s*[xX×]\s*[\d.]+.*?นิ้ว(\s*\(A\d+\))?/g, '');
    t = t.replace(/[\d.]+\s*[xX×]\s*[\d.]+\s*(นิ้ว|inch|cm|ซม\.)?(\s*\(A\d+\))?/g, '');
    // 只删 Size 后随的尺码段(S/M/L/XL/数字/斜杠序列)，保留其后的正常标题词
    t = t.replace(/\bSize\b[\s:：\-–]*(?:XXXL|XXL|XS|XL|S|M|L|\d{1,3})(?:\s*[,/、~-]\s*(?:XXXL|XXL|XS|XL|S|M|L|\d{1,3}))*/gi, '');
    // 100%纯棉：英/泰/中
    t = t.replace(/100\s*%\s*(cotton|ผ้าฝ้าย|คอตตอน|棉)/gi, '');
    t = t.replace(/(cotton|ผ้าฝ้าย|คอตตอน)\s*100\s*%/gi, '');
    t = t.replace(/100\s*percent\s*cotton/gi, '');
    t = t.replace(/\bpure\s+cotton\b/gi, '');
    t = t.replace(/ผ้าฝ้ายแท้/g, '');
    t = t.replace(/纯棉|全棉/g, '');
    t = t.replace(/\(\s*\)/g, ' ');
    t = stripBrandBanned(t); // 品牌商标/来源品牌/违禁词（IP/名人/乐队/球队不删）
    t = t.replace(/\s+/g, ' ').trim();
    while (charLen(t) > 255) {
      var k = t.lastIndexOf(' ');
      if (k < 0) break;
      t = t.slice(0, k);
    }
    return t;
  }

  function getImgBase(url) {
    if (!url) return '';
    var noQuery = String(url).split('?')[0].replace(/\/+$/, '');
    var last = noQuery.split('/').pop() || '';
    var dot = last.lastIndexOf('.');
    var base = dot > 0 ? last.slice(0, dot) : last;
    return base.replace(/[!_.]\d+x\d+$/, '');
  }

  function getOriginSkuImgs(ossData) {
    if (!ossData || !ossData.ORIGIN) return [];
    var props = ossData.ORIGIN.skuPropertyList || [];
    if (!props.length) return [];
    var colors = (first(props) && first(props).attrValueList) || [];
    var imgs = [];
    colors.forEach(function (c) { if (c && c.imgUrl) imgs.push(c.imgUrl); });
    return imgs;
  }

  // 主图兜底取图：按“图片基名”去重（同一张图不同尺寸/参数链接视为同图），并剔除已有来源图
  // 同一张主图绝不允许生成两个规格（Negro+1/Negro+2 同图根因）
  function dedupeMainImgUrls(urls, existing) {
    var seen = {}, out = [];
    (existing || []).forEach(function (it) {
      var u = it && it.url ? String(it.url) : (typeof it === 'string' ? it : '');
      if (u) seen[getImgBase(u)] = 1;
    });
    (urls || []).forEach(function (u) {
      u = String(u || '').trim();
      if (!u) return;
      var k = getImgBase(u);
      if (seen[k]) return;
      seen[k] = 1;
      out.push(u);
    });
    return out;
  }

  // 按 attrValueId 精确配对（匹配不到退化为同位置）给妙手颜色补“它自己”的来源图。
  // 关键：绝不把来源“有图颜色”压缩后按下标对齐——来源任一颜色缺图，其后会全部错位（T恤编号款乱图根因）。
  function fillColorsImgFromOss(colors, ossData) {
    if (!ossData || !ossData.ORIGIN) return;
    var oprops = ossData.ORIGIN.skuPropertyList || [];
    var ocolors = (first(oprops) && first(oprops).attrValueList) || [];
    var byId = {};
    ocolors.forEach(function (o) { if (o && o.attrValueId) byId[String(o.attrValueId)] = o; });
    colors.forEach(function (c, k) {
      if (!c) return;
      if (!c.imgUrl) {
        var m = (c.attrValueId && byId[String(c.attrValueId)]) || ocolors[k]; // 先按ID，再同位置，均不压缩
        if (m && m.imgUrl) {
          c.imgUrl = m.imgUrl;
          if (!c.imgUrls || !c.imgUrls.length) c.imgUrls = [m.imgUrl];
        }
      } else if (!c.imgUrls || !c.imgUrls.length) {
        c.imgUrls = [c.imgUrl];
      }
    });
  }

  // 引流来源颜色列表：优先妙手颜色字段，否则取 OSS ORIGIN 规格一每个来源颜色（名字+代表图，有序、去重）
  async function buildSourceColorList(colors, p) {
    var list = [];
    // 优先用采集来源图(OSS ORIGIN，带真实颜色名如 Negro/Blanco)，名称过滤可减少AI；模板规格图(image-XX)不判色
    if (p.item.dataPath) {
      var oss = await fetchOssJson(p.item.dataPath);
      var op = (oss && oss.ORIGIN && oss.ORIGIN.skuPropertyList) || [];
      var oc = (op[0] && op[0].attrValueList) || [];
      var seen0 = {};
      oc.forEach(function (c) {
        if (c && c.imgUrl && !seen0[c.imgUrl]) { seen0[c.imgUrl] = 1; list.push({ name: c.attrValue, url: c.imgUrl }); }
      });
      if (typeof log === 'function') {
        var osl = (oss && oss.ORIGIN && oss.ORIGIN.skuPropertyList) || [];
        log('  [诊断OSS] dataPath=' + (p.item.dataPath || '') + ' 返回=' + (oss ? 'ok' : 'null') + ' ORIGIN=' + (oss && oss.ORIGIN ? '有' : '无') + ' skuList=' + osl.length + ' 来源颜色数=' + oc.length);
      }
    }
    // 无 OSS 来源图时才退回模板规格图保底
    if (!list.length) {
      // 模板回退(无OSS来源)：跳过插件自建的 diseño personalizado 固定槽，它由定制逻辑重建，不能当来源图判色/被定制词过滤
      var mine = colors.filter(function (c) { return c && c.imgUrl && !isPluginReservedSlotName(c.attrValue); });
      if (mine.length) mine.forEach(function (c) { list.push({ name: c.attrValue, url: c.imgUrl }); });
    }
    if (typeof log === 'function') {
      var ossN = (oc || []).filter(function (c) { return c && c.imgUrl; }).map(function (c) { return c.attrValue; }).join(',');
      var tplN = colors.filter(function (c) { return c && c.imgUrl; }).map(function (c) { return c.attrValue; }).join(',');
      log('  [诊断] 来源图: OSS名称[' + (ossN || '无') + '] 模板名称[' + (tplN || '无') + '] 实际取[' + list.map(function (x) { return x.name; }).join(',') + ']');
    }
    return list;
  }
  // T恤引流：只按颜色名筛选。onlyBlack=true只留黑色(CVC模式)；onlyBlack=false留黑+白(黑白模式)
  async function filterBlackWhiteSource(list, onlyBlack, dedupByColor) {
    var pool = [], detail = [], seenColor = {};
    for (var i = 0; i < list.length; i++) {
      var it = list[i];
      var v = null, how = '';
      // 名称是"主图X"的，直接走图像判色（名称无意义）；其他先名称判色
      var isMainImg = /^主图\d+$/.test(it.name || '');
      if (!isMainImg) {
        v = judgeColorByName(it.name);
        how = 'name';
      }
      // 名称判色无匹配（或主图）→ 图像阈值判色兜底
      if (!v && it.url) {
        v = await judgeColorByImage(it.url);
        how = 'img';
      }
      var keep = (v === 'black') || (!onlyBlack && v === 'white');
      // 按颜色去重：同颜色只保留第一张（产品主图前3张可能有同颜色同印花的不同角度）
      var dup = false;
      if (keep && dedupByColor) {
        if (seenColor[v]) { keep = false; dup = true; } else { seenColor[v] = 1; }
      }
      detail.push((it.name || '?') + ':' + (v === 'black' ? '黑' : v === 'white' ? '白' : '✗') + '(' + how + ')' + (dup ? '[同色去重]' : ''));
      if (keep) pool.push(it.url);
    }
    return { pool: pool, detail: detail };
  }
  // 引流分配（帆布引流 / T恤引流通用）：
  // 槽0(01)固定盲盒；从槽1(02)起按顺序一张来源图对一个槽；来源图用完即止，
  // 剩余空槽不保留（交给后面删多余规格），绝不拿第一张重复填充。
  // needJudge=true（T恤引流）来源图先判色；onlyBlack=true只留黑(CVC)，onlyBlack=false留黑+白(黑白)
  async function assignYinliuSlots(colors, p, needJudge, sourceImgs, judgeOpts, slotOpts) {
    var srcList = await buildSourceColorList(colors, p);
    var pool = [], detail = [];
    var aiCalledY = false;
    if (needJudge) {
      // judgeOpts = {colors:['black','white'], category:'tshirt'} 或 {colors:['black','gray'], category:'shorts'}
      var ylOpts = judgeOpts || { colors: ['black', 'white'], category: 'top' };
      // 第一步：SKU图全部判色（含第1个规格，正常进选池）（名称→像素→AI三级）
      var fb = await aiFilterSourceList(srcList, ylOpts);
      pool = fb.pool; detail = fb.detail;
      if (fb.aiCalled) aiCalledY = true;
      // 第二步：SKU图全无匹配时，只取第1张产品主图判色兜底（同图不同尺寸链接按基名去重，最多1张）
      if (!pool.length && sourceImgs && sourceImgs.length) {
        var mainList = [];
        var mainUrls = dedupeMainImgUrls(sourceImgs.slice(0, 2), srcList);
        if (mainUrls.length) mainList.push({ name: '主图1', url: mainUrls[0] });
        if (mainList.length) {
          var fb2 = await aiFilterSourceList(mainList, { colors: ylOpts.colors, category: ylOpts.category, catKey: ylOpts.catKey });
          pool = fb2.pool;
          detail = detail.concat(['[主图兜底]']).concat(fb2.detail);
          if (fb2.aiCalled) aiCalledY = true;
        }
      }
      // 选池按“图片基名”去重（同上：同图不生成两个规格）
      if (pool.length > 1) {
        var seenPoolY = {}, poolUniqY = [];
        pool.forEach(function (x) {
          var k = getImgBase(x && x.url ? x.url : '');
          if (!k || !seenPoolY[k]) { if (k) seenPoolY[k] = 1; poolUniqY.push(x); }
        });
        pool = poolUniqY;
      }
      // 引流：无匹配颜色带印花图直接跳过
      if (!pool.length) {
        detail.push('(无匹配颜色带印花图→整款跳过)');
        return { pool: pool, kept: [], detail: detail, aiCalled: aiCalledY };
      }
    } else {
      // 非T恤引流（帆布引流）：SKU图+产品主图都用，不判色；主图按基名去重，同一张图不重复成规格
      if (sourceImgs && sourceImgs.length) {
        var mainUrlsB = dedupeMainImgUrls(sourceImgs.slice(0, 3), srcList);
        mainUrlsB.forEach(function (u, i) { srcList.push({ name: '主图' + (i + 1), url: u }); });
      }
      var seen = {};
      srcList.forEach(function (it) { if (it.url && !seen[getImgBase(it.url)]) { seen[getImgBase(it.url)] = 1; pool.push({ url: it.url, color: null }); } });
    }
    if (!pool.length || !colors.length) return { pool: pool, kept: [], detail: detail, aiCalled: aiCalledY };
    if (slotOpts && slotOpts.customUrl) {
      // 引流+定制：槽0(index0/第1规格)=引流盲盒(外层盖图)，槽1(index1/第2规格)=定制固定图并命名 diseño personalizado，
      // 来源pool从槽2(index2/第3规格)起顺序占槽；超出克隆时固定以「第3个规格 colors[2]」为模板(跳过盲盒槽与定制槽)。
      // 规格不足3个先以第1规格为底补齐：colors[1]给定制槽、colors[2]给首个来源槽兼克隆模板，避免模板回退到定制槽而复制 diseño personalizado/__mskbCustom。
      while (colors.length < 3) {
        var preC = Object.assign({}, colors[0]);
        preC.attrValueId = 'new_' + Date.now() + '_pre' + colors.length;
        preC.isNew = true;
        colors.push(preC);
      }
      var keptC = [colors[0]];
      var customSlotY = colors[1];
      customSlotY.imgUrl = slotOpts.customUrl;
      customSlotY.imgUrls = [slotOpts.customUrl];
      customSlotY.attrValue = CUSTOM_SKU_NAME;
      customSlotY.__mskbCustom = true;
      keptC.push(customSlotY);
      var kC = 2, piC = 0;
      for (; kC < colors.length && piC < pool.length; kC++, piC++) {
        colors[kC].imgUrl = pool[piC].url;
        colors[kC].imgUrls = [pool[piC].url];
        keptC.push(colors[kC]);
      }
      // 固定克隆第3个规格(index2，首个来源槽)；补槽后必存在。不得回退 colors[1](那是定制槽)
      var tmplYC = colors[2];
      for (var jC = piC; jC < pool.length; jC++) {
        var ncYC = Object.assign({}, tmplYC);
        delete ncYC.__mskbCustom; // 来源克隆槽绝不携带定制槽标记
        ncYC.attrValueId = 'new_' + Date.now() + '_c' + jC;
        ncYC.imgUrl = pool[jC].url;
        ncYC.imgUrls = [pool[jC].url];
        ncYC.isNew = true;
        colors.push(ncYC);
        keptC.push(ncYC);
        log('  ➕ 自动添加规格槽(克隆第3规格): [来源图' + (jC + 1) + ']', 'ok');
      }
      return { pool: pool, kept: keptC, detail: detail, aiCalled: aiCalledY, customSlot: customSlotY };
    }
    // 纯引流：槽0(index0/第1规格)固定留给盲盒(外层盖图)；来源pool从槽1(index1/第2规格)起顺序占槽
    if (colors.length < 2) {
      // 商品原本只有1个规格时，先以第1规格为底补出第2规格，作为来源首槽与克隆模板
      var preY = Object.assign({}, colors[0]);
      preY.attrValueId = 'new_' + Date.now() + '_pre1';
      preY.isNew = true;
      colors.push(preY);
    }
    var kept = [colors[0]]; // 01 留给盲盒
    for (var i = 1; i < colors.length; i++) {
      var pi = i - 1;
      if (pi < pool.length) {
        colors[i].imgUrl = pool[pi].url;
        colors[i].imgUrls = [pool[pi].url];
        kept.push(colors[i]);
      }
      // 来源图用完后的槽位不 push（=多余规格，后面删除）
    }
    // pool 超出现有槽位 → 固定克隆第2个规格(index1，序号02，带价格)并覆盖图片；不回退第1规格(盲盒槽)
    var tmplY = colors[1];
    for (var j = colors.length - 1; j < pool.length; j++) {
      var ncY = Object.assign({}, tmplY);
      delete ncY.__mskbCustom;
      ncY.attrValueId = 'new_' + Date.now() + '_' + j;
      ncY.imgUrl = pool[j].url;
      ncY.imgUrls = [pool[j].url];
      ncY.isNew = true;
      colors.push(ncY);
      kept.push(ncY);
      log('  ➕ 自动添加规格槽(克隆第2规格): [来源图' + (j + 1) + ']', 'ok');
    }
    return { pool: pool, kept: kept, detail: detail, aiCalled: aiCalledY };
  }

  // ---------------- T恤：下载SKU图用canvas像素判底色 ----------------
  function fetchImageBitmap(url, timeoutMs) {
    return new Promise(function (resolve) {
      var done = false;
      var finish = function (v) { if (!done) { done = true; resolve(v); } };
      var timer = setTimeout(function () { finish(null); }, timeoutMs || 12000);
      fetch(url, { credentials: 'omit' })
        .then(function (resp) {
          if (!resp.ok) { clearTimeout(timer); finish(null); return; }
          return resp.blob();
        })
        .then(function (blob) {
          if (!blob) { clearTimeout(timer); finish(null); return; }
          return createImageBitmap(blob).then(function (bmp) { clearTimeout(timer); finish(bmp); });
        })
        .catch(function () { clearTimeout(timer); finish(null); });
    });
  }

  // ---------------- AI判色（硅基流动 Qwen2-VL）----------------
  var SF_API_KEY = 'sk-unyjrugwkdlzaznkxtktitmewsdfhmfolljjzojjjrrjaqfy';
  var SF_API_URL = 'https://api.siliconflow.cn/v1/chat/completions';
  var SF_PROMPT = '你是电商图片识别助手。最高优先级规则：同一件衣服的正反面并排展示、同款同色多件展示、一件衣服多视角，都不算多件套，is_multi_pack一律为false；只有不同款式的真多件套才为true。分析这张图片，只回答JSON：{"color":"black/white/gray/lightblue/pink/red/beige/other","category":"tshirt/hoodie/crewneck/shorts/set/kids/bag/other","has_print":true/false,"is_detail":true/false,"is_multi_pack":true/false,"top_color":"black/white/gray/other","bottom_color":"black/white/gray/other","is_long_sleeve":true/false,"is_long_pants":true/false}。color=服装主体颜色（black=纯黑/近黑；white=纯白/近白；gray=灰色；lightblue=浅蓝色/淡蓝色；pink=粉红色/粉色；red=正红色/大红色；beige=米色/杏色/奶白色/浅卡其(beige/crema/marfil/ivory)；other=其他所有颜色，包括藏蓝/深蓝/酒红/深紫/深绿/棕色/深卡其/橙色/黄色/绿色都算other）。category=服装品类（tshirt=短袖T恤，无帽、短袖；hoodie=连帽卫衣/帽衫，有帽子；crewneck=圆领卫衣，无帽、长袖、圆领；shorts=短裤；set=上下装套装；kids=儿童服装/童装；bag=帆布袋/手提布袋/购物袋（布质袋身+两条提手、可手提肩背的包，不是穿在身上的衣服）；other=其他非服装/非布袋类商品）。has_print=服装布料本身是否有印花图案（正面印花/背面印花都算true，纯色无印花/只有小logo算false）。关键：严格只看衣服布料上的图案，背景场景/沙滩/海浪/天空/道具/墙壁/模特皮肤都不算印花。is_detail=是否为局部特写而非整体展示（领口/袖口/布料/标签/尺码表/模特局部算true；正面/背面/侧面整体展示都算false）。is_multi_pack=图片中是否展示多件服装组合套装（多色不同款同时摆拍/模特同时穿多件/平铺多件不同颜色为true，单件单独展示为false；同一件服装的正反面并排展示或同款同色多件展示不算多件套，算单件展示为false）。当category=set（上下装套装）时：top_color=上衣（上装）的颜色，bottom_color=短裤（下装）的颜色，只在black/white/gray中选择，无法判断填other；is_long_sleeve=上衣是否为长袖（短袖为false，长袖为true）；is_long_pants=下装是否为长裤（短裤为false，长裤为true）。非套装时is_long_sleeve/is_long_pants都填false。不要输出其他文字。';

  // 套装掩膜快判（白上衣+黑/灰短裤）：
  // 1) 上半区找居中的近白连通块=白T本体；2) 下半区找深色/灰色连通块=短裤；
  // 3) 两块都成立才确认套装；4) 只数白块内部(被白像素包围)的墨迹判印花，背景天然排除。
  // 返回：undefined=非白上衣(走旧黑款逻辑)；null=确认不是可放行套装/无印花(进AI)；对象=白套装有印花像素放行
  async function setMaskQuickJudge(url) {
    var N = 64;
    var bmp = await fetchImageBitmap(url);
    if (!bmp) return undefined;
    var cv = document.createElement('canvas'); cv.width = N; cv.height = N;
    var ctx = cv.getContext('2d');
    ctx.drawImage(bmp, 0, 0, N, N);
    var data = ctx.getImageData(0, 0, N, N).data;
    var cls = new Array(N * N);      // 0背景 1白 2深色 3灰
    var Larr = new Array(N * N), Satarr = new Array(N * N);
    for (var k = 0; k < N * N; k++) {
      var o = k * 4, R = data[o], G = data[o + 1], B = data[o + 2];
      var L = 0.299 * R + 0.587 * G + 0.114 * B;
      var sat = Math.max(R, G, B) - Math.min(R, G, B);
      Larr[k] = L; Satarr[k] = sat;
      if (L >= 165 && sat <= 42) cls[k] = 1;
      else if (L <= 95 && sat <= 55) cls[k] = 2;
      else if (L > 95 && L < 165 && sat <= 45) cls[k] = 3;
      else cls[k] = 0;
    }
    function components(accept, rowMax, rowMin) {
      var seen = new Array(N * N).fill(false), out = [];
      var dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (var s = 0; s < N * N; s++) {
        var sy = (s / N) | 0, sx = s % N;
        if (seen[s] || !accept(cls[s]) || sy < rowMin || sy > rowMax) continue;
        var q = [s], qi = 0; seen[s] = true;
        var sumX = sx, sumY = sy, minX = sx, maxX = sx, minY = sy, maxY = sy;
        while (qi < q.length) {
          var cur = q[qi++], cy = (cur / N) | 0, cx = cur % N;
          for (var dd = 0; dd < 4; dd++) {
            var nx = cx + dirs[dd][0], ny = cy + dirs[dd][1];
            if (nx < 0 || nx >= N || ny < rowMin || ny > rowMax) continue;
            var ns = ny * N + nx;
            if (!seen[ns] && accept(cls[ns])) { seen[ns] = true; q.push(ns); }
          }
          sumX += cx; sumY += cy;
          if (cx < minX) minX = cx; if (cx > maxX) maxX = cx;
          if (cy < minY) minY = cy; if (cy > maxY) maxY = cy;
        }
        out.push({ area: q.length, cells: q, cx: sumX / q.length, cy: sumY / q.length, minX: minX, maxX: maxX, minY: minY, maxY: maxY });
      }
      return out;
    }
    // 上半区白块（行0~35）
    var tops = components(function (c) { return c === 1; }, 35, 0);
    var top = null;
    for (var ti = 0; ti < tops.length; ti++) {
      var t = tops[ti];
      if (t.area >= 40 && t.cx >= 14 && t.cx <= 50 && t.maxY <= 42 && (!top || t.area > top.area)) top = t;
    }
    if (!top) return undefined; // 非白上衣，交给旧黑款逻辑
    // 下半区深色/灰色短裤块（行28~63）
    var bots = components(function (c) { return c === 2 || c === 3; }, 63, 28);
    var bot = null;
    for (var bi = 0; bi < bots.length; bi++) {
      var b = bots[bi];
      if (b.area >= 40 && b.cx >= 12 && b.cx <= 52 && b.minY >= 26 && (!bot || b.area > bot.area)) bot = b;
    }
    if (!bot) return null; // 下半区无短裤=单T，不放行
    // 白块内部墨迹：非白像素且4邻域≥3个属于白块（被白衣包围的印花），背景/短裤不满足
    var inWhite = new Array(N * N).fill(false);
    for (var ci = 0; ci < top.cells.length; ci++) inWhite[top.cells[ci]] = true;
    var ink = 0, lSum = 0, l2Sum = 0;
    for (var wi = 0; wi < top.cells.length; wi++) {
      var id = top.cells[wi];
      lSum += Larr[id]; l2Sum += Larr[id] * Larr[id];
    }
    // 统计被白块包围的非白像素（印花墨迹）
    var holeSeen = {};
    for (var wi2 = 0; wi2 < top.cells.length; wi2++) {
      var id2 = top.cells[wi2], iy2 = (id2 / N) | 0, ix2 = id2 % N;
      var cand = [[ix2 + 1, iy2], [ix2 - 1, iy2], [ix2, iy2 + 1], [ix2, iy2 - 1]];
      for (var cn = 0; cn < 4; cn++) {
        var hx = cand[cn][0], hy = cand[cn][1];
        if (hx < 0 || hx >= N || hy < 0 || hy >= N) continue;
        var hid = hy * N + hx;
        if (inWhite[hid] || holeSeen[hid]) continue;
        var hL = Larr[hid], hSat = Satarr[hid];
        var isInk = (hL < 100 && hSat < 60) || (hSat > 60 && hL < 195);
        if (!isInk) continue;
        // 该墨迹像素四邻域中白块像素≥3 → 视为被白衣包围
        var wn = 0, hn4 = [[hx + 1, hy], [hx - 1, hy], [hx, hy + 1], [hx, hy - 1]];
        for (var hn = 0; hn < 4; hn++) {
          var hxx = hn4[hn][0], hyy = hn4[hn][1];
          if (hxx >= 0 && hxx < N && hyy >= 0 && hyy < N && inWhite[hyy * N + hxx]) wn++;
        }
        if (wn >= 3) { holeSeen[hid] = 1; ink++; }
      }
    }
    var meanL = lSum / top.cells.length, varL = l2Sum / top.cells.length - meanL * meanL;
    var inkRatio = ink / top.cells.length;
    if (inkRatio >= 0.06 && inkRatio <= 0.5 && varL > 800) {
      return { color: 'white', category: 'set', hasPrint: true, isDetail: false, quick: true, mask: true };
    }
    return null; // 无足够印花证据 → 进AI，不像素放行
  }

  // 像素快速初筛：明显黑/白有印花直接通过，明显纯色/灰色直接过滤，不确定才进AI
  async function pixelQuickJudge(url, isSet, imgName) {
    try {
      // 套装优先走掩膜判定：白上衣+短裤双连通块验证，背景排除
      if (isSet) {
        var sq = await setMaskQuickJudge(url);
        if (sq !== undefined) return sq; // 白上衣：有印花放行/无印花进AI；非白上衣才落旧逻辑
      }
      var bmp = await fetchImageBitmap(url);
      if (!bmp) return null;
      var cv = document.createElement('canvas');
      cv.width = 64; cv.height = 64;
      var ctx = cv.getContext('2d');
      // 只采样中心80%区域（衣服主体），周边20%背景不判
      var cw = bmp.width, ch = bmp.height;
      ctx.drawImage(bmp, cw*0.1, ch*0.1, cw*0.8, ch*0.8, 0, 0, 64, 64);
      var d = ctx.getImageData(0, 0, 64, 64).data;
      var body = 0, dark = 0, light = 0, colorPx = 0, lSum = 0, lSum2 = 0, rSum = 0, gSum = 0, bSum = 0;
      for (var i = 0; i < d.length; i += 4) {
        var R = d[i], G = d[i+1], B = d[i+2];
        if (R > 235 && G > 235 && B > 235) continue;
        body++;
        var L = 0.299*R + 0.587*G + 0.114*B;
        lSum += L; lSum2 += L*L; rSum += R; gSum += G; bSum += B;
        var sat = Math.max(R,G,B) - Math.min(R,G,B);
        if (sat < 30) { if (L < 95) dark++; if (L > 145) light++; } else { colorPx++; }
      }
      if (body < 50) return null;
      var avgL = lSum / body;
      var varL = lSum2 / body - avgL * avgL;
      var avg80R = rSum / body, avg80G = gSum / body, avg80B = bSum / body;
      // 采样中心15%（中央小块）平均色，与中心80%主体色对比：有颜色差异=带印花，无差异=纯色
      var cv2 = document.createElement('canvas'); cv2.width = 16; cv2.height = 16;
      var ctx2 = cv2.getContext('2d');
      ctx2.drawImage(bmp, cw*0.425, ch*0.425, cw*0.15, ch*0.15, 0, 0, 16, 16);
      var d2 = ctx2.getImageData(0, 0, 16, 16).data;
      var b2 = 0, r2 = 0, g2 = 0, b2sum = 0;
      for (var j = 0; j < d2.length; j += 4) {
        var R2 = d2[j], G2 = d2[j+1], B2 = d2[j+2];
        if (R2 > 235 && G2 > 235 && B2 > 235) continue;
        b2++; r2 += R2; g2 += G2; b2sum += B2;
      }
      var centerDiff = 0;
      if (b2 > 5) {
        centerDiff = Math.abs(r2/b2 - avg80R) + Math.abs(g2/b2 - avg80G) + Math.abs(b2sum/b2 - avg80B);
      }
      var hasPrint = centerDiff > 30;
      // 注：白上衣像素快判已移除——海滩/街景等彩色背景(棕榈/冲浪板/天空)会被误判成印花，
      // 导致纯白套装误放。白款统一走「名称无印花直接过滤 → 其余进AI」，黑款像素快判保留。
      // 明显纯色无印花：方差<400 → 进AI判（脑图：判纯色/失败→进AI，不直接过滤）
      if (varL < 400) return null;
      // 灰色低方差 → 进AI判（脑图：判纯色/失败→进AI）
      if (avgL >= 110 && avgL <= 170 && varL < 600) return null;
      // V26.11.20.13 胸口印花密度复核：旧 hasPrint 只看中心均色色差(centerDiff>30)，纯黑T褶皱/领口高光、
      // 白衣混入木纹背景都会造成中心色差，使货号名(01/1/11)纯色款被误当印花 quick 上架（实测 Negro+1/Blanco+1 纯色槽）。
      // 即将 quick 命中前再采样胸口中心40%区块：相对主体底色的异类像素占比 + 区内亮度标准差同时达标才算真印花；
      // 不达标则否决 quick → 落到函数末尾 return null 进 AI（AI 判无印花由选池 r.hasPrint 硬条件过滤），本地不直接删图以免误杀小印花。
      if (hasPrint) {
        try {
          var qCv = document.createElement('canvas'); qCv.width = 24; qCv.height = 24;
          var qCtx = qCv.getContext('2d');
          qCtx.drawImage(bmp, cw * 0.30, ch * 0.30, cw * 0.40, ch * 0.40, 0, 0, 24, 24);
          var qd = qCtx.getImageData(0, 0, 24, 24).data;
          var qN = 0, qLS = 0, qLS2 = 0, qPrint = 0, qDist2, qi, qR, qG, qB, qL, qdr, qdg, qdb;
          for (qi = 0; qi < qd.length; qi += 4) {
            qR = qd[qi]; qG = qd[qi + 1]; qB = qd[qi + 2];
            if (qR > 238 && qG > 238 && qB > 238) continue; // 中心区纯白(背景/白底)不计入布料统计
            qN++;
            qL = 0.299 * qR + 0.587 * qG + 0.114 * qB;
            qLS += qL; qLS2 += qL * qL;
            qdr = qR - avg80R; qdg = qG - avg80G; qdb = qB - avg80B;
            qDist2 = qdr * qdr + qdg * qdg + qdb * qdb;
            if (qDist2 > 4900) qPrint++; // 欧氏RGB距离>70：明显异于主体底色（黑衣白/彩印花、白衣黑/彩印花）
          }
          var qRatio = qN ? qPrint / qN : 0;
          var qMeanL = qN ? qLS / qN : 0;
          var qSd = qN > 1 ? Math.sqrt(Math.max(0, qLS2 / qN - qMeanL * qMeanL)) : 0;
          // 阈值保守：真实胸前印花通常占胸口采样区5%以上且拉开亮度离散；纯色褶皱/光影两项均偏低
          if (!(qRatio >= 0.05 && qSd >= 26)) hasPrint = false;
        } catch (qe) { /* 复核画布异常时沿用原 centerDiff 结论，不阻断主链路 */ }
      }
      // 明显黑色有印花：平均亮度<95 且 暗像素>20% 且 有印花 → 直接判黑（不限制彩色像素，黑色带彩色印花也直接判，省AI调用）
      if (avgL < 95 && dark / body > 0.20 && hasPrint) return { color: 'black', category: 'tshirt', hasPrint: true, isDetail: false, quick: true };
      // 黑色带大面积(彩色)印花：平均亮度被印花拉高，但暗像素占比>35% 且 有印花 → 判黑（酒红/藏蓝低饱和暗占比低不满足，交给AI判，防误上彩色）
      if (dark / body > 0.35 && hasPrint) return { color: 'black', category: 'tshirt', hasPrint: true, isDetail: false, quick: true };
      // 明显白色有印花：平均亮度>175 且 亮像素>25% 且 有印花 → 判白（粉色/浅杏色亮像素占比低不满足，交给AI判）
      if (avgL > 175 && light / body > 0.25 && hasPrint) return { color: 'white', category: 'tshirt', hasPrint: true, isDetail: false, quick: true };
      // 不确定 → 进AI精判
      return null;
    } catch (e) { return null; }
  }

  async function aiJudgeColor(imgUrl, skipPixel, forceColor) {
    // 最多尝试2次（超时/异常自动重试）
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        // 第一步：像素快速初筛（skipPixel=true时跳过，产品图兜底用）
        if (!skipPixel) {
          var quick = await pixelQuickJudge(imgUrl);
          if (quick) {
            if (forceColor) quick.color = forceColor;
            log('  ⏺ 像素判色: 命中 → 判' + quick.color + (quick.hasPrint ? '带印花' : '无印花') + (quick.quick ? '(快筛)' : ''), 'ok');
            return quick;
          }
          log('  ⏺ 像素判色: 未命中快筛 → 进AI', 'warn');
        }
        // 第二步：调AI精判（90秒超时）
        log('  ⏳ AI判色中：' + ((String(imgUrl).split('/').pop() || '图').slice(0, 24)) + ' …', 'warn');
        var ctrl = new AbortController();
        var timer = setTimeout(function () { ctrl.abort(); }, 90000);
        var resp = await fetch(SF_API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SF_API_KEY },
          signal: ctrl.signal,
          body: JSON.stringify({
            model: 'Qwen/Qwen3-VL-8B-Instruct',
            messages: [{ role: 'user', content: [
              { type: 'text', text: SF_PROMPT },
              { type: 'image_url', image_url: { url: imgUrl } }
            ]}],
            max_tokens: 150, temperature: 0.1
          })
        });
        clearTimeout(timer);
        if (!resp.ok) {
          var errText = '';
          try { errText = await resp.text(); } catch (e) {}
          console.log('[AI判色] HTTP错误:', resp.status, errText, imgUrl, '尝试', attempt + 1);
          if (attempt === 0) { await new Promise(function (r) { setTimeout(r, 1000); }); continue; }
          log('  ⚠️ AI判色失败: HTTP ' + resp.status + (errText ? ' ' + String(errText).slice(0, 80) : '') + ' [图:' + (String(imgUrl).split('/').pop() || '?').slice(0, 20) + ']', 'warn');
          return null;
        }
        var data = await resp.json();
        if (data.error) {
          console.log('[AI判色] API错误:', JSON.stringify(data.error), imgUrl, '尝试', attempt + 1);
          if (attempt === 0) { await new Promise(function (r) { setTimeout(r, 1000); }); continue; }
          log('  ⚠️ AI判色失败: API错误 ' + JSON.stringify(data.error).slice(0, 100) + ' [图:' + (String(imgUrl).split('/').pop() || '?').slice(0, 20) + ']', 'warn');
          return null;
        }
        var text = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content || '').trim();
        var m = text.match(/\{[\s\S]*\}/);
        if (!m) {
          console.log('[AI判色] 返回非JSON:', text, imgUrl, '尝试', attempt + 1);
          if (attempt === 0) { await new Promise(function (r) { setTimeout(r, 1000); }); continue; }
          log('  ⚠️ AI判色失败: 返回非JSON "' + String(text).slice(0, 60) + '" [图:' + (String(imgUrl).split('/').pop() || '?').slice(0, 20) + ']', 'warn');
          return null;
        }
        var r = JSON.parse(m[0]);
        // 归一化：AI偶返回整串枚举如"black/white/gray/..."，统一归为other
        var aiColor = (r.color || 'other').trim().toLowerCase();
        if (!['black','white','gray','lightblue','pink','red','beige','other'].includes(aiColor)) aiColor = 'other';
        var aiCat = (r.category || 'other').trim().toLowerCase();
        if (!['tshirt','hoodie','crewneck','shorts','set','kids','bag','other'].includes(aiCat)) aiCat = 'other';
        function normSetColor(c) {
          c = (c || '').trim().toLowerCase();
          return ['black','white','gray'].includes(c) ? c : 'other';
        }
        var result = { color: aiColor, category: aiCat, hasPrint: r.has_print === true, isDetail: r.is_detail === true, isMultiPack: r.is_multi_pack === true,
          topColor: normSetColor(r.top_color), bottomColor: normSetColor(r.bottom_color),
          isLongSleeve: r.is_long_sleeve === true, isLongPants: r.is_long_pants === true };
        // forceColor：名称匹配颜色词时强制覆盖颜色（SKU图名称是Negro/Blanco等直接认定颜色）
        if (forceColor) result.color = forceColor;
        // AI结果像素验证：AI判black时验主体是否真黑（低饱和暗像素占比）
        // 黑色带印花T恤：印花(白/彩)周围是大面积黑色布料，低饱和暗像素占比高 → 保持black上架
        // 酒红/藏蓝/深蓝/绿/紫等彩色（饱和度高，非低饱和暗）→ 低饱和暗像素占比低 → 修正为other过滤
        // 采样中心80%（含印花+四周黑色布料），避开边缘背景；不用中心50%（恰是印花位置）误杀黑色带印花
        if (!forceColor && result.color === 'black') {
          try {
            var vBmp = await fetchImageBitmap(imgUrl);
            if (vBmp) {
              var vCv = document.createElement('canvas'); vCv.width = 48; vCv.height = 48;
              var vCtx = vCv.getContext('2d');
              var cw = vBmp.width, ch = vBmp.height;
              var sx = cw * 0.1, sy = ch * 0.1, sw = cw * 0.8, sh = ch * 0.8;
              vCtx.drawImage(vBmp, sx, sy, sw, sh, 0, 0, 48, 48);
              var vd = vCtx.getImageData(0, 0, 48, 48).data;
              var vBody = 0, vDarkLow = 0;
              for (var vi = 0; vi < vd.length; vi += 4) {
                var vR = vd[vi], vG = vd[vi+1], vB2 = vd[vi+2];
                if (vR > 235 && vG > 235 && vB2 > 235) continue;
                vBody++;
                var vL2 = 0.299*vR + 0.587*vG + 0.114*vB2;
                var vSat = Math.max(vR, vG, vB2) - Math.min(vR, vG, vB2);
                if (vSat < 30 && vL2 < 95) vDarkLow++;
              }
              if (vBody > 40) {
                // 低饱和暗像素占比<12%（如酒红/藏蓝，彩色饱和高不算）→ 主体非黑 → other过滤
                if (vDarkLow / vBody < 0.12) {
                  result.color = 'other';
                  result.colorFixed = true;
                }
              }
            }
          } catch (e) {}
        }
        return result;
      } catch (e) {
        console.log('[AI判色] 异常:', e.message, imgUrl, '尝试', attempt + 1);
        if (attempt === 0) { await new Promise(function (r) { setTimeout(r, 1000); }); continue; }
        log('  ⚠️ AI判色失败: 异常 ' + (e && e.message || '') + ' [图:' + (String(imgUrl).split('/').pop() || '?').slice(0, 20) + ']', 'warn');
        return null;
      }
    }
    return null;
  }

  // 计算图片平均颜色（用于去重）
  async function getAvgColor(url) {
    try {
      var bmp = await fetchImageBitmap(url);
      if (!bmp) return null;
      var cv = document.createElement('canvas');
      cv.width = 32; cv.height = 32;
      var ctx = cv.getContext('2d');
      ctx.drawImage(bmp, 0, 0, 32, 32);
      var d = ctx.getImageData(0, 0, 32, 32).data;
      var r = 0, g = 0, b = 0, n = 0;
      for (var i = 0; i < d.length; i += 4) {
        if (d[i] > 235 && d[i+1] > 235 && d[i+2] > 235) continue;
        r += d[i]; g += d[i+1]; b += d[i+2]; n++;
      }
      if (n < 10) return null;
      return [Math.round(r/n), Math.round(g/n), Math.round(b/n)];
    } catch (e) { return null; }
  }

  // 西语无印花/纯色关键词（名称命中直接过滤，不调AI）——默认全局版
  var DEFAULT_NO_PRINT_RE = /sin\s*(gr[aá]fico|gr[aá]fica|gr[aá]ficos|gr[aá]ficas|estampado|estampada|estampados|estampadas|print|prints|diseno|dise[nñ]o|dise[nñ]os|impresion|impresión|impresiones)|liso|lisa|lisos|lisas|no\s*prints?|without\s*prints?|no\s*graphic|color\s*(solido|sólido|solida|sólida|solidos|sólidos|sólidas|puro|pura|puros|puras|unicolor|único|unica|únicos|únicas|unico|unica|unicos|unicas)|camiseta\s*de\s*color|camisetas\s*de\s*color|pantal[oó]n\s*de\s*color|pantalones?\s*(cortos|cortas|de\s)*color|pure\s*(color|colors|black|white)|negro\s*(puro|solido|sólido)|negra\s*(pura|solida|sólida)|negros\s*(puros|solidos|sólidos)|negras\s*(puras|sólidas)|blanco\s*(puro|solido|sólido)|blanca\s*(pura|solida|sólida)|blancos\s*(puros|solidos|sólidos)|blancas\s*(puras|sólidas)|gris\s*(puro|solido|sólido)|grises\s*(puros|solidos|sólidos)|solid\s*colors?|plain|unprinted|单色|纯色|无印花|空白版|无图案|空白图|素色|单\s*T恤|单\s*短裤|彩色\s*T恤|彩色\s*短裤|camiseta\s*sol[ai]|camisetas\s*sol[ai]s?|shorts?\s*sol[ai]|shorts?\s*sol[ai]s?/i;
  // 各品类追加的纯色过滤词（在默认基础上额外过滤，不删原词）
  // kids：童装前置名称过滤——白名单内颜色(粉/浅蓝/红)只拦明确纯色后缀以保留其印花款；非白名单彩色(绿/深蓝/黄/橙/紫/棕/杏米色系等)裸词直接过滤。仅 kids 合并进 getNoPrintRe，不影响帆布袋 bag 的合法米色(beige/crema/marfil 由 bag 判色层放行)
  var CAT_EXTRA_NO_PRINT_RE = {
    kids: /\brosas?\s+(sólidas?|solidas?|puras?|lisas?|sin\s+estampado)\b|rosad[oa]s?\s+(sólid[oa]s?|solid[oa]s?|pur[oa]s?|lis[oa]s?|sin\s+estampado)\b|azul\s*(claro|celeste)\s*(sólido|liso)?|rojo\s*sólido|pink\s*solid|light\s*blue\s*solid|red\s*solid|pure\s*pink|pure\s*(light\s*blue|red)|fuchsia|fucsia|lila|purpura|magenta|burdeos|vino|morado|púrpura|purple|naranja|orange|amarillo|yellow|verde|green|azul\s*(oscuro|marino|navy)|dark\s*blue|navy|(?<!light\s)(?<!baby\s)(?<!sky\s)\bblue\b|caf[eé]|marrón|brown|beige|caqui|khaki|albaricoqu[ea]s?|almendr(?:a|o|ad[oa])s?|chabacan[oa]s?|damasc[oa]s?|melocot[oó]n(?:es)?|durazn[oa]s?|apricots?|\bnude\b|crema|marfil|color\s*carne|(?:blanco|color)\s*hueso|gris\s*(oscuro|pizarra)|dark\s*gray|浅蓝.*纯色|粉.*纯色|红.*纯色|粉红.*纯色/i
  };
  function getNoPrintRe(catKey) {
    var extra = CAT_EXTRA_NO_PRINT_RE[catKey];
    if (!extra) return DEFAULT_NO_PRINT_RE;
    // 合并：default.source + extra.source（去掉末尾 /i）
    var merged = DEFAULT_NO_PRINT_RE.source + '|' + extra.source.replace(/\/[gimsuy]*$/, '');
    return new RegExp(merged, 'i');
  }
  // 占位图/提示图/非商品图名称（命中直接过滤，避免像素初筛把白底/黑底提示图误判为T恤）
  var PLACEHOLDER_NAME_RE = /solo\s*(para\s*)?consultas?|仅供咨询|仅咨询|no\s*se\s*env(ía|ia)|不发货|contenido\s*no\s*disponible|ning[uú]n\s*producto|参考图|占位图|示意图|禁用图|禁止图|提示图|not\s*available|coming\s*soon|placeholder|demo\s*image|sample\s*image/i;
  // 混名过滤：名称含颜色词的同时又含品类/款式描述词（如"T恤 黑色""圆领 黑色"）→ 判定为纯色简陋名，直接过滤
  var MIXCAT_NAME_RE = /T恤|t恤|t[- ]?shirt|圆领|连帽|卫衣|hoodie|crewneck|长袖|短袖|短裤|长裤|套装|裤|背心|衬衫|上衣|camiseta|tee\b|cuello|capucha|su[eé]ter|sudera|sudorera|sudadera|pantal[oó]n|shorts?|conjunto|juego|manga|mangas|blusa|top\b/i;
  // 印花描述词：名称含这些词说明是印花款，混名过滤不生效（保护真正的印花款）
  var PRINT_DESC_RE = /estampad|grafic|print|disen|diseñ|印花|图案|花样|字样|骷髅|图形|logo|monogram|pattern|decal|texto/i;
  // 套装名称判定：完整套装名(上衣+短裤 或 含套装词)+允许色→放行；单T/单裤→过滤；纯色无标识→走AI
  function judgeSetName(name, nameColor) {
    var n = String(name == null ? '' : name).toLowerCase();
    var hasTop = /T恤|恤|camiseta|t[ -]?shirt|\btop\b|\bT\b/i.test(n);
    var hasPants = /裤|短裤|short|shorts|pantal[oó]n/i.test(n);
    var hasSetWord = /套装|conjunto|set\b|juego/i.test(n);
    if (hasSetWord || (hasTop && hasPants)) return nameColor ? 'keep' : 'ai';
    if (hasTop || hasPants) return 'skip';
    return 'ai';
  }
  // 非黑/白/灰的其它颜色词（套装只收黑白灰，命中直接过滤，省AI）
  var OTHER_COLOR_RE = /粉|红|蓝|绿|黄|橙|紫|棕|卡其|米|青|彩|guinda|granada|berry|carmesí|crimson|baya|vino|burdeos|bordo|borgoña|burgundy|wine|maroon|granate|rosado|rosada|rosados|rosadas|rosa|rosas|rojo|roja|rojos|rojas|azul|azules|verde|verdes|amarillo|amarilla|amarillos|amarillas|naranja|naranjas|morado|morada|morados|moradas|purpura|marron|beige|caqui|multicolor|pink|pinks|red|reds|blue|blues|green|greens|yellow|yellows|orange|oranges|purple|purples|brown|browns|colorful|\bcolor\b/i;
  // 直接过滤词：名称/颜色含 Felpa(绒布抓绒材质)/playera/camiseta/manga corta → 直接过滤
  var FILTER_NAME_RE = /felpa|felpas|felpado|felpada|felpados|felpadas|felpudo|felpuda|felpudos|felpudas|playera|playeras|camiseta|camisetas|manga\s*corta|mangas\s*cortas/i;
  // 用户自定义/咨询占位图(名称含 Solo consultas 等)：直接采用，不走AI判色
  var CUSTOM_DIRECT_RE = /solo\s*(para\s*)?consultas?|仅供咨询|mi\s*imagen|自定义/i;

  // 全品类通用 SKU 名黑名单：采集混入的非本品类规格(joya/joyas 西语“珠宝首饰”/赠品配件)，名称层直接过滤。
  // 仅作用于采集 SKU 规格名；插件自己写入的 Blanco/Negro/diseño personalizado 等规格名不含该词，不受影响。
  var COMMON_SKU_NAME_BLOCK_RE = /joyas?/i;

  // ===== V26.11.20.11 跨品类名称排他词库（零AI成本；按员工9大上架品类互斥矩阵重做）=====
  // 仅作用于「采集SKU规格名 nit.name」（通常是品类词/颜色/货号，如 una sudadera negra）；
  // 插件写入的输出槽名(Negro/Negro+1/diseño personalizado)与用户手选图(pluginSlot/custom)在本检查之前已豁免，绝不经过这里。
  // 两层判定：
  //  ①rival 对立款式层（仅卫衣两模式：连帽↔圆领）：命中对立款式明确词即过滤，sudadera 这类圆领/连帽共称不豁免；同条含本款式明确词 ownStyle(如 hoodie)时放过（矛盾混合名宁留不误杀）。
  //  ②exclude 跨大类层：命中他品类词候选过滤；若同条含当前模式本品强词 own（童装 infantil、套装 conjunto、CVC 字样、卫衣 sudadera、短裤 shorts 等）则豁免，避免误杀 camiseta infantil / conjunto camiseta+short / playera CVC 交叉命名。
  var FOREIGN_CAT_FAMILIES = {
    cvc: ['\\bcvc\\b'],
    hoodie: ['hoodie', 'hooded\\s+sweatshirt', 'con\\s+capucha', 'capucha'],
    crew: ['crewneck', 'crew\\s+neck\\s+sweatshirt', 'sudadera\\s+(?:de\\s+)?cuello\\s+redondo'],
    sweatGeneral: ['sudadera', 'sudera', 'sudorera', 'sweatshirt'],
    knitOuter: ['su[eé]ter', 'pul[oó]ver', 'j[eé]rsey(?![a-záéíóúüñ])', 'cardigan', 'chamarra', 'chaqueta', 'abrigo', 'chaleco'],
    tshirt: ['(?<![a-záéíóúüñ])t[- ]?shirts?(?![a-z])', '\\btee\\b', 'camiseta', 'playera', 'manga\\s+corta'],
    shorts: ['\\bshorts\\b', 'pantal[oó]n(?:es)?\\s+cortos?', 'bermuda(?:s)?'],
    pantsLong: ['pantal[oó]n(?:es)?', 'sweatpants', 'jogger(?:s)?', 'jogging', 'leggings?', 'jeans?', 'vaquero(?:s)?', 'mezclilla'],
    skirts: ['falda(?:s)?', '\\bskirt\\b'],
    setwear: ['conjunto', '\\bset\\b', 'dos\\s+piezas', '2\\s*piezas', 'two\\s*piece', 'tracksuit', 'chandal', 'set\\s+deportivo', 'set\\s+de\\s+(?:top|camiseta|sudadera|pantal)'],
    kids: ['infantil', 'ni[ñn]o(?:s)?', 'ni[ñn]a(?:s)?', 'beb[eé]', 'toddler', 'kids?', 'children'],
    bagsOther: ['mochila(?:s)?', 'bolso(?:s)?', 'cartera(?:s)?', 'backpack', '\\bbag\\b'],
    caps: ['gorra(?:s)?', 'gorro(?:s)?', 'sombrero(?:s)?', '\\bhat\\b', 'baseball\\s+cap'],
    shoes: ['zapato(?:s)?', 'zapatilla(?:s)?', 'tenis', 'sneaker(?:s)?', 'shoe(?:s)?', 'bota(?:s)?', 'sandalia(?:s)?'],
    underwear: ['sost[eé]n', 'sujetador(?:es)?', '\\bbra\\b', 'calz[oó]n(?:es)?', 'panty(?:s)?', 'bikini(?:s)?', 'boxer(?:s)?', 'ropa\\s+interior', 'traje\\s+de\\s+ba[ñn]o'],
    dress: ['vestido(?:s)?', '\\bdress\\b'],
    accessories: ['calcet(?:i|í)n(?:es)?', 'calceta(?:s)?', 'sock(?:s)?', 'bufanda(?:s)?', 'scarf(?:s)?', 'guante(?:s)?', 'cintur[oó]n(?:es)?', 'cinturon(?:es)?', '\\bbelt\\b', 'reloj(?:es)?', 'lentes', 'gafas']
  };
  // 纯单词自动补 Unicode 字母环视边界（避免 camisa 误匹配 camiseta 这类子串）；含空格/正则结构(反斜杠/括号/管道)的词条原样使用，边界由词条自带
  function foreignWordSrc(w) {
    if (/[\s\\|()?]/.test(w)) return w;
    return '(?<![a-záéíóúüñ])' + w + '(?![a-záéíóúüñ])';
  }
  // 9 大上架品类互斥矩阵（V26.11.20.11 按员工清单）：exclude=跨大类排他族，own=本品强词(命中则豁免exclude)，rival/ownStyle=卫衣对立款式层。
  // 注意：crewneck(纯圆领)按清单不排短裤；top_h(连帽混合)排短裤。sudadera/sweatshirt 是圆领+连帽共称，两卫衣模式都不放进 exclude。
  function foreignModeProfile(catKey, req) {
    catKey = catKey || '';
    if (req === 'bag' || catKey === 'bag') {
      return { exclude: ['tshirt', 'sweatGeneral', 'knitOuter', 'hoodie', 'crew', 'pantsLong', 'shorts', 'skirts', 'setwear', 'kids', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: [] }; // 帆布袋不排 bagsOther，避免误伤 bolsa de lona
    }
    if (catKey === 'cvc') {
      return { exclude: ['hoodie', 'crew', 'sweatGeneral', 'knitOuter', 'tshirt', 'shorts', 'pantsLong', 'skirts', 'setwear', 'kids', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['cvc'] }; // CVC：普通T恤词候选排，名称带 cvc 本品字样豁免
    }
    if (req === 'shorts' || catKey === 'shorts') {
      return { exclude: ['hoodie', 'crew', 'sweatGeneral', 'knitOuter', 'tshirt', 'cvc', 'pantsLong', 'skirts', 'setwear', 'kids', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['shorts'] };
    }
    if (req === 'set' || catKey === 'set') {
      return { exclude: ['hoodie', 'crew', 'sweatGeneral', 'knitOuter', 'tshirt', 'cvc', 'shorts', 'pantsLong', 'skirts', 'kids', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['setwear'] }; // 套装按清单排单件T恤/短裤；名称含 conjunto/set 本品词豁免
    }
    if (req === 'kids' || catKey === 'kids') {
      return { exclude: ['hoodie', 'crew', 'sweatGeneral', 'knitOuter', 'shorts', 'pantsLong', 'skirts', 'setwear', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['kids'] }; // V26.11.20.12 童装按最新清单只排卫衣两类/短裤/套装(+裤裙配饰)；童装T恤与CVC是本品，移除 tshirt/cvc 排他；名称含 infantil/niño 仍豁免交叉命名
    }
    if (req === 'sweatshirt' || catKey === 'top_h' || catKey === 'crewneck') {
      if (catKey === 'crewneck') {
        return { exclude: ['tshirt', 'cvc', 'setwear', 'shorts', 'kids', 'pantsLong', 'skirts', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['crew', 'sweatGeneral'], rival: ['hoodie'], ownStyle: ['crew'] }; // V26.11.20.12 圆领按最新清单排T恤/CVC/套装/短裤/童装/连帽(新增短裤)；rival层另排明确连帽词
      }
      return { exclude: ['tshirt', 'cvc', 'shorts', 'setwear', 'kids', 'pantsLong', 'skirts', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['hoodie', 'sweatGeneral'], rival: ['crew'], ownStyle: ['hoodie'] }; // 连帽混合：排T恤/CVC/短裤/套装/童装/圆领
    }
    if (req === 'top' || catKey === 'top_t') {
      return { exclude: ['sweatGeneral', 'knitOuter', 'hoodie', 'crew', 'pantsLong', 'shorts', 'skirts', 'setwear', 'kids', 'bagsOther', 'caps', 'shoes', 'underwear', 'dress', 'accessories'], own: ['tshirt'] }; // 普通T恤维持 .10 全量排他
    }
    return null; // 油画/未知模式不启用，保持 .8 行为
  }
  function buildForeignCategoryRe(families) {
    if (!families || !families.length) return null;
    var parts = [];
    for (var fi = 0; fi < families.length; fi++) {
      var arr = FOREIGN_CAT_FAMILIES[families[fi]];
      if (!arr) continue;
      for (var fj = 0; fj < arr.length; fj++) parts.push(foreignWordSrc(arr[fj]));
    }
    if (!parts.length) return null;
    return new RegExp(parts.join('|'), 'i');
  }
  // 每款商品构造一次检查器（4 个正则预编译）；循环内调 hit(name) 返回命中词或 ''（豁免/未命中）
  function buildForeignChecker(catKey, req) {
    var p = foreignModeProfile(catKey, req);
    if (!p) return null;
    var excludeRe = buildForeignCategoryRe(p.exclude);
    var ownRe = buildForeignCategoryRe(p.own);
    var rivalRe = buildForeignCategoryRe(p.rival);
    var ownStyleRe = buildForeignCategoryRe(p.ownStyle);
    if (!excludeRe && !rivalRe) return null;
    return {
      hit: function (name) {
        if (!name) return '';
        var s = String(name);
        // ① 对立款式层：命中 rival 且无本款式明确词 → 过滤（sudadera 共称不豁免此层）
        if (rivalRe) {
          var rm = rivalRe.exec(s);
          if (rm && !(ownStyleRe && ownStyleRe.test(s))) return rm[0];
        }
        // ② 跨大类层：命中排他词，但同条含本品强词 → 豁免
        if (excludeRe) {
          var em = excludeRe.exec(s);
          if (em) {
            if (ownRe && ownRe.test(s)) return '';
            return em[0];
          }
        }
        return '';
      }
    };
  }
  // 单测/复用：返回名称中命中的第一个非本品类词；豁免、未命中或模式不启用返回 ''
  function matchForeignCategory(name, catKey, req) {
    var checker = buildForeignChecker(catKey, req);
    return checker ? checker.hit(name) : '';
  }

  // ===== 帆布袋(bag)专用：定制固定槽 / 来源过滤词 / URL去重键 =====
  // 插件写入的「定制」固定规格名（输出槽）。重跑且OSS来源缺失、从模板规格回退读图时按此名精确豁免，绝不能当采集定制词过滤
  var CUSTOM_SKU_NAME = 'diseño personalizado';
  function normSlotName(s) {
    return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
  }
  function isPluginReservedSlotName(s) { return normSlotName(s) === normSlotName(CUSTOM_SKU_NAME); }
  // 来源图URL身份键：去掉query/hash(CDN缩放/签名参数)，同 origin+pathname 视为同一张图；替代旧的平均RGB近似判重(会误杀白底不同印花)
  function sourceUrlKey(u) { try { var x = new URL(String(u)); return x.origin + x.pathname; } catch (e) { return String(u || ''); } }
  // 帆布袋来源SKU名：出现任何非白/米颜色词(含西语阴阳性/单复数与英文) → 直接过滤；白色 blanco/blanca/white、米色 beige/crema 不在内
  var BAG_OTHER_COLOR_RE = /negro|negra|negros|negras|\bblack\b|gris|grises|gray|grey|\bred\b|rojo|roja|rojos|rojas|azul|azules|celeste|marino|navy|\bpink\b|rosa|rosas|rosado|rosada|fucsia|magenta|verde|verdes|green|amarillo|amarilla|amarillos|amarillas|yellow|naranja|naranjas|orange|morado|morada|morados|moradas|purpura|púrpura|lila|violeta|purple|marron|marrón|cafe|café|brown|vino|burdeos|borgoña|burgundy|wine|guinda|dorado|dorada|dorados|\bgold\b|plateado|plateada|silver|multicolor|colorful|黑|灰|红|蓝|粉|绿|(?<!米)黄|橙|紫|棕|咖|青|彩/i;
  // 帆布袋来源SKU名：设计定制相关词，仅用于过滤「采集数据」SKU名；插件自建第二规格 CUSTOM_SKU_NAME 不经过名称判色且模板回退已精确豁免
  var BAG_CUSTOM_WORD_RE = /dise[ñn]o\s*personaliz|dise[ñn]os\s*personaliz|personaliz|custom(ized)?\s*design|custom\s*image|your\s*design|create\s*your\s*own|dise[ñn]a\s*tu|a\s*medida|sublimaci[oó]n|make\s*your\s*own|来图定制|定制|自定义图案|定做|订制|\bdiy\b/i;

  // SKU颜色名称识别——默认全局版（黑/白/灰，所有品类共用）
  var DEFAULT_COLOR_NAME = {
    black: /negro|negra|black|黑色?/,
    white: /blanco|blanca|white|白色?/,
    gray: /gris|gray|grey|灰色?/
  };
  // 判色结果 -> 西语颜色名（用于改写SKU规格名，墨西哥站）
  var ES_COLOR_NAME = { black: 'Negro', white: 'Blanco', gray: 'Gris', lightblue: 'Azul Claro', pink: 'Rosa', red: 'Rojo', beige: 'Beige' };
  function esColorName(color) { return ES_COLOR_NAME[color] || null; }
  // 套装SKU名：上衣色+短裤色（如 Negro+Blanco）；缺分色时退化为整体色
  function esSetSlotName(p) {
    var t = p && p.topColor ? esColorName(p.topColor) : null;
    var b = p && p.bottomColor ? esColorName(p.bottomColor) : null;
    if (t && b) return t + '+' + b;
    return (p && esColorName(p.color)) || '';
  }
  // 同名允许色加序号后缀（Negro -> Negro+1 -> Negro+2）
  function dedupName(name, used) {
    used = used || {};
    if (used[name] == null) used[name] = 0;
    used[name]++;
    return used[name] === 1 ? name : name + '+' + (used[name] - 1);
  }
  // 给一组来源规格槽(对象引用)写西语规格名，slots 与 names 平行。
  // bagSeq=true(帆布袋)：白/米统一命名 Blanco(米色不再写 Beige)；多个来源槽在本组内统一序列
  //   Blanco1/Blanco2… 连续递增(白+米混排也连号，避免规格值重名)，仅1个有效来源槽用裸名 Blanco；
  // bagSeq=false(其他品类)：沿用旧规则——同名组>1时组内依次 名+1/名+2，单张用裸名。
  function applySlotNames(slots, names, bagSeq) {
    slots = slots || []; names = names || [];
    if (bagSeq) {
      var bagTotal = 0, bi;
      for (bi = 0; bi < slots.length; bi++) { if (slots[bi] && names[bi]) bagTotal++; }
      var bagPos = 0;
      for (bi = 0; bi < slots.length; bi++) {
        if (!slots[bi] || !names[bi]) continue;
        bagPos++;
        slots[bi].attrValue = bagTotal > 1 ? ('Blanco' + bagPos) : 'Blanco';
      }
      return;
    }
    var cnt = {}, i, n;
    for (i = 0; i < names.length; i++) { n = names[i]; if (n) cnt[n] = (cnt[n] || 0) + 1; }
    var idx = {};
    for (i = 0; i < slots.length; i++) {
      n = names[i];
      if (!n || !slots[i]) continue;
      if (cnt[n] > 1) {
        idx[n] = (idx[n] || 0) + 1; slots[i].attrValue = n + '+' + idx[n];
      } else { slots[i].attrValue = n; }
    }
  }
  // 自动克隆/补出的新颜色槽(isNew, attrValueId='new_...')必须在 info.skuMap 有对应「颜色×尺码」SKU 行，
  // 否则妙手保存报 “SKU【规格名-尺码】不存在”（V26.11.20.8 修复；机制移植自 V26.10.27.16，增强为自动学习 key 维度顺序）。
  // 直接在传入 skuMap 上补缺失 key（深拷贝正常 SKU 行）；找不到任何样本行时把新槽 id 放 droppableIds，由调用方剔除以防整款保存被打回。
  // opt: {colors:原始颜色槽, validColors:本次保留槽, sizes:尺码值数组, yinliuFirstId:引流盲盒颜色id(选样本跳过), customName:定制规格名(选样本跳过)}
  function ensureClonedSkus(skuMap, opt) {
    opt = opt || {};
    skuMap = skuMap || {};
    var colors = opt.colors || [], validColors = opt.validColors || [], sizes = opt.sizes || [];
    var customName = opt.customName || '';
    var yjId = opt.yinliuFirstId != null ? String(opt.yinliuFirstId) : '';
    var colorIdSet = {}, realColorSlot = {};
    function rememberColor(c) {
      if (c && c.attrValueId != null) {
        colorIdSet[String(c.attrValueId)] = 1;
        if (!c.isNew) realColorSlot[String(c.attrValueId)] = c;
      }
    }
    colors.forEach(rememberColor);
    validColors.forEach(rememberColor);
    var sizeIdSet = {};
    sizes.forEach(function (s) { if (s && s.attrValueId != null) sizeIdSet[String(s.attrValueId)] = 1; });
    function splitKey(k) {
      return String(k == null ? '' : k).replace(/^;+|;+$/g, '').split(';').filter(function (x) { return x !== ''; });
    }

    // 遍历现有 skuMap：①学习 key 中颜色段/尺码段位置；②挑一个正常来源颜色的 SKU 行做深拷贝样本
    var layout = null, sampleKey = null, sampleSku = null;
    var fallbackKey = null, fallbackSku = null, yjKey = null, yjSku = null;
    var allKeys = Object.keys(skuMap), ki, p;
    for (ki = 0; ki < allKeys.length; ki++) {
      var k = allKeys[ki], sk = skuMap[k];
      if (!sk || sk.isDelete === '1') continue;
      var seg = splitKey(k), cPos = -1, sPos = -1;
      for (p = 0; p < seg.length; p++) {
        if (cPos < 0 && colorIdSet[seg[p]]) cPos = p;
        if (sPos < 0 && sizeIdSet[seg[p]]) sPos = p;
      }
      if (!layout && cPos >= 0) {
        layout = {
          colorPos: cPos, sizePos: sPos, segCount: seg.length,
          order: seg.map(function (x) { return colorIdSet[x] ? 'c' : (sizeIdSet[x] ? 's' : '?'); }).join('-')
        };
      }
      if (cPos >= 0) {
        var cid = seg[cPos], slotObj = realColorSlot[cid];
        var isYj = !!(yjId && cid === yjId);
        var isCustom = !!(slotObj && customName && normSlotName(slotObj.attrValue) === normSlotName(customName));
        if (!isYj && !isCustom && slotObj && !sampleKey) { sampleKey = k; sampleSku = sk; }
        if (isYj && !yjKey) { yjKey = k; yjSku = sk; }
      }
      if (!fallbackKey) { fallbackKey = k; fallbackSku = sk; }
    }
    if (!sampleKey && fallbackKey) { sampleKey = fallbackKey; sampleSku = fallbackSku; }
    if (!sampleKey && yjKey) { sampleKey = yjKey; sampleSku = yjSku; }

    var newSlots = validColors.filter(function (c) { return c && c.isNew && c.attrValueId != null; });
    var result = { skuMap: skuMap, added: 0, newSlotCount: newSlots.length, keys: [], droppableIds: [], layout: layout, sampleKey: sampleKey };
    if (!newSlots.length) return result;
    // 无任何现存 SKU 行可复制：不能凭空构造价格/库存结构 → 交调用方剔除新槽，保证原有规格可正常保存
    if (!sampleSku) {
      newSlots.forEach(function (c) { result.droppableIds.push(String(c.attrValueId)); });
      return result;
    }

    var tmplSeg = splitKey(sampleKey);
    var colorPos = layout ? layout.colorPos : 0;
    var sizePos = layout ? layout.sizePos : -1;
    if (!layout) {
      for (p = 0; p < tmplSeg.length; p++) { if (realColorSlot[tmplSeg[p]]) { colorPos = p; break; } }
      layout = result.layout = { colorPos: colorPos, sizePos: -1, segCount: tmplSeg.length, order: 'fallback' };
    }
    var multiDim = tmplSeg.length >= 2;
    if (multiDim && sizePos < 0) {
      for (p = 0; p < tmplSeg.length; p++) { if (p !== colorPos && (!sizes.length || sizeIdSet[tmplSeg[p]])) { sizePos = p; break; } }
      if (sizePos < 0) { for (p = 0; p < tmplSeg.length; p++) { if (p !== colorPos) { sizePos = p; break; } } }
    }
    function putKey(segArr) {
      var key = ';' + segArr.join(';') + ';';
      if (skuMap[key]) return; // 已存在（真实槽/重复补行）不覆盖
      var copy = JSON.parse(JSON.stringify(sampleSku));
      copy.isDelete = '0';
      skuMap[key] = copy;
      result.added++;
      result.keys.push(key);
    }
    newSlots.forEach(function (slot) {
      var nid = String(slot.attrValueId);
      if (!multiDim) {
        // 现有 SKU 就是单维 key（如无尺码帆布袋）：只替换颜色段
        var seg0 = tmplSeg.slice();
        while (seg0.length <= colorPos) seg0.push('');
        seg0[colorPos] = nid;
        putKey(seg0);
      } else if (sizes.length && sizePos >= 0) {
        // 服装颜色×尺码：为新颜色的每个尺码补一行，维度顺序沿用真实 key
        sizes.forEach(function (sz) {
          if (!sz || sz.attrValueId == null) return;
          var seg = tmplSeg.slice();
          while (seg.length <= Math.max(colorPos, sizePos)) seg.push('');
          seg[colorPos] = nid;
          seg[sizePos] = String(sz.attrValueId);
          putKey(seg);
        });
      } else {
        // 多段 key 但尺码维度无法识别/无尺码列表：保留模板非颜色段原值，每个新槽补一行保底
        var seg1 = tmplSeg.slice();
        while (seg1.length <= colorPos) seg1.push('');
        seg1[colorPos] = nid;
        putKey(seg1);
      }
    });
    return result;
  }
  // 各品类追加识别的颜色（在默认黑/白/灰基础上追加，不删原词）
  // kids：额外认浅蓝/粉/红
  var CAT_COLOR_NAME_EXTRA = {
    kids: {
      lightblue: /azul\s*claro|celeste|light\s*blue|baby\s*blue|sky\s*blue|浅蓝色?/,
      pink: /\brosas?\b|rosad[oa]s?|\bpinks?\b|fuchsia|magenta|hot\s*pink|粉红色?|粉色/,
      red: /rojo|roja|red|红色?/
    },
    // 帆布袋：在默认黑/白/灰之外追加米色（白色已由DEFAULT_COLOR_NAME.white识别；含white/白的米白/奶白会先命中white，同样放行）
    bag: {
      beige: /beige|beiges|crema|color\s*crema|marfil|ivory|hueso|浅米|米色|米黄|杏色|象牙色?/
    }
  };
  function judgeColorByName(name, catKey) {
    if (!name) return null;
    var n = String(name).toLowerCase();
    var table = {};
    // 合并默认 + 品类追加
    for (var k in DEFAULT_COLOR_NAME) table[k] = DEFAULT_COLOR_NAME[k];
    if (catKey && CAT_COLOR_NAME_EXTRA[catKey]) {
      for (var k2 in CAT_COLOR_NAME_EXTRA[catKey]) table[k2] = CAT_COLOR_NAME_EXTRA[catKey][k2];
    }
    for (var color in table) {
      if (table[color].test(n)) return color;
    }
    return null;
  }

  // 并发控制：同时最多 limit 个 worker 执行，保持输入顺序返回结果
  async function runConcurrent(items, limit, worker) {
    var results = new Array(items.length);
    var idx = 0;
    async function runner() {
      while (idx < items.length) {
        var cur = idx++;
        results[cur] = await worker(items[cur], cur);
      }
    }
    var n = Math.max(1, Math.min(limit, items.length));
    var runners = [];
    for (var ri = 0; ri < n; ri++) runners.push(runner());
    await Promise.all(runners);
    return results;
  }

  // 批量判色：名称→像素→AI三级。opts={colors, category, useAIOnly}
  async function aiFilterSourceList(list, opts) {
    opts = opts || {};
    var allowColors = opts.colors || ['black', 'white'];
    var requireCategory = opts.category || null;
    var useAIOnly = opts.useAIOnly === true;
    var catKey = opts.catKey || null;
    var noPrintRe = getNoPrintRe(catKey);
    // V26.11.20.11 当前模式的跨品类排他检查器（名称层零AI过滤；油画等无品类模式为 null 不启用）
    var foreignChecker = buildForeignChecker(catKey, requireCategory);
    // 第一步：名称判色——无印花词过滤，占位图过滤，颜色词直接通过（认定有印花）
    var nameFiltered = [];
    for (var ni = 0; ni < list.length; ni++) {
      var nit = list[ni];
      // 插件自建固定槽(重跑时模板回退读到)：直接采用，不被采集定制词/颜色词过滤
      if (nit.pluginSlot) {
        nameFiltered.push({ it: nit, r: { color: (allowColors[0] || 'white'), category: (requireCategory === 'bag' ? 'bag' : 'tshirt'), hasPrint: true, isDetail: false, custom: true, nameJudge: true, pluginSlot: true }, done: true });
        continue;
      }
      // V26.11.20.11 跨品类词库：名称含当前模式“非本品”的明确品类词（如T恤模式出现 una sudadera/hoodie/pantalon/gorra）→ 名称层直接过滤，不进像素/AI，零成本；交叉命名含本品强词时 checker 内部豁免
      if (foreignChecker && nit.name) {
        var fhit = foreignChecker.hit(String(nit.name));
        if (fhit) {
          nameFiltered.push({ it: nit, r: null, nameSkip: true, skipReason: '非本品类词(' + fhit + ')[过滤]' });
          continue;
        }
      }
      // 全品类通用无关 SKU 名(joya/joyas 珠宝首饰等) → 名称层直接过滤(服装/帆布袋 普通+引流 都经此)，不进AI
      if (nit.name && COMMON_SKU_NAME_BLOCK_RE.test(nit.name)) {
        nameFiltered.push({ it: nit, r: null, nameSkip: true, skipReason: '无关品类词(joyas等)[过滤]' });
        continue;
      }
      // 帆布袋：采集SKU名含设计定制相关词 → 直接过滤（仅限采集数据；插件第二规格 diseño personalizado 不走名称判色，模板回退也已豁免）
      if (catKey === 'bag' && nit.name && BAG_CUSTOM_WORD_RE.test(nit.name)) {
        nameFiltered.push({ it: nit, r: null, nameSkip: true });
        continue;
      }
      // 帆布袋：名称含白/米以外颜色词(含西语阴阳单复数) → 直接过滤不进AI，防AI把彩色袋误判成白/米放行
      if (catKey === 'bag' && nit.name && BAG_OTHER_COLOR_RE.test(nit.name)) {
        nameFiltered.push({ it: nit, r: null, nameSkip: true });
        continue;
      }
      if (nit.name && PLACEHOLDER_NAME_RE.test(nit.name)) {
        // 占位/参考图（Solo consulta/仅咨询/不发货）→ 直接过滤，不上架
        nameFiltered.push({ it: nit, r: null, nameSkip: true });
      } else if (nit.name && CUSTOM_DIRECT_RE.test(nit.name)) {
        // 用户自定义图直接采用，不判色
        nameFiltered.push({ it: nit, r: { color: (allowColors[0] || 'black'), category: (requireCategory === 'set' ? 'set' : requireCategory === 'kids' ? 'kids' : requireCategory === 'bag' ? 'bag' : requireCategory === 'top' ? 'tshirt' : 'hoodie'), hasPrint: true, isDetail: false, custom: true, nameJudge: true }, done: true });
      } else if (catKey !== 'set' && nit.name && (noPrintRe.test(nit.name) || FILTER_NAME_RE.test(nit.name))) {
        nameFiltered.push({ it: nit, r: null, nameSkip: true });
      } else {
        if (catKey === 'set' && !useAIOnly) {
          // 套装名称含无印花词(blanco sin estampado / no print / liso 等) → 直接过滤，不进AI
          if (nit.name && noPrintRe.test(nit.name)) {
            nameFiltered.push({ it: nit, r: null, nameSkip: true });
          } else {
          var setColor = judgeColorByName(nit.name, 'set');
          var setJudge = judgeSetName(nit.name, setColor);
          // 1. 单T/单裤（无套装词、无上衣+裤组合）→ 直接过滤，不进AI
          if (setJudge === 'skip') {
            nameFiltered.push({ it: nit, r: null, nameSkip: true });
          }
          // 2. 含其它颜色词（非黑/白/灰）→ 直接过滤，哪怕同时含黑白灰词
          else if (OTHER_COLOR_RE.test(nit.name)) {
            nameFiltered.push({ it: nit, r: null, nameSkip: true });
          }
          // 3. 套装 + 黑/白/灰颜色词 → 锁定颜色，进像素判印花，判不出进AI
          else if (setJudge === 'keep') {
            nameFiltered.push({ it: nit, r: null, forceColor: setColor });
          }
          // 4. 套装无颜色词 / 名称无品类词 → 走AI
          else {
            nameFiltered.push({ it: nit, r: null, forceColor: null });
          }
          }
        } else {
          var nameColor = judgeColorByName(nit.name, catKey);
          if (nameColor && !useAIOnly) {
            // 名称命中颜色词但同时含品类/款式词且不含印花描述（如"T恤 黑色"）→ 纯色混名直接过滤
            if (MIXCAT_NAME_RE.test(nit.name) && !PRINT_DESC_RE.test(nit.name)) {
              nameFiltered.push({ it: nit, r: null, nameSkip: true });
            } else if (!PRINT_DESC_RE.test(nit.name) && (catKey === 'kids' || catKey === 'crewneck' || catKey === 'top_h' || catKey === 'top_t' || catKey === 'shorts' || catKey === 'cvc' || catKey === 'bag') && nit.name.replace(/(black|white|gray|grey|negro|negra|blanco|blanca|gris|rosa|rosas|rosado|rosados|rosada|rosadas|rojo|roja|azul\s*claro|celeste|黑色|白色|灰色|黑|白|灰|浅蓝|粉|红|beige|beiges|crema|marfil|ivory|米色|米黄|杏色)/ig, '').replace(/[\s,，.\-·\/]/g, '') !== '') {
              // 上衣类(圆领/连帽/T恤/CVC)与短裤：颜色词+额外词/数字（如“Negro 1”）→ 进AI判印花，过滤纯色/无印花图；纯颜色词直接放行
              nameFiltered.push({ it: nit, r: null, forceColor: nameColor });
            } else {
              // 纯颜色词（如“黑色”）或名称含印花描述：直接通过
              nameFiltered.push({ it: nit, r: { color: nameColor, category: 'tshirt', hasPrint: true, isDetail: false, nameJudge: true }, done: true });
            }
          } else if (!useAIOnly && OTHER_COLOR_RE.test(nit.name)) {
            // 名称命中非允许彩色词（verde/Azul/Rosa/RED/vino等）→ 直接过滤，不进AI判色（防AI误判成黑保留）
            nameFiltered.push({ it: nit, r: null, nameSkip: true });
          } else {
            nameFiltered.push({ it: nit, r: null, forceColor: useAIOnly ? null : nameColor });
          }
        }
      }
    }
    // 第二步：逐张判定——每张来源图都先本地像素快筛(不调AI)，像素判不出(null)再进AI精判。
    // 不再因“已有一张通过”短路后续图：旧 quickPass 会把同一链接内多个不同印花 SKU 整批标成“省AI跳过”、不进选池，导致大量印花丢失。
    // 并发限制2：像素为本地计算；仅像素不足时才打AI，避免多张同时请求触发限流/超时。
    var aiCalled = false;
    var results = await runConcurrent(nameFiltered, 2, function (nf) {
      if (nf.nameSkip || nf.done) return nf;
      var it = nf.it;
      if (!it.url) return { it: it, r: null, noImg: true };
      return pixelQuickJudge(it.url, requireCategory === 'set', it.name).then(function (quick) {
        // 像素判出结果即采用（不进AI，控成本）；判不出(null)才进AI精判（分色+袖长）
        if (quick) {
          if (nf.forceColor) quick.color = nf.forceColor;
          return { it: it, r: quick, placeholderName: nf.placeholderName, forceColor: nf.forceColor };
        }
        aiCalled = true;
        // 套装进AI时跳过内部像素（外层已判过），直接调AI
        return aiJudgeColor(it.url, requireCategory === 'set', nf.forceColor || null).then(function (r) { return { it: it, r: r, placeholderName: nf.placeholderName, forceColor: nf.forceColor }; });
      });
    });
    var pool = [], detail = [], seenUrlKeys = {};
    for (var i = 0; i < results.length; i++) {
      var it = results[i].it;
      if (results[i].nameSkip) { detail.push((it.name || '?') + ':' + (results[i].skipReason || '无印花(名称)[过滤]')); continue; }
      if (results[i].noImg) { detail.push((it.name || '?') + ':无图'); continue; }
      var r = results[i].r;
      if (!r) { detail.push((it.name || '?') + ':判色无结果(像素/AI均未给出)[过滤]'); continue; }
      // 品类容错：上衣/套装模式下，AI偶把有印花服装误判为other，自动修正
      // 卫衣模式不做容错（避免把T恤图误判成卫衣）
      if ((requireCategory === 'top' || requireCategory === 'clothing') && r.category === 'other'
          && r.hasPrint && !r.isDetail && !r.quick && !r.nameJudge) {
        r.category = 'tshirt';
        r.categoryFixed = true;
      }
      // 帆布袋模式：进入判色的已是bag商品，AI偶把白色印花帆布袋判other，有印花+非细节图 → 修正为bag（颜色仍须为white才保留）
      if (requireCategory === 'bag' && r.category === 'other'
          && r.hasPrint && !r.isDetail && !r.quick && !r.nameJudge) {
        r.category = 'bag';
        r.categoryFixed = true;
      }
      // 套装模式：AI偶把套装图判成tshirt，要求多件套(上衣+短裤同时展示)+有印花 → 修正为set
      // 白款补充：AI未判isMultiPack但bottom_color给出黑白灰(说明同框有短裤)且非长裤 → 同样修正为set
      // 单T图AI的bottom_color为other，不会被误放行
      if (requireCategory === 'set' && r.category === 'tshirt'
          && r.hasPrint && !r.isDetail && !r.quick && !r.nameJudge && !r.isLongPants
          && (r.isMultiPack || (r.bottomColor && r.bottomColor !== 'other'))) {
        r.category = 'set';
        r.categoryFixed = true;
      }
      // AI判其它颜色(彩色)但有印花+服装品类 → 用像素验证主体是否真黑(黑底彩色印花/深色误判)：
      // 近黑→按黑处理保留；真彩色(酒红/藏蓝/绿等)→保持other→过滤，不上彩色
      var KNOWN_COLORS = ['black', 'white', 'gray', 'lightblue', 'pink', 'red'];
      if ((requireCategory === 'top' || requireCategory === 'sweatshirt' || requireCategory === 'clothing' || requireCategory === 'set')
          && !KNOWN_COLORS.includes(r.color) && r.hasPrint && !r.isDetail
          && (r.category === 'tshirt' || r.category === 'hoodie' || r.category === 'crewneck'
              || r.category === 'shorts' || r.category === 'set')) {
        var nearBlackC = false, nearWhiteC = false;
        if (it.url) {
          try {
            var cbBmp = await fetchImageBitmap(it.url);
            if (cbBmp) {
              var cbCv = document.createElement('canvas'); cbCv.width = 32; cbCv.height = 32;
              var cbCtx = cbCv.getContext('2d');
              var cbw = cbBmp.width, cbh = cbBmp.height;
              var cbsx = cbw * 0.25, cbsy = cbh * 0.25, cbsw = cbw * 0.5, cbsh = cbh * 0.5;
              cbCtx.drawImage(cbBmp, cbsx, cbsy, cbsw, cbsh, 0, 0, 32, 32);
              var cbd = cbCtx.getImageData(0, 0, 32, 32).data;
              var cbb = 0, cbr = 0, cbg = 0, cbb2 = 0, cbWhite = 0;
              for (var cbi = 0; cbi < cbd.length; cbi += 4) {
                var cbR = cbd[cbi], cbG = cbd[cbi+1], cbB = cbd[cbi+2];
                if (cbR > 235 && cbG > 235 && cbB > 235) continue;
                var cbL0 = 0.299*cbR + 0.587*cbG + 0.114*cbB;
                var cbSat0 = Math.max(cbR, cbG, cbB) - Math.min(cbR, cbG, cbB);
                // 近白中性像素（白衣受光影影响常落在160~235，纯白背景已在上面跳过）
                if (requireCategory === 'set' && cbL0 > 160 && cbSat0 < 45) cbWhite++;
                cbb++; cbr += cbR; cbg += cbG; cbb2 += cbB;
              }
              if (cbb > 20) {
                var cbaR = cbr / cbb, cbaG = cbg / cbb, cbaB = cbb2 / cbb;
                var cbL = 0.299*cbaR + 0.587*cbaG + 0.114*cbaB;
                var cbMx = Math.max(cbaR, cbaG, cbaB), cbMn = Math.min(cbaR, cbaG, cbaB);
                if (cbL < 90 && (cbMx - cbMn) < 40) nearBlackC = true;
                // 套装近白（白上衣+黑短裤，AI判other）→ 修正为white：均值近白，或近白中性像素占比≥35%
                if (requireCategory === 'set' && ((cbL > 160 && (cbMx - cbMn) < 45) || (cbWhite / cbb) >= 0.35)) nearWhiteC = true;
              }
            }
          } catch (e) {}
        }
        if (nearBlackC) { r.color = 'black'; r.colorFixed = true; }
        if (nearWhiteC) { r.color = 'white'; r.colorFixed = true; }
        // 套装AI整体色判other但已分出白上衣+黑白灰短裤 → 直接按白上衣修正white（彩色短裤bottomColor=other不放行）
        if (requireCategory === 'set' && r.topColor === 'white' && r.bottomColor && r.bottomColor !== 'other') {
          r.color = 'white'; r.colorFixed = true;
        }
      }
      var ct = r.color === 'black' ? '黑' : r.color === 'white' ? '白' : r.color === 'gray' ? '灰' : r.color === 'lightblue' ? '浅蓝' : r.color === 'pink' ? '粉红' : r.color === 'red' ? '红' : r.color === 'beige' ? '米' : '其他';
      var cat = r.category === 'tshirt' ? 'T恤' : r.category === 'hoodie' ? '连帽卫衣' : r.category === 'crewneck' ? '圆领卫衣' : r.category === 'shorts' ? '短裤' : r.category === 'set' ? '套装' : r.category === 'kids' ? '童装' : r.category === 'bag' ? '帆布袋' : '其他';
      var fl = [];
      if (r.hasPrint) fl.push('有印花'); else fl.push('无印花');
      if (r.isDetail) fl.push('细节图');
      if (r.isMultiPack) fl.push('多件套');
      if (requireCategory === 'set' && r.isLongSleeve) fl.push('长袖');
      if (requireCategory === 'set' && r.isLongPants) fl.push('长裤');
      if (r.categoryFixed) fl.push('品类修正');
      if (r.blueFixed) fl.push('蓝修正');
      if (r.colorFixed) fl.push('颜色修正');
      if (results[i].placeholderName) fl.push('占位图名');
      if (r.custom) fl.push('自定义');
      if (r.quick) fl.push('像素');
      if (r.fallback) fl.push('像素兜底');
      if (r.nameJudge) fl.push('名称');
      else if (results[i].forceColor) fl.push('名称判色');
      var colorOk = allowColors.indexOf(r.color) >= 0;
      // 像素验色只做日志记录，不过滤（完全信任AI颜色判断，避免误杀有印花的黑/白T恤）
      if (colorOk && !r.quick && !r.nameJudge && !r.fallback && it.url) {
        var avgVerify = await getAvgColor(it.url);
        if (avgVerify) {
          var avgL = 0.299*avgVerify[0] + 0.587*avgVerify[1] + 0.114*avgVerify[2];
          if ((r.color === 'black' && avgL > 150) || (r.color === 'white' && avgL < 80)) {
            fl.push('像素验色存疑(以AI为准)');
          }
        }
      }
      // 名称/像素结果无法判断品类，放宽品类过滤；AI精判结果严格检查品类
      // requireCategory='top' 时 tshirt/hoodie/crewneck 都算通过
      function catPass(req, c) {
        if (!req) return true;
        if (req === 'top') return c === 'tshirt'; // T恤/CVC模式只收短袖T恤，长袖款(hoodie/crewneck)过滤
        if (req === 'sweatshirt') return c === 'hoodie' || c === 'crewneck';
        if (req === 'clothing') return c === 'tshirt' || c === 'hoodie' || c === 'crewneck' || c === 'shorts' || c === 'set';
        if (req === 'kids') return c === 'kids' || c === 'tshirt'; // 童装只收短袖T恤，长袖款(hoodie/crewneck)过滤
        if (req === 'bag') return c === 'bag'; // 帆布袋只收bag
        return c === req;
      }
      var catOk = !requireCategory || r.quick || r.nameJudge || results[i].forceColor || catPass(requireCategory, r.category);
      // 套装(clothing/set)模式 isMultiPack 不过滤（套装图本来就是上衣+短裤一起展示）
      var multiOk = (requireCategory === 'clothing' || requireCategory === 'set') ? true : !r.isMultiPack; // 多件套恢复过滤(正反面同款不算,AI判isMultiPack过滤真多件套)
      // 套装只收短袖+短裤：长袖上衣或长裤下装 → 过滤
      var sleeveOk = requireCategory !== 'set' || (!r.isLongSleeve && !r.isLongPants);
      var keep = colorOk && catOk && r.hasPrint && !r.isDetail && multiOk && sleeveOk;
      // 严格去重：仅按来源URL身份(origin+pathname，忽略CDN缩放/签名query)判同图；不再用整图平均RGB近似——
      // 白/米色布底上的不同色印花整图均值可能极接近，旧逻辑(RGB差<5)会误杀允许色下的不同印花
      if (keep) {
        var urlKey = sourceUrlKey(it.url);
        if (urlKey && seenUrlKeys[urlKey]) {
          detail.push((it.name || '?') + ':' + ct + '/' + cat + '(' + fl.join('/') + ')[重复图URL去重]');
          continue;
        }
        if (urlKey) seenUrlKeys[urlKey] = 1;
      }
      detail.push((it.name || '?') + ':' + ct + '/' + cat + '(' + fl.join('/') + ')' + (keep ? '' : '[过滤]'));
      log('  ⏳ 判色: ' + (it.name || '?') + ' → ' + ct + '/' + cat + '(' + fl.join('/') + ')' + (keep ? ' [留]' : ' [过滤]'));
      if (keep) pool.push({ url: it.url, color: r.color, topColor: r.topColor || null, bottomColor: r.bottomColor || null });
    }
    return { pool: pool, detail: detail, aiCalled: aiCalled };
  }

  async function judgeColorByImage(url) {
    try {
      var bmp = await fetchImageBitmap(url);
      if (!bmp) return null;
      var cv = document.createElement('canvas');
      cv.width = 64; cv.height = 64;
      var ctx = cv.getContext('2d');
      var cw2 = bmp.width, ch2 = bmp.height;
      ctx.drawImage(bmp, cw2*0.25, ch2*0.25, cw2*0.5, ch2*0.5, 0, 0, 64, 64);
      var d = ctx.getImageData(0, 0, 64, 64).data;
      var body = 0, darkGray = 0, lightGray = 0, colorPx = 0;
      var lSum = 0, lSum2 = 0; // 亮度和、亮度平方和（用于算方差）
      for (var i = 0; i < d.length; i += 4) {
        var R = d[i], G = d[i + 1], B = d[i + 2];
        if (R > 235 && G > 235 && B > 235) continue; // 去白背景
        body++;
        var L = 0.299 * R + 0.587 * G + 0.114 * B;
        lSum += L;
        lSum2 += L * L;
        var sat = Math.max(R, G, B) - Math.min(R, G, B);
        if (sat < 30) { // 低饱和=衣服底色
          if (L < 95) darkGray++;
          if (L > 145) lightGray++;
        } else {
          colorPx++; // 彩色像素=印花/图案
        }
      }
      if (body < 50) return null;
      var avgL = lSum / body;
      var varL = lSum2 / body - avgL * avgL;
      // 灰色过滤
      if (avgL >= 100 && avgL <= 150) return null;
      // 印花判断：方差>600 或 彩色像素>8% 才算有印花（褶皱阴影方差通常<600）
      var hasPrint = (varL > 600) || (colorPx / body > 0.08);
      // 判黑
      if (avgL < 100 && darkGray / body >= 0.15) return { color: 'black', hasPrint: hasPrint };
      // 判白
      if (avgL > 150 && lightGray / body >= 0.20) return { color: 'white', hasPrint: hasPrint };
      return null;
    } catch (e) { return null; }
  }

  // ---------------- API 层 ----------------
  // MX T恤默认商品主图（8张，面板不填时自动用；要换直接改这里）
  var MX_DEFAULT_MAIN_IMGS = ['https://earth-rt.chengji-inc.com/picture/1337319/2026-10-08/8223e1dc-af19-4c07-9153-983b11fdd891.png',
  ];

  async function apiPost(path, params, timeoutMs) {
    var body = new URLSearchParams();
    Object.keys(params || {}).forEach(function (k) { body.append(k, params[k]); });
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, timeoutMs || 25000);
    var resp, text;
    try {
      resp = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
        credentials: 'include', signal: ctrl.signal,
        body: body.toString()
      });
      text = await resp.text();
    } catch (e) {
      clearTimeout(timer);
      return { result: 'fail', reason: (e.name === 'AbortError' ? '请求超时' : '网络失败') + ':' + path.split('/').pop() };
    }
    clearTimeout(timer);
    try { return JSON.parse(text); } catch (e) { return { result: 'fail', reason: '非JSON响应: ' + text.slice(0, 120) }; }
  }

  async function apiSave(info, ossMd5, site, retry) {
    var body = 'shopCollectItemInfo=' + encodeURIComponent(JSON.stringify(info));
    if (ossMd5) body += '&ossMd5=' + encodeURIComponent(ossMd5);
    if (site) body += '&site=' + encodeURIComponent(site);
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, 30000);
    try {
      var resp = await fetch(API.save, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
        credentials: 'include', signal: ctrl.signal,
        body: body
      });
      clearTimeout(timer);
      var text = await resp.text();
      try { return JSON.parse(text); } catch (e) { return { result: 'fail', reason: '保存非JSON响应' }; }
    } catch (e) {
      clearTimeout(timer);
      // 网络失败/超时：重试1次
      if (!retry) {
        log('  保存网络异常(' + (e.name === 'AbortError' ? '超时' : '断网') + ')，3秒后重试…', 'warn');
        await sleep(3000);
        return apiSave(info, ossMd5, site, true);
      }
      return { result: 'fail', reason: '保存网络失败: ' + (e.name === 'AbortError' ? '超时30s' : 'Failed to fetch') };
    }
  }

  async function fetchOssJson(dataPath) {
    try {
      var ctrl = new AbortController();
      var timer = setTimeout(function () { ctrl.abort(); }, 15000);
      var resp = await fetch(OSS_BASE + dataPath, { credentials: 'include', signal: ctrl.signal });
      clearTimeout(timer);
      if (resp.ok) return await resp.json();
    } catch (e) { }
    return null;
  }

  // ---------------- 全局状态 ----------------
  var running = false, abortFlag = false;
  var appAccountIdCache = null;

  async function getAppAccountId() {
    if (appAccountIdCache) return appAccountIdCache;
    var fp = await apiPost(API.search, {
      pageNo: '1', pageSize: '1', status: 'notPublished',
      claimPublishShopStatus: 'published', remarkType: 'multi', titleType: 'multi'
    });
    var si = first(fp.detailList || []);
    appAccountIdCache = si && si.appAccountId ? String(si.appAccountId) : '';
    return appAccountIdCache;
  }

  // 扫描采集箱商品聚合人员名单（新版页面无人员筛选框，不能用DOM读取）
  async function loadOwnersFromApi(onProgress) {
    var map = {}, scanned = 0, noSid = 0, totalPages = 0;
    var appAid = await getAppAccountId();
    for (var pg = 1; pg <= 40; pg++) {
      var sr = await apiPost(API.search, {
        pageNo: String(pg), pageSize: '50',
        status: 'notPublished',
        remarkType: 'multi', titleType: 'multi'
      });
      if (pg === 1) {
        var tv = Number(sr.total || 0);
        if (tv > 0) totalPages = Math.min(40, Math.ceil(tv / 50));
      }
      var items = sr.detailList || [];
      if (!items.length) break;
      scanned += items.length;
      items.forEach(function (it) {
        var sid = it.subAppAccountId ? String(it.subAppAccountId) : '';
        var name = it.ownerSubAccountAliasName || it.subAppAccountAliasName || it.ownerSubAccountName || it.subAppAccountName || it.ownerAliasName || '';
        if (!sid) { noSid++; return; }              // 无子账号ID：无法按人筛选，只能跳过
        if (!name || name === '主账号') return;
        if (!map[sid]) map[sid] = name;
      });
      if (onProgress) onProgress(pg, totalPages, Object.keys(map).length);
      // 按 total 决定翻到第几页，不再因为“本页没有新面孔”就提前停
      if (totalPages ? pg >= totalPages : items.length < 50) break;
    }
    var list = [{ id: 'main_' + appAid, name: '主账号', isMain: true }];
    Object.keys(map).forEach(function (sid) { list.push({ id: sid, name: map[sid] }); });
    for (var i = 0; i < list.length; i++) {
      var p = { pageNo: '1', pageSize: '1', status: 'notPublished', claimPublishShopStatus: 'published', remarkType: 'multi', titleType: 'multi' };
      p['ownerAccountIds[0]'] = list[i].id;
      try { var c = await apiPost(API.search, p); list[i].total = c.total || 0; } catch (e) { list[i].total = 0; }
    }
    var pagesDone = Math.max(1, Math.ceil(scanned / 50));
    log('人员扫描：翻 ' + pagesDone + ' 页、共 ' + scanned + ' 个未发布商品，识别 ' + (list.length - 1) + ' 个子账号' +
      (noSid ? '（另有 ' + noSid + ' 个商品没带子账号ID，无法按人筛选，已跳过）' : ''), 'ok');
    var ownNames = list.slice(1).map(function (o) { return o.name + ':' + (o.total || 0); }).join('，');
    if (ownNames) log('各子账号未发布数量 → ' + ownNames, 'ok');
    var zeroOwn = list.slice(1).filter(function (o) { return !o.total; });
    if (zeroOwn.length) log('提示：' + zeroOwn.map(function (o) { return o.name; }).join('、') + ' 统计为 0，可能这些人的商品已全部发布，或当前列表没加载到他们的数据', 'warn');
    return list;
  }

  // ================= UI =================
  var panel, logEl, progressBar, curText, statText;
  var catBoxes, smodeRadios, genderRadios, countInput, ownerSelect, yinliuInput, customChk, customInput, singleChk, brandBoxInput, mximgInput, btnStart, btnStop, btnLoadOwner, pubShopSelect, btnLoadShop;

  function buildPanel() {
    if (document.getElementById('mskb-panel')) return;
    panel = document.createElement('div');
    panel.id = 'mskb-panel';
    panel.innerHTML =
      '<div id="mskb-header"><span>🛠 妙手上架助手 <small id="mskb-ver">' + PLUGIN_VERSION + '</small></span>' +
      '<span id="mskb-min" style="cursor:pointer">—</span></div>' +
      '<div id="mskb-body">' +
      '<div id="mskb-updbar" style="display:none;align-items:center;gap:6px;border:1px solid #f0c36d;background:#fff8e5;border-radius:7px;padding:6px 8px;margin:0 0 7px;font-size:11.5px;color:#8a5a00">' +
      '<span id="mskb-updtext" style="flex:1;line-height:1.5">发现新版本</span>' +
      '<button id="mskb-updbtn" class="mskb-btn mskb-green" type="button" style="padding:4px 10px;font-size:11.5px;flex:0 0 auto">立即更新</button>' +
      '</div>' +
      '<div id="mskb-lic" style="border:1px solid #d9e2e8;border-radius:8px;padding:7px 9px;margin:0 0 7px;background:#f7fbfd">' +
      '<div style="display:flex;align-items:center;gap:6px;font-size:11.5px"><b>授权</b><span id="mskb-lic-status" style="color:#c0392b">未授权 / 已失效</span>' +
      '<button id="mskb-lic-toggle" class="mskb-mini" type="button" style="margin-left:auto">展开</button></div>' +
      '<div id="mskb-lic-body" style="display:none;margin-top:6px">' +
      '<div style="font-size:10.5px;color:#666;line-height:1.5;margin-bottom:3px">本机机器码（发给管理员换授权码，一机一码）：</div>' +
      '<div style="display:flex;gap:4px;align-items:center"><input id="mskb-mcode" readonly spellcheck="false" style="flex:1;font-size:11px;padding:5px 6px;border:1px solid #ccc;border-radius:6px;background:#fff;box-sizing:border-box">' +
      '<button id="mskb-mcopy" class="mskb-mini" type="button">复制</button></div>' +
      '<textarea id="mskb-licinput" spellcheck="false" rows="3" placeholder="粘贴管理员给你的授权码（MSKB1.载荷.签名）" style="width:100%;font-size:11px;margin-top:6px;padding:5px;box-sizing:border-box;border:1px solid #ccc;border-radius:6px;resize:vertical"></textarea>' +
      '<div style="display:flex;gap:6px;margin-top:6px"><button id="mskb-licact" class="mskb-btn mskb-green" type="button" style="flex:1">激活</button>' +
      '<button id="mskb-licclear" class="mskb-btn mskb-gray" type="button">注销</button></div>' +
      '<div id="mskb-lic-tip" style="font-size:10.5px;color:#888;line-height:1.5;margin-top:5px">授权绑定本机机器码与有效期，换电脑需重新领取；未授权时「开始处理」会被拦截。</div>' +
      '</div></div>' +
      '<div class="mskb-row" style="align-items:flex-start;margin-bottom:6px"><label style="white-space:nowrap;font-size:12px;min-width:48px;flex:0 0 auto;padding-top:4px">品类：</label>' +
      '<div style="flex:1;display:flex;flex-wrap:wrap;gap:6px">' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="canvas" checked> 油画</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="bag"> 帆布袋(白/米)</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="top_t"> T恤</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="top_h"> 连帽卫衣</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="top_c"> 圆领卫衣</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="shorts"> 短裤</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="set"> T恤短裤套装</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="kids"> 童装</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-cat" value="cvc"> T恤CVC</label>' +
      '</div></div>' +
      '<div class="mskb-row" style="align-items:flex-start;margin-bottom:6px"><label style="white-space:nowrap;font-size:12px;min-width:48px;flex:0 0 auto;padding-top:4px">款式：</label>' +
      '<div style="flex:1;display:flex;flex-wrap:wrap;gap:6px">' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-gender" value="unisex" checked> 通用</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-gender" value="male"> 男款</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-gender" value="female"> 女款</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-gender" value="boy"> 男童</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-gender" value="girl"> 女童</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-gender" value="mixed"> 男女混合</label>' +
      '</div></div>' +
      '<div class="mskb-row" style="align-items:flex-start;margin-bottom:6px"><label style="white-space:nowrap;font-size:12px;min-width:48px;flex:0 0 auto;padding-top:4px">模式：</label>' +
      '<div style="flex:1;display:flex;flex-wrap:wrap;gap:6px">' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-smode" value="normal" checked> 普通模式</label>' +
      '<label class="mskb-opt mskb-tk"><input type="radio" name="mskb-smode" value="yinliu"> 引流</label>' +
      '<label class="mskb-opt mskb-tk" title="可与引流同时勾选：引流锁第1规格，定制图锁第2规格并命名 diseño personalizado"><input type="checkbox" id="mskb-custom" name="mskb-custom"> 定制</label>' +
      '<label class="mskb-opt mskb-tk" title="只采集到主图、商品没有细节图时勾选：必须在「主图链接」填细节图直链，留空不发布；可与引流/定制同时勾选"><input type="checkbox" id="mskb-single" name="mskb-single"> 单主图</label>' +
      '</div></div>' +
      '<div class="mskb-row" id="mskb-yinliu-row" style="display:none"><label style="white-space:nowrap">引流款图：</label>' +
      '<img id="mskb-yl-preview" style="width:48px;height:48px;object-fit:cover;border:1px solid #D1D1D1;border-radius:4px;display:none;background:#f5f5f5;flex:0 0 auto;margin:0 4px 0 0">' +
      '<div style="position:relative;flex:1;min-width:140px">' +
      '<input id="mskb-yinliu" type="text" spellcheck="false" placeholder="图片直链，留空按普通模式" style="width:100%;font-size:11px;padding:5px 24px 5px 6px;box-sizing:border-box">' +
      '<button id="mskb-yl-btn" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:none;background:none;cursor:pointer;font-size:11px;color:#0078D7;padding:2px 6px;z-index:2">▼</button>' +
      '</div>' +
      '</div>' +
      '<div class="mskb-row" id="mskb-custom-row" style="display:none"><label style="white-space:nowrap">定制款图：</label>' +
      '<img id="mskb-cu-preview" style="width:48px;height:48px;object-fit:cover;border:1px solid #D1D1D1;border-radius:4px;display:none;background:#f5f5f5;flex:0 0 auto;margin:0 4px 0 0">' +
      '<div style="position:relative;flex:1;min-width:140px">' +
      '<input id="mskb-custom-url" type="text" spellcheck="false" placeholder="定制图片直链；锁第2规格并命名 diseño personalizado（可与引流同时勾选）" style="width:100%;font-size:11px;padding:5px 6px;box-sizing:border-box">' +
      '</div>' +
      '</div>' +
      '<div class="mskb-row" style="align-items:flex-start"><label style="white-space:nowrap;flex:0 0 68px">主图链接：</label>' +
      '<div style="flex:1;min-width:0">' +
      '<textarea id="mskb-mximg" spellcheck="false" rows="2" placeholder="每行1张主图直链（T恤/卫衣/短裤/套装/帆布袋可用，插入第1张原主图后）" style="width:100%;font-size:11px;padding:5px;box-sizing:border-box;resize:vertical"></textarea>' +
      '<div id="mskb-single-tip" style="display:none;font-size:10.5px;color:#c0392b;line-height:1.5;margin-top:4px">单主图已勾选：此处必填细节图直链（每行1条，http/https），留空或全部无效 → 本批不会发布。</div>' +
      '<div id="mskb-mximg-pre" style="display:grid;grid-template-columns:repeat(4,56px);gap:4px;margin-top:6px"></div>' +
      '</div>' +
      '</div>' +
      '<div class="mskb-row"><label>数量：</label>' +
      '<input id="mskb-count" type="number" value="20" min="1" max="500" style="width:70px">' +
      '<label style="margin-left:8px">人员：</label>' +
      '<select id="mskb-owner" style="flex:1;min-width:90px">' +
      '<option value="__main__" selected>主账号</option>' +
      '<option value="__all__">全部人员</option>' +
      '</select>' +
      '</div>' +
      '<div class="mskb-row"><label style="white-space:nowrap">发布店铺：</label>' +
      '<select id="mskb-pubshop" style="flex:1;min-width:120px" title="选一个预发布店铺后，只处理已选该店铺的商品，并发布到该店铺；自动=每个商品用它自己的第一个预发布店铺"><option value="__auto__" selected>自动（按商品已选预发布店铺）</option></select>' +
      '<button id="mskb-loadshop" class="mskb-btn mskb-gray" style="margin-left:4px;white-space:nowrap">载入店铺</button>' +
      '</div>' +
      '<div class="mskb-row">' +
      '<button id="mskb-start" class="mskb-btn mskb-green">▶ 开始处理</button>' +
      '<button id="mskb-stop" class="mskb-btn mskb-red" disabled>■ 停止</button>' +
      '<button id="mskb-loadowner" class="mskb-btn mskb-gray">载入子账号</button>' +
      '</div>' +
      '<details style="margin:4px 0"><summary style="cursor:pointer;color:#0d8a7a;font-size:12px;font-weight:bold;outline:none">📖 使用步骤（点我展开）</summary>' +
      '<div style="font-size:11.5px;line-height:1.8;color:#333;background:#f6f8fa;padding:9px 10px;border-radius:6px;margin-top:6px">' +
      '⓪ 首次使用先点顶部「授权」→「展开」→ 复制本机机器码发给管理员换授权码 → 粘贴授权码点「激活」；未授权时「开始处理」会被拦截（防止插件外传）<br>' +
      '① 采集箱勾选商品 → 点上方「选择店铺」认领<br>' +
      '② 点「载入子账号」→ 下拉选自己（主账号可跳过）<br>' +
      '　　（可选）点「载入店铺」→「发布店铺」选一个预发布店铺：只处理已选该店铺的商品，并发布到该店铺；不选=自动按商品自己的第一个预发布店铺<br>' +
      '③ 选品类（单选）→ 选款式（通用/男款/女款/男女混合）→ 选<b>普通模式</b>或<b>引流</b>（引流填引流款图）；「定制」可与引流同时勾选，填定制图后锁定第2规格并命名 diseño personalizado；只采集到主图、商品没有细节图的，勾「单主图」（可与引流/定制同时），必须自己在<b>主图链接</b>里填细节图直链，不填不会发布；主图链接对服装/帆布袋生效<br>' +
      '④ 数量先填 <b>3</b> 试跑，点「开始处理」<br>' +
      '⑤ 看进度条；要中途停点「停止」<br>' +
      '<span style="color:#c0392b">插件自动识别每个商品的品类并按勾选过滤：上衣只留黑/白带印花，短裤只留黑/灰。先小数量确认再放量。</span>' +
      '</div></details>' +
      '<details style="margin:4px 0"><summary style="cursor:pointer;color:#0d8a7a;font-size:12px;font-weight:bold;outline:none">🏷 品牌/违禁词库（每行一个·四模式统一剔除）</summary>' +
      '<textarea id="mskb-brands" spellcheck="false" style="width:100%;height:120px;font-size:11px;margin-top:6px;padding:6px;border:1px solid #ccc;border-radius:6px;resize:vertical;box-sizing:border-box" placeholder="每行一个词，大小写不敏感；整框清空则用内置词库"></textarea>' +
      '<div style="font-size:10.5px;color:#888;line-height:1.5">只删品牌商标 / 来源卖家品牌 / 违禁词；<b style="color:#c0392b">IP·动漫·名人·乐队·球队联盟名是流量词，不要填进来</b>。改动失焦自动保存。</div>' +
      '</details>' +
      '<div id="mskb-progress-wrap"><div id="mskb-progress"></div></div>' +
      '<div id="mskb-cur" style="font-size:11px;color:#444;margin:4px 0;min-height:15px"></div>' +
      '<div id="mskb-stat" style="font-size:12px;font-weight:bold;margin:2px 0"></div>' +
      '<div class="mskb-row" style="justify-content:space-between;align-items:center">' +
      '<div class="mskb-tabs"><button id="mskb-tab-all" class="mskb-tab mskb-tab-on" type="button">全部日志</button>' +
      '<button id="mskb-tab-fail" class="mskb-tab" type="button">失败汇总</button></div>' +
      '<div><button id="mskb-copy" class="mskb-mini">复制</button>' +
      '<button id="mskb-clear" class="mskb-mini">清空</button></div>' +
      '</div>' +
      '<div id="mskb-log"></div>' +
      '</div>';
    panel.style.display = 'none';
    document.body.appendChild(panel);

    // 悬浮球
    var fab = document.createElement('div');
    fab.id = 'mskb-fab';
    fab.textContent = '妙';
    fab.style.cssText = 'position:fixed;right:24px;bottom:24px;width:56px;height:56px;border-radius:50%;' +
      'background:linear-gradient(135deg,rgba(0,120,215,.85),rgba(0,90,180,.9));' +
      'backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);' +
      'color:#fff;font-size:22px;font-weight:700;display:flex;align-items:center;justify-content:center;' +
      'cursor:default;z-index:2147483641;box-shadow:0 4px 20px rgba(0,120,215,.4),inset 0 1px 2px rgba(255,255,255,.3);' +
      'user-select:none;font-family:"Microsoft YaHei",sans-serif;transition:box-shadow .2s;';
    document.body.appendChild(fab);

    var fabDragging = false;
    fab.addEventListener('mousedown', function (e) {
      fabDragging = false;
      fab._sx = e.clientX; fab._sy = e.clientY;
      var r = fab.getBoundingClientRect();
      fab._left = r.left; fab._top = r.top;
      e.preventDefault();
    });
    document.addEventListener('mousemove', function (e) {
      if (!fab._sx) return;
      var dx = e.clientX - fab._sx, dy = e.clientY - fab._sy;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) fabDragging = true;
      if (fabDragging) {
        fab.style.left = (fab._left + dx) + 'px';
        fab.style.top = (fab._top + dy) + 'px';
        fab.style.right = 'auto'; fab.style.bottom = 'auto';
      }
    });
    document.addEventListener('mouseup', function () {
      if (fabDragging) { fabDragging = false; fab._sx = 0; return; }
      if (fab._sx) {
        panel.style.display = 'block';
        fab.style.display = 'none';
      }
      fab._sx = 0;
    });

    var style = document.createElement('style');
    style.textContent =
      '#mskb-panel{position:fixed;top:80px;right:16px;width:420px;max-height:88vh;overflow:auto;' +
      'background:#fff;border:1px solid #D1D1D1;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,.15);' +
      'z-index:2147483640;font-family:"Segoe UI","Microsoft YaHei",sans-serif;font-size:13px;color:#1B1B1B}' +
      '#mskb-header{background:#0078D7;color:#fff;padding:10px 14px;' +
      'font-weight:600;display:flex;justify-content:space-between;align-items:center;border-radius:8px 8px 0 0;' +
      'font-size:14px}' +
      '#mskb-ver{font-weight:normal;font-size:11px;opacity:.9;font-family:Consolas,monospace}' +
      '#mskb-body{padding:14px}' +
      '.mskb-row{display:flex;align-items:center;gap:6px;margin:8px 0;flex-wrap:nowrap}' +
      '.mskb-row label{margin:0}.mskb-opt{display:flex;align-items:center;gap:3px;font-size:12px;' +
      'padding:3px 8px;border:1px solid #D1D1D1;border-radius:4px;cursor:pointer;user-select:none;background:#fff;white-space:nowrap}' +
      '.mskb-opt:hover{background:#E5F1FB;border-color:#0078D7}' +
      '.mskb-opt input{margin:0;accent-color:#0078D7}' +
      '.mskb-btn{border:none;border-radius:4px;color:#fff;padding:8px 12px;cursor:pointer;font-size:13px;font-weight:600;flex:1;' +
      'font-family:"Segoe UI","Microsoft YaHei",sans-serif}' +
      '.mskb-green{background:#0078D7}.mskb-green:hover{background:#0063B1}' +
      '.mskb-red{background:#D83B01}.mskb-red:hover{background:#B82F00}' +
      '.mskb-gray{background:#767676;flex:0 0 auto;padding:6px 12px;font-size:12px}' +
      '.mskb-gray:hover{background:#5C5C5C}' +
      '.mskb-btn:disabled{opacity:.5;cursor:not-allowed}' +
      '.mskb-mini{border:1px solid #D1D1D1;background:#fff;border-radius:4px;padding:4px 10px;font-size:12px;cursor:pointer;' +
      'color:#0078D7;font-weight:600}' +
      '.mskb-mini:hover{background:#E5F1FB;border-color:#0078D7}' +
      '.mskb-tabs{display:inline-flex;gap:4px}' +
      '.mskb-tab{border:1px solid #D1D1D1;background:#F5F5F5;border-radius:4px;padding:3px 10px;font-size:12px;cursor:pointer;color:#555}' +
      '.mskb-tab:hover{background:#E5F1FB}' +
      '.mskb-tab-on{background:#0078D7;border-color:#0078D7;color:#fff;font-weight:600}' +
      '#mskb-log.mskb-filter-fail > div:not(.mskb-fail-item){display:none}' +
      '#mskb-log.mskb-filter-fail.mskb-empty-msg::after{content:"暂无发布失败日志";color:#888;display:block;text-align:center;padding:20px 0}' +
      '#mskb-progress-wrap{height:18px;background:#E5E5E5;border-radius:4px;overflow:hidden;margin-top:8px;border:1px solid #D1D1D1}' +
      '#mskb-progress{height:100%;width:0;background:#0078D7;' +
      'transition:width .3s;text-align:center;color:#fff;font-size:11px;line-height:18px;font-family:Consolas,monospace}' +
      '#mskb-log{background:#1B1B1B;color:#CCCCCC;padding:10px;border-radius:4px;height:160px;overflow-y:auto;' +
      'font-family:Consolas,"Courier New",monospace;font-size:11.5px;white-space:pre-wrap;line-height:1.55;' +
      'border:1px solid #333}' +
      '#mskb-log .mskb-err{color:#F1707B}#mskb-log .mskb-warn{color:#F7C948}#mskb-log .mskb-ok{color:#6CCB5F}' +
      '#mskb-panel input[type=number],#mskb-panel input[type=text],#mskb-panel select,#mskb-panel textarea{padding:6px 8px;border:1px solid #D1D1D1;border-radius:4px;font-size:12.5px;' +
      'font-family:"Segoe UI","Microsoft YaHei",sans-serif;color:#1B1B1B;background:#fff;box-sizing:border-box}' +
      '#mskb-panel input[type=number]:focus,#mskb-panel input[type=text]:focus,#mskb-panel select:focus,#mskb-panel textarea:focus{outline:none;border-color:#0078D7;box-shadow:0 0 0 1px #0078D7}' +
      '.mskb-sep{border:none;border-top:1px solid #E5E5E5;margin:10px 0}';
    document.head.appendChild(style);

    logEl = $('mskb-log'); progressBar = $('mskb-progress');
    curText = $('mskb-cur'); statText = $('mskb-stat');
    catBoxes = panel.querySelectorAll('input[name=mskb-cat]');
    smodeRadios = panel.querySelectorAll('input[name=mskb-smode]');
    genderRadios = panel.querySelectorAll('input[name=mskb-gender]');
    // 品类 → 允许的性别选项
    var CAT_GENDER = {
      canvas: ['unisex'],
      bag: ['unisex'],
      top_t: ['male', 'female', 'mixed'],
      top_h: ['male', 'female', 'mixed'],
      top_c: ['male', 'female', 'mixed'],
      shorts: ['male'],
      set: ['male'],
      kids: ['boy', 'girl', 'mixed'],
      cvc: ['male', 'female', 'mixed']
    };
    function syncGenderByCat() {
      var selCat = panel.querySelector('input[name=mskb-cat]:checked');
      var cat = selCat ? selCat.value : 'canvas';
      var allow = CAT_GENDER[cat] || ['unisex'];
      genderRadios.forEach(function (g) {
        g.disabled = allow.indexOf(g.value) < 0;
        var lbl = g.closest('label');
        if (lbl) lbl.style.opacity = g.disabled ? '0.35' : '1';
        // 被禁用的选项强制取消勾选，避免旧选中态残留
        if (g.disabled && g.checked) g.checked = false;
      });
      // 当前选中的性别若被禁用，自动切到允许的第一个
      var curG = panel.querySelector('input[name=mskb-gender]:checked');
      if (!curG || allow.indexOf(curG.value) < 0) {
        var firstOk = panel.querySelector('input[name=mskb-gender][value="' + allow[0] + '"]');
        if (firstOk) { firstOk.disabled = false; firstOk.checked = true; }
      }
    }
    catBoxes.forEach(function (c) { c.addEventListener('change', syncGenderByCat); });
    syncGenderByCat();
    countInput = $('mskb-count'); ownerSelect = $('mskb-owner');
    yinliuInput = $('mskb-yinliu');
    customChk = $('mskb-custom');
    customInput = $('mskb-custom-url');
    singleChk = $('mskb-single');
    mximgInput = $('mskb-mximg');
    // 主图链接预览：每行1张，前8张填进 2行x4个 预览格
    function renderMxImgPreviews() {
      var pre = $('mskb-mximg-pre');
      if (!pre || !mximgInput) return;
      var urls = mximgInput.value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 8);
      var cells = [];
      for (var i = 0; i < urls.length; i++) {
        var cell = document.createElement('div');
        cell.style.width = '100%'; cell.style.aspectRatio = '1';
        cell.style.border = '1px solid #d1d1d1'; cell.style.borderRadius = '4px';
        cell.style.background = '#f5f5f5'; cell.style.overflow = 'hidden';
        cell.style.display = 'flex'; cell.style.alignItems = 'center'; cell.style.justifyContent = 'center';
        var img = document.createElement('img');
        img.src = urls[i]; img.style.width = '100%'; img.style.height = '100%'; img.style.objectFit = 'cover';
        img.onerror = function () { this.style.display = 'none'; };
        cell.appendChild(img);
        cells.push(cell);
      }
      pre.innerHTML = '';
      cells.forEach(function (c) { pre.appendChild(c); });
    }
    if (mximgInput) mximgInput.addEventListener('input', renderMxImgPreviews);
    renderMxImgPreviews();
    btnStart = $('mskb-start'); btnStop = $('mskb-stop'); btnLoadOwner = $('mskb-loadowner');
    pubShopSelect = $('mskb-pubshop'); btnLoadShop = $('mskb-loadshop');
    // 授权区交互：展开/收起、复制机器码、激活、注销
    (function () {
      var licToggle = $('mskb-lic-toggle'), licBody = $('mskb-lic-body'), licInput = $('mskb-licinput'),
        licAct = $('mskb-licact'), licClear = $('mskb-licclear'), mcCopy = $('mskb-mcopy'),
        mcInput = $('mskb-mcode'), licTip = $('mskb-lic-tip');
      if (licToggle && licBody) {
        licToggle.addEventListener('click', function () {
          var show = licBody.style.display === 'none';
          licBody.style.display = show ? 'block' : 'none';
          licToggle.textContent = show ? '收起' : '展开';
          if (show) licPaint();
        });
      }
      if (mcCopy && mcInput) {
        mcCopy.addEventListener('click', function () {
          var v = mcInput.value || licMachineCode();
          mcInput.value = v;
          try { mcInput.select(); document.execCommand('copy'); } catch (e) { }
          try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(v); } catch (e) { }
          mcCopy.textContent = '已复制';
          setTimeout(function () { mcCopy.textContent = '复制'; }, 1200);
        });
      }
      if (licAct && licInput) {
        licAct.addEventListener('click', async function () {
          var code = licInput.value.trim();
          if (!code) { licTip.style.color = '#c0392b'; licTip.textContent = '请先粘贴授权码'; return; }
          licAct.disabled = true; licAct.textContent = '校验中…';
          var r = await licApply(code, false);
          licAct.disabled = false; licAct.textContent = '激活';
          if (r.ok) {
            licInput.value = '';
            licTip.style.color = '#0d8a7a';
            licTip.textContent = '激活成功：' + (LIC_INFO.name || '未署名') + (LIC_INFO.expire ? '，有效期至 ' + LIC_INFO.expire : '，长期有效');
            if (licBody) { licBody.style.display = 'none'; if (licToggle) licToggle.textContent = '展开'; }
            toast('授权成功');
          } else {
            licTip.style.color = '#c0392b';
            licTip.textContent = r.reason;
            toast('授权失败');
          }
        });
      }
      if (licClear) {
        licClear.addEventListener('click', function () {
          try { localStorage.removeItem('mskb_lic'); } catch (e) { }
          LIC_OK = false; LIC_INFO = { name: '', expire: '', machine: licMachineCode() };
          licPaint();
          licTip.style.color = '#888';
          licTip.textContent = '已注销本机授权；需要重新粘贴授权码才能开始处理。';
          log('已注销本机授权', 'warn');
        });
      }
    })();
    bindUpdateUI();
    var savedPubShop = '';
    try { savedPubShop = localStorage.getItem('mskb_pubshop') || ''; } catch (e) { }
    function escPubShopHtml(s) {
      return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
      });
    }
    // 发布店铺下拉：列出当前账号可选的预发布店铺（按店铺ID发布，选后只处理已选该店铺的商品）
    function fillPubShopOptions(shops) {
      if (!pubShopSelect) return;
      var cur = pubShopSelect.value;
      if (!cur || cur === '__auto__') cur = savedPubShop || '__auto__';
      var html = ['<option value="__auto__">自动（按商品已选预发布店铺）</option>'];
      (shops || []).forEach(function (s) {
        html.push('<option value="' + escPubShopHtml(s.id) + '">' + escPubShopHtml(s.name || s.id) + '</option>');
      });
      pubShopSelect.innerHTML = html.join('');
      var hit = false;
      for (var i = 0; i < pubShopSelect.options.length; i++) {
        if (pubShopSelect.options[i].value === cur) { hit = true; break; }
      }
      pubShopSelect.value = hit ? cur : '__auto__';
      if (!hit && cur !== '__auto__') log('发布店铺已重置为「自动」：原选店铺不在当前账号店铺列表', 'warn');
    }
    async function loadPubShopOptions(silent) {
      if (btnLoadShop) { btnLoadShop.disabled = true; btnLoadShop.textContent = '载入中…'; }
      try {
        var so = await apiPost(API.shopOptions, {});
        var shops = [], seenShop = {};
        (so.siteShopOptions || []).forEach(function (site) {
          (site.options || []).forEach(function (o) {
            if (!o || !o.value) return;
            var id = String(o.value);
            if (seenShop[id]) return;
            seenShop[id] = 1;
            shops.push({ id: id, name: o.label || '' });
          });
        });
        fillPubShopOptions(shops);
        if (!silent) { log('已载入 ' + shops.length + ' 个预发布店铺，可在「发布店铺」指定只发其中一个', 'ok'); toast('已载入店铺'); }
      } catch (e) {
        if (!silent) log('载入店铺失败: ' + ((e && e.message) || e), 'err');
      } finally {
        if (btnLoadShop) { btnLoadShop.disabled = false; btnLoadShop.textContent = '载入店铺'; }
      }
    }
    if (pubShopSelect) {
      pubShopSelect.addEventListener('change', function () {
        savedPubShop = pubShopSelect.value;
        try { localStorage.setItem('mskb_pubshop', savedPubShop); } catch (e) { }
      });
    }
    if (btnLoadShop) btnLoadShop.addEventListener('click', function () { loadPubShopOptions(false); });

    // 模式联动：选「引流」才显示引流款图行；「定制」为独立勾选(可与引流同时)，勾选后显示定制图行；主图链接行常显
    function syncModeRows() {
      var checked = panel.querySelector('input[name=mskb-smode]:checked');
      var v = checked ? checked.value : 'normal';
      var ylRow = $('mskb-yinliu-row');
      if (ylRow) ylRow.style.display = (v === 'yinliu') ? 'flex' : 'none';
    }
    smodeRadios.forEach(function (r) { r.addEventListener('change', syncModeRows); });
    syncModeRows();
    function syncCustomRow() {
      var cuRow = $('mskb-custom-row');
      if (cuRow && customChk) cuRow.style.display = customChk.checked ? 'flex' : 'none';
    }
    function refreshCuPreview() {
      var img = $('mskb-cu-preview');
      if (!img || !customInput) return;
      var v = customInput.value.trim();
      if (/^https?:\/\/.+\.(png|jpe?g|webp|gif)(\?|$)/i.test(v)) {
        img.src = v; img.style.display = 'block';
        img.onerror = function () { this.style.display = 'none'; };
      } else { img.style.display = 'none'; }
    }
    if (customChk) {
      customChk.addEventListener('change', function () {
        syncCustomRow();
        try { localStorage.setItem('mskb_custom_on', customChk.checked ? '1' : '0'); } catch (e) { }
      });
      try { if (localStorage.getItem('mskb_custom_on') === '1') customChk.checked = true; } catch (e) { }
    }
    if (customInput) {
      customInput.addEventListener('input', refreshCuPreview);
      customInput.addEventListener('change', function () {
        try { localStorage.setItem('mskb_custom_url', customInput.value.trim()); } catch (e) { }
        refreshCuPreview();
      });
      try { customInput.value = localStorage.getItem('mskb_custom_url') || ''; } catch (e) { }
      refreshCuPreview();
    }
    syncCustomRow();

    // 单主图：独立勾选，可与引流/定制共存；勾选后「主图链接」变必填（只采集到主图、无细节图时手工补细节图直链）
    function syncSingleTip() {
      var tip = $('mskb-single-tip');
      if (!tip || !singleChk) return;
      tip.style.display = singleChk.checked ? 'block' : 'none';
      if (mximgInput) mximgInput.style.borderColor = singleChk.checked ? '#c0392b' : '';
    }
    if (singleChk) {
      singleChk.addEventListener('change', function () {
        syncSingleTip();
        try { localStorage.setItem('mskb_single_on', singleChk.checked ? '1' : '0'); } catch (e) { }
      });
      try { if (localStorage.getItem('mskb_single_on') === '1') singleChk.checked = true; } catch (e) { }
      syncSingleTip();
    }
    btnStart.addEventListener('click', function () { onStart().catch(function (e) { log('未捕获异常: ' + (e && e.message ? e.message : e), 'err'); }); });
    btnStop.addEventListener('click', function () { abortFlag = true; log('⏹ 已请求停止，当前商品处理完后退出…', 'warn'); btnStop.disabled = true; });
    btnLoadOwner.addEventListener('click', loadOwnerOptions);
    // 引流款图历史：每次填入有效链接自动存入 localStorage，点▼弹出选历史
    var YL_HIST_KEY = 'mskb_yinliu_history';
    function loadYlHistory() {
      try { return JSON.parse(localStorage.getItem(YL_HIST_KEY) || '[]'); } catch (e) { return []; }
    }
    function saveYlHistory(arr) {
      try { localStorage.setItem(YL_HIST_KEY, JSON.stringify(arr.slice(0, 20))); } catch (e) { }
    }
    var ylPop = null, ylBtn = $('mskb-yl-btn');
    function ensureYlPop() {
      if (ylPop) return ylPop;
      ylPop = document.createElement('div');
      ylPop.id = 'mskb-yl-pop';
      ylPop.style.cssText = 'display:none;position:fixed;width:340px;max-height:200px;overflow-y:auto;background:#fff;border:1px solid #D1D1D1;border-radius:4px;box-shadow:0 4px 16px rgba(0,0,0,.2);z-index:2147483647;font-size:11px';
      document.body.appendChild(ylPop);
      return ylPop;
    }
    function refreshYlPop() {
      var pop = ensureYlPop();
      var hist = loadYlHistory();
      pop.innerHTML = '';
      if (!hist.length) {
        pop.innerHTML = '<div style="padding:10px;color:#888">暂无历史链接</div>';
        return;
      }
      hist.forEach(function (url, idx) {
        var item = document.createElement('div');
        item.style.cssText = 'padding:6px 10px;cursor:pointer;border-bottom:1px solid #f0f0f0;display:flex;align-items:center;gap:6px';
        var thumb = document.createElement('img');
        thumb.style.cssText = 'width:32px;height:32px;object-fit:cover;border:1px solid #E0E0E0;border-radius:3px;flex:0 0 auto;background:#f5f5f5';
        thumb.src = url;
        thumb.onerror = function () { thumb.style.display = 'none'; };
        var label = document.createElement('span');
        label.style.cssText = 'flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
        label.textContent = (idx + 1) + '. ' + url;
        item.title = url;
        item.appendChild(thumb);
        item.appendChild(label);
        item.onmouseenter = function () { item.style.background = '#E5F1FB'; };
        item.onmouseleave = function () { item.style.background = '#fff'; };
        item.onmousedown = function (e) {
          e.stopPropagation();
          e.preventDefault();
          yinliuInput.value = url;
          pop.style.display = 'none';
          refreshYlPreview();
          yinliuInput.dispatchEvent(new Event('change'));
        };
        pop.appendChild(item);
      });
    }
    if (ylBtn) {
      ylBtn.addEventListener('mousedown', function (e) {
        e.stopPropagation();
        e.preventDefault();
        var pop = ensureYlPop();
        if (pop.style.display === 'block') { pop.style.display = 'none'; return; }
        refreshYlPop();
        var r = ylBtn.getBoundingClientRect();
        pop.style.top = (r.bottom + 4) + 'px';
        pop.style.left = r.left + 'px';
        pop.style.display = 'block';
      });
    }
    document.addEventListener('mousedown', function (e) {
      if (ylPop && ylPop.style.display === 'block' && !ylPop.contains(e.target) && e.target !== ylBtn) {
        ylPop.style.display = 'none';
      }
    });

    // 引流款图预览：输入框变化时显示缩略图
    function refreshYlPreview() {
      var img = $('mskb-yl-preview');
      if (!img) return;
      var v = yinliuInput.value.trim();
      if (v && /^https?:\/\//i.test(v)) {
        img.src = v;
        img.style.display = 'block';
        img.onerror = function () { img.style.display = 'none'; img.src = ''; };
      } else {
        img.style.display = 'none';
        img.src = '';
      }
    }
    yinliuInput.addEventListener('input', refreshYlPreview);
    yinliuInput.addEventListener('change', function () {
      var v = yinliuInput.value.trim();
      try { localStorage.setItem('mskb_yinliu_url', v); } catch (e) { }
      if (v && /^https?:\/\//.test(v)) {
        var hist = loadYlHistory();
        if (hist.indexOf(v) < 0) {
          hist.unshift(v);
          saveYlHistory(hist);
        }
      }
      log(v ? '引流款图网址已记住：' + v.slice(0, 60) + (v.length > 60 ? '…' : '') : '引流款图已清空，选引流时将按普通模式处理', v ? 'ok' : 'warn');
    });
    try { yinliuInput.value = localStorage.getItem('mskb_yinliu_url') || ''; } catch (e) { yinliuInput.value = ''; }
    refreshYlPreview();

    // 品牌/违禁词库：默认内置，可编辑，localStorage 记住
    brandBoxInput = $('mskb-brands');
    function syncBrandReFromBox() {
      var raw = brandBoxInput.value;
      var words = raw.trim() ? raw.split(/\r?\n/) : DEFAULT_BRAND_WORDS.slice(); // 整框清空=用内置
      brandStripRe = buildBrandStripRe(words);
      try { localStorage.setItem('mskb_brand_words_v2', raw); } catch (e) { }
      return words.filter(function (w) { return String(w).trim(); }).length;
    }
    try { var savedB = localStorage.getItem('mskb_brand_words_v2'); brandBoxInput.value = (savedB != null) ? savedB : DEFAULT_BRAND_WORDS.join('\n'); } catch (e) { brandBoxInput.value = DEFAULT_BRAND_WORDS.join('\n'); }
    brandBoxInput.addEventListener('blur', function () { var n = syncBrandReFromBox(); log('品牌/违禁词库已更新：当前 ' + n + ' 个词', 'ok'); });
    syncBrandReFromBox();
    $('mskb-copy').addEventListener('click', function () {
      navigator.clipboard.writeText(logEl.innerText).then(function () { toast('日志已复制'); });
    });
    $('mskb-clear').addEventListener('click', function () { logEl.innerHTML = ''; refreshFailEmpty(); });
    function setLogTab(failMode) {
      $('mskb-tab-all').classList.toggle('mskb-tab-on', !failMode);
      $('mskb-tab-fail').classList.toggle('mskb-tab-on', failMode);
      logEl.classList.toggle('mskb-filter-fail', failMode);
      refreshFailEmpty();
    }
    $('mskb-tab-all').addEventListener('click', function () { setLogTab(false); });
    $('mskb-tab-fail').addEventListener('click', function () { setLogTab(true); });
    $('mskb-min').addEventListener('click', function () {
      panel.style.display = 'none';
      fab.style.display = 'flex';
    });
    makeDraggable(panel, $('mskb-header'));
  }

  function makeDraggable(p, handle) {
    var sx, sy, px, py, drag = false;
    handle.addEventListener('mousedown', function (e) {
      drag = true; sx = e.clientX; sy = e.clientY;
      var r = p.getBoundingClientRect(); px = r.left; py = r.top;
      e.preventDefault();
    });
    document.addEventListener('mousemove', function (e) {
      if (!drag) return;
      p.style.left = (px + e.clientX - sx) + 'px';
      p.style.top = Math.max(0, py + e.clientY - sy) + 'px';
      p.style.right = 'auto';
    });
    document.addEventListener('mouseup', function () { drag = false; });
  }

  function nowStr() { var d = new Date(); return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + ':' + ('0' + d.getSeconds()).slice(-2); }
  function log(msg, type) {
    if (!logEl) return null;
    var line = document.createElement('div');
    if (type) line.className = 'mskb-' + type;
    line.textContent = '[' + nowStr() + '] ' + msg;
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
    return line;
  }
  // 失败汇总模式下，无失败条目时显示占位提示
  function refreshFailEmpty() {
    if (!logEl) return;
    var hasFail = logEl.querySelectorAll('.mskb-fail-item').length > 0;
    logEl.classList.toggle('mskb-empty-msg', !hasFail);
  }
  function setProgress(done, total) {
    var pct = total ? Math.floor(done * 100 / total) : 0;
    progressBar.style.width = pct + '%';
    progressBar.textContent = pct + '%';
  }
  function toast(msg) {
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;top:24px;left:50%;transform:translateX(-50%);background:#333;color:#fff;' +
      'padding:10px 22px;border-radius:8px;z-index:2147483647;font-size:14px;box-shadow:0 4px 16px rgba(0,0,0,.3)';
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 1800);
  }

  async function loadOwnerOptions() {
    btnLoadOwner.disabled = true; btnLoadOwner.textContent = '扫描中…';
    log('扫描采集箱人员名单（会翻完全部未发布页，人多的店约需1分钟）…');
    try {
      var list = await loadOwnersFromApi(function (pg, total, cnt) { btnLoadOwner.textContent = '第' + pg + (total ? '/' + total : '') + '页 · 已识别' + cnt + '人…'; });
      ownerSelect.innerHTML =
        '<option value="__main__">主账号</option>' +
        '<option value="__all__">全部人员</option>';
      list.forEach(function (o) {
        if (o.isMain) {
          var mo = ownerSelect.querySelector('option[value="__main__"]');
          if (mo) mo.textContent = '主账号 (' + o.total + ')';
          return;
        }
        var opt = document.createElement('option');
        opt.value = o.id;
        opt.textContent = o.name + ' (' + o.total + ')';
        ownerSelect.appendChild(opt);
      });
      log('已载入 ' + list.length + ' 个人员，括号内为未发布商品数', 'ok');
      toast('已载入 ' + list.length + ' 个人员');
    } catch (e) {
      log('载入人员失败: ' + ((e && e.message) || e), 'err');
    } finally {
      btnLoadOwner.disabled = false; btnLoadOwner.textContent = '载入子账号';
    }
  }

  async function resolveOwnerId() {
    var val = ownerSelect ? ownerSelect.value : '__main__';
    if (val === '__all__') return { id: '', label: '全部人员' };
    if (val === '__main__' || !val) {
      var aid = await getAppAccountId();
      return { id: aid ? 'main_' + aid : '', label: '主账号' + (aid ? '(' + aid + ')' : '') };
    }
    var lbl = val;
    if (ownerSelect && ownerSelect.selectedOptions && ownerSelect.selectedOptions[0]) {
      lbl = ownerSelect.selectedOptions[0].textContent || val;
    }
    return { id: val, label: lbl };
  }

  // ---------------- 扫描（只翻列表，快速圈定已选店铺商品）----------------
  async function scanProducts(ownerId, batchSize, targetShopId, onProgress) {
    var picked = [];
    var targetShop = targetShopId ? String(targetShopId) : '';
    for (var pageNo = 1; pageNo <= 60; pageNo++) {
      if (abortFlag) break;
      var params = {
        pageNo: String(pageNo), pageSize: '50',
        status: 'notPublished',
        claimPublishShopStatus: 'published',
        remarkType: 'multi', titleType: 'multi'
      };
      if (ownerId) params['ownerAccountIds[0]'] = ownerId;
      var lr = await apiPost(API.search, params);
      var items = lr.detailList || [];
      if (!items.length) break;
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var claimed = item.collectBoxDetailShopList || [];
        if (!claimed.length) continue; // 未选预发布店铺 → 跳过
        var pickShopId = '';
        if (targetShop) {
          // 指定了发布店铺：只圈定已选该店铺的商品，并固定发布到该店铺
          for (var ci = 0; ci < claimed.length; ci++) {
            if (String(claimed[ci].shopId || '') === targetShop) { pickShopId = targetShop; break; }
          }
          if (!pickShopId) continue;
        } else {
          pickShopId = String(first(claimed).shopId || '');
        }
        picked.push({
          did: item.collectBoxDetailId,
          item: item,
          pubShopId: pickShopId
        });
        if (picked.length >= batchSize) return picked;
      }
      if (onProgress) onProgress(pageNo, picked.length);
    }
    return picked;
  }

  // ---------------- T恤：只按颜色名筛选。onlyBlack=true只留黑；onlyBlack=false留黑+白 ----------------
  async function pickTshirtColors(colors, p, onlyBlack) {
    var judged = [];
    for (var ci = 0; ci < colors.length; ci++) {
      var c = colors[ci];
      if (!c) { judged.push({ c: c, v: null, name: '', how: 'empty' }); continue; }
      if (!c.imgUrl) { judged.push({ c: c, v: null, name: c.attrValue || '', how: '无图' }); continue; }
      // SKU图直接AI判色：选对应颜色带印花的，无印花/细节图过滤
      var r = await aiJudgeColor(c.imgUrl);
      if (!r) { judged.push({ c: c, v: null, name: c.attrValue || '', how: 'AI失败' }); continue; }
      var ct = r.color === 'black' ? '黑' : r.color === 'white' ? '白' : '其他';
      var fl = [];
      if (r.hasPrint) fl.push('有印花'); else fl.push('无印花');
      if (r.isDetail) fl.push('细节图');
      var v = ((r.color === 'black' || (!onlyBlack && r.color === 'white')) && r.hasPrint && !r.isDetail) ? r.color : null;
      judged.push({ c: c, v: v, name: c.attrValue || '', how: 'AI:' + ct + '/' + fl.join('/') });
    }
    var kept = judged.filter(function (j) {
      return j.v === 'black' || (!onlyBlack && j.v === 'white');
    });
    return { judged: judged, kept: kept };
  }

  // 取货源ID：按"长数字特征"匹配（货源ID约19位，商品ID才10位），不依赖字段名；匹配不到再兜底did
  function getSourceId(p) {
    var it = p.item || {};
    var best = null;
    for (var k in it) {
      var v = it[k];
      if (v != null && /^\d{12,}$/.test(String(v)) && (!best || String(v).length > String(best).length)) best = String(v);
    }
    if (best) return best;
    log('  [诊断] 未取到货源ID，item字段: ' + Object.keys(it).join(','), 'warn');
    return p.did;
  }

  // ---------------- 单个处理（此时才取详情/OSS图）----------------
  // ctx = { cats:[勾选品类], smode:'normal'|'yinliu' }；每个商品先自动识别品类，再按勾选过滤、合成内部 mode
  async function processOne(p, ctx, defaultShopId, yinliuUrl, mxImgs) {
    var aiUsed = false;
    // 单主图兜底硬门：只采集到主图、没有细节图时必须由「主图链接」提供细节图直链；缺失一律不保存、不发布
    if (ctx.single === true && !(mxImgs && mxImgs.length)) {
      return { status: 'skipped', reason: '单主图未填细节图链接，按规则不发布' };
    }
    var detail = await apiPost(API.detail, { detailId: p.did, shopId: p.pubShopId });
    var info = detail.shopCollectItemInfo;
    if (!info || !info.skuPropertyList) return { status: 'skipped', reason: '无编辑数据' };
    log('  [诊断] site=' + (info.site || '') + ' cid=' + info.cid);
    if (!info.cid || info.cid === '0') return { status: 'skipped', reason: '无类目' };

    var props = info.skuPropertyList;
    var colors = (first(props) && first(props).attrValueList) || [];
    var sizes = (props.length > 1 && props[1]) ? (props[1].attrValueList || []) : [];
    var imgUrls = info.imgUrls || [];

    // ===== 自动识别商品品类与性别：优先 cid 映射，查不到再 AI 看图 =====
    var ptype, prodGender;
    var cidHit = CID_MAP[String(info.cid)];
    var detSource;
    if (cidHit) {
      ptype = cidHit.ptype; prodGender = cidHit.gender; detSource = 'cid映射';
    } else {
      log('  [提示] cid=' + info.cid + ' 不在映射表，走AI看图；如需固定可加入CID_MAP', 'warn');
      // AI 看图：hoodie/crewneck 都归为 sweatshirt（cid 本就把连帽圆领放一类）
      var detUrl = null;
      for (var di = 0; di < colors.length; di++) { if (colors[di] && colors[di].imgUrl) { detUrl = colors[di].imgUrl; break; } }
      if (!detUrl && imgUrls.length) detUrl = String(imgUrls[0] || '').trim();
      var detR = detUrl ? await aiJudgeColor(detUrl, true) : null;
      prodGender = 'unknown';
      if (detR) {
        if (detR.category === 'shorts') ptype = 'shorts';
        else if (detR.category === 'set') ptype = 'set';
        else if (detR.category === 'kids') ptype = 'kids';
        else if (detR.category === 'bag') { ptype = 'bag'; prodGender = 'unisex'; }
        else if (detR.category === 'tshirt') ptype = detR.isMultiPack ? 'set' : 'tshirt';
        else if (detR.category === 'hoodie' || detR.category === 'crewneck') ptype = detR.isMultiPack ? 'set' : 'sweatshirt';
        else ptype = 'canvas';
      } else {
        ptype = 'canvas';
      }
      detSource = 'AI看图';
    }
    var ptypeLabel = ptype === 'canvas' ? '油画' : ptype === 'bag' ? '帆布袋' : ptype === 'tshirt' ? 'T恤' : ptype === 'sweatshirt' ? '卫衣(连帽/圆领)'
      : ptype === 'shorts' ? '短裤' : ptype === 'set' ? 'T恤短裤套装' : ptype === 'kids' ? '童装' : ptype;
    var genLabel = prodGender === 'male' ? '男' : prodGender === 'female' ? '女' : prodGender === 'unisex' ? '通用' : prodGender === 'boy' ? '男童' : prodGender === 'girl' ? '女童' : '未知';
    log('  品类识别：' + ptypeLabel + ' / ' + genLabel + '（' + detSource + ', cid=' + info.cid + '）');

    // 性别过滤：通用=全过；男款=男/通用；女款=女/通用；男女混合=男+女
    // 童装款：男童=男童cid；女童=女童cid；男女童=男童+女童
    if (ctx.gender === 'male' && !(prodGender === 'male' || prodGender === 'unisex')) {
      return { status: 'skipped', reason: '性别不符(需男款，本商品' + genLabel + ')' };
    }
    if (ctx.gender === 'female' && !(prodGender === 'female' || prodGender === 'unisex')) {
      return { status: 'skipped', reason: '性别不符(需女款，本商品' + genLabel + ')' };
    }
    if (ctx.gender === 'boy' && prodGender !== 'boy') {
      return { status: 'skipped', reason: '性别不符(需男童，本商品' + genLabel + ')' };
    }
    if (ctx.gender === 'girl' && prodGender !== 'girl') {
      return { status: 'skipped', reason: '性别不符(需女童，本商品' + genLabel + ')' };
    }
    // 男女混合：童装时=男童+女童；成人时=男+女
    if (ctx.gender === 'mixed') {
      var isKidsSel = (ctx.cats.indexOf('kids') >= 0);
      if (isKidsSel && !(prodGender === 'boy' || prodGender === 'girl')) {
        return { status: 'skipped', reason: '性别不符(需男女童，本商品' + genLabel + ')' };
      }
      if (!isKidsSel && !(prodGender === 'male' || prodGender === 'female')) {
        return { status: 'skipped', reason: '性别不符(男女混合，本商品' + genLabel + ')' };
      }
    }

    // 品类勾选过滤：sweatshirt 同时匹配连帽(top_h)和圆领(top_c)
    function ptypeEnabled(t) {
      if (t === 'canvas') return ctx.cats.indexOf('canvas') >= 0;
      if (t === 'bag') return ctx.cats.indexOf('bag') >= 0;
      if (t === 'tshirt') return ctx.cats.indexOf('top_t') >= 0 || ctx.cats.indexOf('cvc') >= 0;
      if (t === 'sweatshirt') return ctx.cats.indexOf('top_h') >= 0 || ctx.cats.indexOf('top_c') >= 0;
      if (t === 'shorts') return ctx.cats.indexOf('shorts') >= 0;
      if (t === 'set') return ctx.cats.indexOf('set') >= 0;
      if (t === 'kids') return ctx.cats.indexOf('kids') >= 0;
      return false;
    }
    if (!ptypeEnabled(ptype)) return { status: 'skipped', reason: '品类未勾选(' + ptypeLabel + ')' };

    // 合成内部 mode：普通/引流 与 品类 组合
    // 注意：选了「引流」但引流款图留空/无效时，yinliuUrl='' → 自动退回普通模式（不插盲盒，序号1用来源图）
    var wantYinliu = (ctx.smode === 'yinliu') && !!yinliuUrl &&
      /^https?:\/\/.+\.(png|jpe?g|webp|gif)(\?|$)/i.test(yinliuUrl);
    if (ctx.smode === 'yinliu' && !wantYinliu) log('  引流款图无效，本商品按普通模式处理', 'warn');
    // 定制(可与引流并存)：固定占用第2规格；链接缺失/非法或油画品类时不启用（油画链路保持不变）
    var wantCustom = ptype !== 'canvas' && ctx.custom === true && !!ctx.customUrl && /^https?:\/\/.+\.(png|jpe?g|webp|gif)(\?|$)/i.test(ctx.customUrl);
    if (ctx.custom === true && ptype === 'canvas') log('  [提示] 定制槽仅用于服装/帆布袋品类，油画商品忽略定制', 'warn');
    var mode;
    if (ptype === 'canvas') mode = wantYinliu ? 'yinliu' : 'normal';
    else if (ptype === 'bag') mode = wantYinliu ? 'mxbag_y' : 'mxbag';
    else if (ptype === 'shorts') mode = wantYinliu ? 'mxshorts' : 'mxshorts_n';
    else if (ptype === 'set') mode = wantYinliu ? 'mxset' : 'mxset_n';
    else if (ptype === 'sweatshirt') mode = wantYinliu ? 'mxsweat_y' : 'mxsweat';
    else if (ptype === 'kids') mode = wantYinliu ? 'mxkids_y' : 'mxkids';
    else if (ptype === 'tshirt' && ctx.cats.indexOf('cvc') >= 0 && ctx.cats.indexOf('top_t') < 0) mode = wantYinliu ? 'mxcvc_y' : 'mxcvc';
    else mode = wantYinliu ? 'mxytl' : 'mxtshirt';

    var withImg = colors.filter(function (c) { return c && c.imgUrl; });
    var validColors;

    // 模式分类
    var isT = (mode === 'tshirt' || mode === 'tyl' || mode === 'mxtshirt' || mode === 'mxytl' || mode === 'cvctyl' || mode === 'mxshorts' || mode === 'mxshorts_n' || mode === 'mxset' || mode === 'mxset_n' || mode === 'mxsweat' || mode === 'mxsweat_y' || mode === 'mxkids' || mode === 'mxkids_y' || mode === 'mxcvc' || mode === 'mxcvc_y' || mode === 'mxbag' || mode === 'mxbag_y');
    var isY = (mode === 'yinliu' || mode === 'tyl' || mode === 'mxytl' || mode === 'cvctyl' || mode === 'mxshorts' || mode === 'mxset' || mode === 'mxsweat_y' || mode === 'mxkids_y' || mode === 'mxcvc_y' || mode === 'mxbag_y');
    var tshirtOnly = (mode === 'tshirt' || mode === 'mxtshirt' || mode === 'mxshorts_n' || mode === 'mxset_n' || mode === 'mxsweat' || mode === 'mxkids' || mode === 'mxcvc' || mode === 'mxbag');
    var isTyl = (mode === 'tyl' || mode === 'mxytl' || mode === 'cvctyl' || mode === 'mxshorts' || mode === 'mxset' || mode === 'mxsweat_y' || mode === 'mxkids_y' || mode === 'mxcvc_y' || mode === 'mxbag_y');
    var isMx = isT;   // 所有服装品类普通与引流都补主图
    var onlyBlack = (mode === 'cvctyl');                            // CVC模式只留黑色（新版UI不再产生）

    if (tshirtOnly) {
      // ===== 普通T恤/短裤：SKU图优先判色，全无匹配再产品主图前2张AI判色兜底 =====
      // 短裤模式：黑+灰，品类shorts；T恤模式：黑+白，品类tshirt
      // 短裤：黑+灰；套装：黑/白/灰；卫衣：黑+白但只收hoodie/crewneck不收tshirt；T恤：黑+白；童装：黑/白/浅蓝/粉/红
      var tOpts;
      if (mode === 'mxshorts' || mode === 'mxshorts_n') tOpts = { colors: ['black', 'gray'], category: 'shorts', catKey: 'shorts' };
      else if (mode === 'mxset' || mode === 'mxset_n') tOpts = { colors: ['black', 'white', 'gray'], category: 'set', catKey: 'set' };
      else if (mode === 'mxsweat') {
        // 圆领卫衣只做黑色；连帽卫衣黑+白
        var sweatIsCrew = (ctx.cats.indexOf('top_c') >= 0 && ctx.cats.indexOf('top_h') < 0);
        var sweatColors = sweatIsCrew ? ['black'] : ['black', 'white'];
        tOpts = { colors: sweatColors, category: 'sweatshirt', catKey: sweatIsCrew ? 'crewneck' : 'top_h' };
      }
      else if (mode === 'mxkids') tOpts = { colors: ['black', 'white', 'lightblue', 'pink', 'red'], category: 'kids', catKey: 'kids' };
      else if (mode === 'mxcvc') tOpts = { colors: ['black'], category: 'top', catKey: 'cvc' };
      else if (mode === 'mxbag') tOpts = { colors: ['white', 'beige'], category: 'bag', catKey: 'bag' };
      else tOpts = { colors: ['black', 'white'], category: 'top', catKey: 'top_t' };
      var srcListT = await buildSourceColorList(colors, p);
      // 第一步：SKU图判色（名称→像素→AI三级）
      var fbT = await aiFilterSourceList(srcListT, tOpts);
      var poolT = fbT.pool; var detailT = fbT.detail;
      if (fbT.aiCalled) aiUsed = true;
      // 第二步：SKU图全无匹配时，只取第1张产品主图判色兜底
      // （取2张会把同一款的两张图/同图不同尺寸链接做成 Negro+1/Negro+2 两个同图规格；判色只需1张代表图）
      if (!poolT.length && imgUrls.length) {
        var mainListT = [];
        var mainUrlsT = dedupeMainImgUrls(imgUrls.slice(0, 2), srcListT);
        if (mainUrlsT.length) mainListT.push({ name: '主图1', url: mainUrlsT[0] });
        if (mainUrlsT.length > 1) log('  [主图兜底] 主图有多张不同图，按规则只取第1张判色，避免同图重复规格', 'warn');
        if (mainListT.length) {
          var fbT2 = await aiFilterSourceList(mainListT, { colors: tOpts.colors, category: tOpts.category, catKey: tOpts.catKey });
          poolT = fbT2.pool;
          detailT = detailT.concat(['[主图兜底]']).concat(fbT2.detail);
          if (fbT2.aiCalled) aiUsed = true;
        }
      }
      // 选池按“图片基名”去重：SKU图与主图兜底命中同一张图时只保留1个规格，避免同图规格 Negro+1/Negro+2
      if (poolT.length > 1) {
        var seenPoolT = {}, poolUniqT = [];
        poolT.forEach(function (x) {
          var k = getImgBase(x && x.url ? x.url : '');
          if (!k || !seenPoolT[k]) { if (k) seenPoolT[k] = 1; poolUniqT.push(x); }
          else log('  [去重] 丢弃同图规格: ' + (x.name || '') + ' ' + String(x.url).slice(-60));
        });
        poolT = poolUniqT;
      }
      log('  判色 ' + detailT.length + '→留' + poolT.length + '：' + detailT.join(' '));
      if (!poolT.length) return { status: 'skipped', reason: '无匹配颜色带印花图，整款跳过' };
      if (wantCustom) {
        // ===== 普通+定制：位置0=来源第1张，位置1(第二规格)=定制固定图(diseño personalizado)，其余来源从位置2起，超出克隆 =====
        validColors = [];
        var esAllC = [], srcSlotsN = [];
        if (colors.length < 2) {
          var preN = Object.assign({}, colors[0]);
          preN.attrValueId = 'new_' + Date.now() + '_pre1';
          preN.isNew = true;
          colors.push(preN);
        }
        var poolPosN = 0;
        if (poolT.length > 0 && colors[0]) {
          colors[0].imgUrl = poolT[0].url; colors[0].imgUrls = [poolT[0].url];
          validColors.push(colors[0]); srcSlotsN.push(colors[0]); esAllC.push(esSetSlotName(poolT[0])); poolPosN = 1;
        }
        var customSlotN = colors[1];
        customSlotN.imgUrl = ctx.customUrl; customSlotN.imgUrls = [ctx.customUrl];
        customSlotN.attrValue = CUSTOM_SKU_NAME; customSlotN.__mskbCustom = true;
        validColors.push(customSlotN);
        for (var tn = 2; tn < colors.length && poolPosN < poolT.length; tn++) {
          colors[tn].imgUrl = poolT[poolPosN].url; colors[tn].imgUrls = [poolT[poolPosN].url];
          validColors.push(colors[tn]); srcSlotsN.push(colors[tn]); esAllC.push(esSetSlotName(poolT[poolPosN])); poolPosN++;
        }
        var tmplCN = colors[2] || colors[1] || colors[0];
        while (poolPosN < poolT.length) {
          var ncN = Object.assign({}, tmplCN);
          ncN.attrValueId = 'new_' + Date.now() + '_n' + poolPosN;
          ncN.imgUrl = poolT[poolPosN].url; ncN.imgUrls = [poolT[poolPosN].url]; ncN.isNew = true;
          colors.push(ncN); validColors.push(ncN); srcSlotsN.push(ncN); esAllC.push(esSetSlotName(poolT[poolPosN]));
          log('  ➕ 自动添加规格槽: ' + esSetSlotName(poolT[poolPosN]) + ' [来源图' + (poolPosN + 1) + ']', 'ok');
          poolPosN++;
        }
        applySlotNames(srcSlotsN, esAllC, mode === 'mxbag');
        log('  普通+定制分配：01来源图 + 02定制(' + CUSTOM_SKU_NAME + ') + 来源共' + poolT.length + '张 → 保留' + validColors.length + '个规格');
      } else {
      // 把判色通过的图按顺序分配给colors
      validColors = [];
      var esAll = [];
      for (var ti = 0; ti < colors.length && validColors.length < poolT.length; ti++) {
        if (colors[ti]) {
          var piN = validColors.length;
          colors[ti].imgUrl = poolT[piN].url;
          colors[ti].imgUrls = [poolT[piN].url];
          esAll.push(esSetSlotName(poolT[piN]));
          validColors.push(colors[ti]);
        }
      }
      // poolT 超出现有槽位 → 克隆第二个SKU(序号02，带价格)，覆盖图片/名称
      if (poolT.length > colors.length) {
        var tmplC = colors[1] || colors[0];
        for (var ai = colors.length; ai < poolT.length; ai++) {
          var nc = Object.assign({}, tmplC);
          nc.attrValueId = 'new_' + Date.now() + '_' + ai;
          nc.imgUrl = poolT[ai].url;
          nc.imgUrls = [poolT[ai].url];
          nc.isNew = true;
          colors.push(nc);
          esAll.push(esSetSlotName(poolT[ai]));
          validColors.push(nc);
          log('  ➕ 自动添加规格槽: ' + esSetSlotName(poolT[ai]) + ' [来源图' + (ai + 1) + ']', 'ok');
        }
      }
      // 帆布袋(mxbag)同色多张按 Blanco1/Blanco2 递增；其他品类沿用 名+1 规则
      applySlotNames(validColors, esAll, mode === 'mxbag');
      }
    } else if (isY) {
      // ===== 引流：01盲盒，02起配SKU图 =====
      var yUrl = yinliuUrl; // 走到这里必为有效引流款图（wantYinliu 已校验）
      // 所有引流模式统一走判色流程：SKU有图用SKU图，无图用产品主图兜底
      // shorts：黑+灰；set：黑/白/灰；sweatshirt：黑+白只收hoodie/crewneck；top：黑+白
      var judgeOpts;
      if (mode === 'mxshorts') judgeOpts = { colors: ['black', 'gray'], category: 'shorts', catKey: 'shorts' };
      else if (mode === 'mxset') judgeOpts = { colors: ['black', 'white', 'gray'], category: 'set', catKey: 'set' };
      else if (mode === 'mxsweat_y') {
        var sweatIsCrewY = (ctx.cats.indexOf('top_c') >= 0 && ctx.cats.indexOf('top_h') < 0);
        var sweatColorsY = sweatIsCrewY ? ['black'] : ['black', 'white'];
        judgeOpts = { colors: sweatColorsY, category: 'sweatshirt', catKey: sweatIsCrewY ? 'crewneck' : 'top_h' };
      }
      else if (mode === 'mxkids_y') judgeOpts = { colors: ['black', 'white', 'lightblue', 'pink', 'red'], category: 'kids', catKey: 'kids' };
      else if (mode === 'mxcvc_y') judgeOpts = { colors: ['black'], category: 'top', catKey: 'cvc' };
      else if (mode === 'mxbag_y') judgeOpts = { colors: ['white', 'beige'], category: 'bag', catKey: 'bag' };
      else judgeOpts = { colors: ['black', 'white'], category: 'top', catKey: 'top_t' };
      var ay = await assignYinliuSlots(colors, p, isTyl, imgUrls, judgeOpts, { customUrl: wantCustom ? ctx.customUrl : '' });
      if (ay.aiCalled) aiUsed = true;
      if (isTyl && ay.detail.length) log('  来源判色 ' + ay.detail.length + '→留' + ay.pool.length + '：' + ay.detail.join(' '));
      if (!ay.kept.length) return { status: 'skipped', reason: isTyl ? '来源无匹配颜色带印花图' : '无来源SKU图' };
      validColors = ay.kept;
      // 01号位(模板第1规格)：名称保留模板填的(不判色)，图固定用引流款图链接框的图
      first(validColors).imgUrl = yUrl; first(validColors).imgUrls = [yUrl];
      if (wantCustom) {
        // 引流+定制：槽1=引流(不改名)，槽2(index1)=定制槽(assignYinliuSlots内已定名diseño personalizado/定图)，来源槽从 index2 起 ↔ pool[0..]
        var esCY = [];
        for (var kc = 2; kc < validColors.length; kc++) {
          var pvC = ay.pool[kc - 2];
          esCY.push(pvC ? esSetSlotName(pvC) : '');
        }
        applySlotNames(validColors.slice(2), esCY, mode === 'mxbag_y');
        log('  引流+定制分配：01引流款 + 02定制(' + CUSTOM_SKU_NAME + ') + 来源图' + ay.pool.length + '张 → 保留' + validColors.length + '个规格，其余空槽删除');
      } else {
        // 判色后把来源SKU规格名改为判出的西语颜色名（01盲盒不改名，名称保留模板）；帆布袋同色多张 Blanco1/Blanco2 递增
        var esAllY = [];
        for (var kiN = 1; kiN < validColors.length; kiN++) {
          var pvN = ay.pool[kiN - 1];
          esAllY.push(pvN ? esSetSlotName(pvN) : '');
        }
        applySlotNames(validColors.slice(1), esAllY, mode === 'mxbag_y');
        log('  引流分配：01引流款 + 来源图' + ay.pool.length + '张 → 保留' + validColors.length + '个规格，其余空槽删除');
      }
    } else {
      // ===== 普通帆布画 normal（原逻辑保持不变）=====
      if (withImg.length) {
        // 妙手字段有图：过滤混入的产品主图
        var productKeys = {};
        imgUrls.forEach(function (u) { var b = getImgBase(u); if (b.length > 5) productKeys[b] = 1; });
        validColors = withImg.filter(function (c) { return !productKeys[getImgBase(c.imgUrl)]; });
        if (!validColors.length) validColors = withImg.slice();
      } else if (p.item.dataPath) {
        // 妙手无图：从 OSS ORIGIN 按ID/同位置补图（不压缩、不借位），再保留有图颜色
        var oss = await fetchOssJson(p.item.dataPath);
        fillColorsImgFromOss(colors, oss);
        validColors = colors.filter(function (c) { return c && c.imgUrl; });
        if (!validColors.length) return { status: 'skipped', reason: '无SKU图' };
      } else {
        return { status: 'skipped', reason: '无SKU图' };
      }
      if (!validColors.length) return { status: 'skipped', reason: '过滤后无有效SKU图' };
    }

    // 全品类通用兜底：最终保留规格前剔除采集名命中黑名单的槽(joya/joyas 珠宝等)。
    // 服装/帆布袋多在判色名称层已滤；此处覆盖油画普通分支(只按有无图筛)及任何模板漏网槽，保证所有品类生效。
    var commonBlockBefore = validColors.length;
    validColors = validColors.filter(function (c) {
      if (!c) return false;
      if (isPluginReservedSlotName(c.attrValue)) return true; // 插件自建固定槽(如定制名)豁免
      return !(c.attrValue && COMMON_SKU_NAME_BLOCK_RE.test(c.attrValue));
    });
    if (validColors.length < commonBlockBefore) log('  通用名称过滤(joyas等无关SKU)：剔除 ' + (commonBlockBefore - validColors.length) + ' 个规格');
    if (!validColors.length) return { status: 'skipped', reason: 'joyas等无关SKU名称过滤后无有效规格' };

    // V26.11.20.8：自动克隆/补出的新颜色槽同步补全 skuMap「颜色×尺码」SKU 行，否则保存报“SKU【…-尺码】不存在”
    var yjFirstId = (isY && colors[0] && colors[0].attrValueId != null) ? String(colors[0].attrValueId) : '';
    var skuEnsure = ensureClonedSkus(info.skuMap || {}, {
      colors: colors,
      validColors: validColors,
      sizes: sizes,
      yinliuFirstId: yjFirstId,
      customName: CUSTOM_SKU_NAME
    });
    info.skuMap = skuEnsure.skuMap;
    if (skuEnsure.newSlotCount) {
      if (skuEnsure.droppableIds.length) {
        var dropSkuIds = {};
        skuEnsure.droppableIds.forEach(function (id) { dropSkuIds[id] = 1; });
        var beforeSkuDrop = validColors.length;
        validColors = validColors.filter(function (c) { return !(c && c.isNew && dropSkuIds[String(c.attrValueId)]); });
        log('  ⚠️ 未找到可复制的SKU模板，' + (beforeSkuDrop - validColors.length) + ' 个自动克隆槽不提交（避免“SKU不存在”整款失败），原有规格正常保存', 'warn');
        if (!validColors.length) return { status: 'skipped', reason: '克隆槽缺少SKU模板且无原有规格可保留，整款跳过' };
      }
      var laySku = skuEnsure.layout || {};
      log('  [诊断SKU] 自动克隆槽' + skuEnsure.newSlotCount + '个 → 补skuMap行' + skuEnsure.added + '条，key维度[' + (laySku.order || ('段数' + (laySku.segCount || '?'))) + ']，样本key=' + (skuEnsure.sampleKey || '(无)') + (skuEnsure.droppableIds.length ? '，回退剔除' + skuEnsure.droppableIds.length + '槽' : ''));
    }

    // 标题：T恤(普通/引流)只清洗不加前缀；帆布普通/引流加随机前缀
    info.title = isT ? cleanTshirtTitle(info.title) : fixTitle(info.title);

    // 删除多余规格（三种模式共用同一套已验证逻辑）
    var validIds = {};
    validColors.forEach(function (c) { validIds[c.attrValueId] = 1; });
    first(props).attrValueList = validColors;
    var newSkuMap = {};
    Object.keys(info.skuMap || {}).forEach(function (key) {
      var parts = key.replace(/^;+|;+$/g, '').split(';').filter(Boolean);
      var hit = parts.some(function (x) { return validIds[x]; });
      var sku = info.skuMap[key];
      if (!hit) sku.isDelete = '1';
      newSkuMap[key] = sku;
    });
    info.skuMap = newSkuMap;

    if (!isT) log('颜色' + colors.length + '→有效' + validColors.length + ' 尺寸' + sizes.length);

    // MX模式：SKU图处理完后，保存前补产品主图（用户主图插入在第一张原主图后面）；单主图模式对全品类生效
    if ((isMx || ctx.single === true) && mxImgs && mxImgs.length) {
      var origImgs = (info.imgUrls || []).map(function (u) { return String(u || '').trim(); }).filter(Boolean);
      var userImgs = mxImgs.map(function (u) { return String(u || '').trim(); }).filter(Boolean);
      var seenMx = {}, mergedMx = [];
      // 第一张原主图
      if (origImgs.length) { seenMx[origImgs[0]] = 1; mergedMx.push(origImgs[0]); }
      // 用户输入的主图（插入在第一张后面）
      userImgs.forEach(function (u) { if (!seenMx[u]) { seenMx[u] = 1; mergedMx.push(u); } });
      // 剩余原主图
      for (var oi = 1; oi < origImgs.length; oi++) { if (!seenMx[origImgs[oi]]) { seenMx[origImgs[oi]] = 1; mergedMx.push(origImgs[oi]); } }
      info.imgUrls = mergedMx;
      log('  ' + (isMx ? 'MX产品主图' : '单主图') + '：用户图' + userImgs.length + '张插入第1张后 → 共' + mergedMx.length + '张');
    }

    log('  [诊断] 保存前 info.imgUrls.length=' + (info.imgUrls || []).length + ' 传ossMd5=' + (detail.ossMd5 || '(空)'));
    log('  [诊断] 保存前 info.imgUrls.length=' + (info.imgUrls || []).length + ' 传ossMd5=' + (detail.ossMd5 || '(空)'));
    var sr = await apiSave(info, detail.ossMd5 || "", info.site || "");
    if (sr.result === 'fail') return { status: 'fail', reason: '保存失败: ' + (sr.reason || '').slice(0, 90) };
    await sleep(300);

    var shopId = p.pubShopId || null;
    var claimIds = detail.claimToShopIds || [];
    if (!shopId && claimIds.length) shopId = String(first(claimIds));
    if (!shopId && p.item.pubShopList && p.item.pubShopList.length) shopId = String(first(p.item.pubShopList).shopId);
    if (!shopId && p.item.collectBoxDetailShopList && p.item.collectBoxDetailShopList.length) shopId = String(first(p.item.collectBoxDetailShopList).shopId);
    if (!shopId && info.shopId) shopId = String(info.shopId);
    if (!shopId && ctx.targetShopId) shopId = String(ctx.targetShopId);
    if (!shopId) shopId = String(defaultShopId);

    var pubParams = { isVerifyPublishLimit: '0' };
    pubParams['detailIds' + IDX0] = p.did;
    pubParams['shopIds' + IDX0] = shopId;
    var pr = await apiPost(API.publish, pubParams);
    var ps = pr.result, reason = pr.reason || '';
    if (ps === 'success') return { status: 'success', aiUsed: aiUsed };
    if (reason.indexOf('重复') >= 0 || reason.indexOf('已发布') >= 0) return { status: 'skipped', reason: reason.slice(0, 50) };
    return { status: 'fail', reason: '发布失败: ' + reason.slice(0, 80) };
  }


  // ---------------- 主流程 ----------------
  async function onStart() {
    if (running) return;
    if (UPD_FORCE) {
      log('当前版本 ' + PLUGIN_VERSION + ' 已停用：服务端已发布 ' + (UPD_LATEST ? 'V' + UPD_LATEST : '新版本') + '，请双击「更新插件.bat」更新并重启 Chrome 后再用', 'err');
      toast('请先更新插件');
      return;
    }
    if (!LIC_OK) {
      log('未授权或授权已失效：请先在面板顶部「授权」区粘贴授权码并点「激活」，再开始处理（防止插件外传，未授权不允许运行）', 'err');
      toast('请先激活授权');
      return;
    }
    var cats = [];
    catBoxes.forEach(function (c) { if (c.checked) cats.push(c.value); });
    var smode = 'normal';
    smodeRadios.forEach(function (r) { if (r.checked) smode = r.value; });
    var gender = 'unisex';
    genderRadios.forEach(function (r) { if (r.checked) gender = r.value; });
    // 发布店铺：选具体店铺 → 只处理已选该店铺的商品，并发布到该店铺；自动 → 每个商品用其第一个预发布店铺
    if (pubShopSelect && pubShopSelect.options.length <= 1) { await loadPubShopOptions(true); }
    var targetShopId = (pubShopSelect && pubShopSelect.value && pubShopSelect.value !== '__auto__') ? pubShopSelect.value : '';
    var targetShopLabel = '';
    if (targetShopId && pubShopSelect && pubShopSelect.selectedOptions && pubShopSelect.selectedOptions[0]) {
      targetShopLabel = pubShopSelect.selectedOptions[0].textContent || targetShopId;
    }
    // 定制模式(独立勾选，可与引流同时)：必须填有效图片直链才启用，否则本批忽略定制
    var customOn = !!(customChk && customChk.checked);
    var customUrlRaw = (customInput && customInput.value.trim()) || '';
    var customEffective = (customOn && /^https?:\/\/.+\.(png|jpe?g|webp|gif)(\?|$)/i.test(customUrlRaw)) ? customUrlRaw : '';
    if (customOn && !customEffective) log('已勾「定制」但定制图链接为空或不是图片直链 → 本批不启用定制槽', 'warn');
    // 单主图(独立勾选，可与引流/定制同时)：用户只采集到主图、商品没有任何细节图 → 「主图链接」必须填细节图直链，否则不发布
    var singleOn = !!(singleChk && singleChk.checked);
    if (!cats.length) {
      log('请先选择一个品类（油画/T恤/连帽卫衣/圆领卫衣/短裤/T恤短裤套装）', 'warn');
      toast('请先选择品类');
      return;
    }
    var batchSize = parseInt(countInput.value, 10) || 20;

    var yinliuUrl = (yinliuInput && yinliuInput.value.trim()) || '';
    var mxImgs = [];
    // 主图链接：放空不添加任何图片，填了链接才添加
    if (mximgInput) {
      mxImgs = mximgInput.value.split(/\r?\n/)
        .map(function (x) { return x.trim(); })
        .filter(function (x) { return /^https?:\/\//.test(x); });
    }
    // 引流款图：必须是有效图片直链才走引流盲盒；留空或格式不对 → 退回普通模式（序号1用来源图）
    var yinliuEffective = /^https?:\/\/.+\.(png|jpe?g|webp|gif)(\?|$)/i.test(yinliuUrl) ? yinliuUrl : '';
    // 单主图硬门：没有细节图直链就不允许进入发布流程（整批不启动，避免漏填后成批无细节图上架）
    if (singleOn && !mxImgs.length) {
      log('已勾「单主图」但「主图链接」为空或没有有效 http(s) 直链 → 本批不发布（单主图必须填细节图直链）', 'warn');
      toast('单主图必须填细节图链接');
      curText.textContent = '单主图未填细节图链接，已取消';
      return;
    }
    // 开始前以面板最新词库构建标题过滤正则（整框清空则用内置）
    var bRaw = brandBoxInput ? brandBoxInput.value : '';
    var bWords = bRaw.trim() ? bRaw.split(/\r?\n/) : DEFAULT_BRAND_WORDS.slice();
    brandStripRe = buildBrandStripRe(bWords);
    var bCount = bWords.filter(function (w) { return String(w).trim(); }).length;
    var CAT_LABEL = { canvas: '油画', bag: '帆布袋(白/米)', top_t: 'T恤', top_h: '连帽卫衣', top_c: '圆领卫衣', shorts: '短裤', set: 'T恤短裤套装', kids: '童装', cvc: 'T恤CVC' };
    var GEN_LABEL = { unisex: '通用', male: '男款', female: '女款', mixed: '男女混合', boy: '男童', girl: '女童' };
    var catLabelStr = cats.map(function (c) { return CAT_LABEL[c] || c; }).join('+');
    var modeLabel = (smode === 'yinliu' ? '引流' : '普通') + (customEffective ? '+定制' : '') + (singleOn ? '+单主图' : '') + ' / ' + catLabelStr + ' / ' + (GEN_LABEL[gender] || '通用');

    running = true; abortFlag = false;
    btnStart.disabled = true; btnStop.disabled = false;
    statText.textContent = ''; setProgress(0, 1); curText.textContent = '准备中…';
    log('==============================', 'ok');
    log('开始 [' + modeLabel + ']，目标数量 ' + batchSize);
    if (targetShopId) log('发布店铺：' + (targetShopLabel || targetShopId) + '（只处理已选该店铺的商品，发布到该店铺）', 'ok');
    else log('发布店铺：自动（每个商品用它自己的第一个预发布店铺）', 'ok');
    log('标题过滤品牌/违禁词 ' + bCount + ' 个（IP/动漫/名人/乐队/球队联盟名保留不删）');
    log('处理规则：上衣(T恤/卫衣)留黑+白带印花；短裤留黑+灰；套装留黑/白/灰；帆布袋留白+米(含阴阳词，其它颜色词全过滤，采集定制词过滤)；油画按来源SKU图；标题只删尺寸与100%纯棉词', 'ok');
    if (mxImgs.length) log('主图链接：' + mxImgs.length + ' 张将插入第1张原主图后', 'ok');
    if (singleOn) log('单主图模式：已填 ' + mxImgs.length + ' 张细节图直链（插入第1张原主图后），本批允许发布；任一商品缺链接都会被保存前拦下', 'ok');
    if (smode === 'yinliu') {
      if (yinliuEffective) log('引流款图(序号1)：' + yinliuEffective.slice(0, 70), 'ok');
      else log('引流款图留空或格式不对 → 按普通模式处理（序号1直接用来源图）', 'warn');
    }
    if (customEffective) log('定制款图(第2规格·' + CUSTOM_SKU_NAME + ')：' + customEffective.slice(0, 70), 'ok');

    try {
      var so = await apiPost(API.shopOptions, {});
      var allShops = [];
      (so.siteShopOptions || []).forEach(function (site) {
        (site.options || []).forEach(function (o) { allShops.push({ id: o.value, name: o.label || '' }); });
      });
      var defaultShopId = allShops.length ? first(allShops).id : '';
      if (targetShopId) defaultShopId = targetShopId;
      log('默认店铺ID: ' + defaultShopId + (targetShopId ? '（已指定发布店铺）' : ''));

      var owner = await resolveOwnerId();
      log('所属人员: ' + owner.label + (owner.id ? ' (' + owner.id + ')' : ' [不过滤]'));

      curText.textContent = '正在扫描已选店铺商品…';
      var list = await scanProducts(owner.id, batchSize, targetShopId, function (pg, found) {
        curText.textContent = '扫描第 ' + pg + ' 页… 已圈定 ' + found + '/' + batchSize;
      });
      log('已圈定 ' + list.length + ' 个已选店铺商品，开始逐个处理', list.length ? 'ok' : 'warn');
      if (!list.length) {
        statText.textContent = '没有可处理商品';
        curText.textContent = '';
        if (targetShopId) {
          log('在「' + (targetShopLabel || targetShopId) + '」下没有找到未发布商品。', 'warn');
          log('请确认这些商品已「选择店铺」到该预发布店铺，或把「发布店铺」改回自动。', 'warn');
        } else {
          log('没有找到「已选择预发布店铺」的商品。', 'warn');
          log('请先在采集箱勾选商品 → 点上方「选择店铺」认领，再回来运行。', 'warn');
        }
        return;
      }

      var success = 0, failed = 0, skipped = 0;
      var aiUsedSet = {};
      for (var idx = 0; idx < list.length; idx++) {
        if (abortFlag) { log('已停止。', 'warn'); break; }
        var p = list[idx];
        curText.textContent = '[' + (idx + 1) + '/' + list.length + '] 处理中…';
        var headerLine = log('[' + (idx + 1) + '/' + list.length + '] 货源ID：' + getSourceId(p));
        try {
          var r = await processOne(p, { cats: cats, smode: smode, gender: gender, custom: !!customEffective, customUrl: customEffective, single: singleOn, targetShopId: targetShopId }, defaultShopId, yinliuEffective, mxImgs);
          if (r.aiUsed) { var sid = getSourceId(p); if (!aiUsedSet[sid]) { aiUsedSet[sid] = 1; log('  🤖 该货源ID调用了AI判色', 'warn'); } }
          if (r.status === 'success') { success++; log('  ✅ 成功', 'ok'); }
          else if (r.status === 'skipped') { skipped++; log('  ⏭ 跳过' + (r.reason ? '：' + r.reason : ''), 'warn'); }
          else {
            failed++;
            var failLine = log('  ❌ ' + r.reason, 'err');
            if (headerLine) headerLine.classList.add('mskb-fail-item');
            if (failLine) failLine.classList.add('mskb-fail-item');
            refreshFailEmpty();
          }
        } catch (e) {
          failed++;
          var exLine = log('  ❌ 异常: ' + ((e && e.message) || e).toString().slice(0, 120), 'err');
          if (headerLine) headerLine.classList.add('mskb-fail-item');
          if (exLine) exLine.classList.add('mskb-fail-item');
          refreshFailEmpty();
        }
        setProgress(idx + 1, list.length);
        statText.textContent = '成功 ' + success + '  失败 ' + failed + '  跳过 ' + skipped + '  AI ' + Object.keys(aiUsedSet).length;
        await sleep(300);
      }

      setProgress(list.length, list.length);
      curText.textContent = '';
      log('==============================', 'ok');
      log('完成：成功=' + success + ' 失败=' + failed + ' 跳过=' + skipped + ' AI=' + Object.keys(aiUsedSet).length + ' 总计=' + list.length, failed ? 'warn' : 'ok');
      statText.textContent = '✅ 完成 成功' + success + ' 失败' + failed + ' 跳过' + skipped + ' AI ' + Object.keys(aiUsedSet).length;
      toast('处理完成：成功' + success + ' 失败' + failed + ' AI ' + Object.keys(aiUsedSet).length);
    } catch (e) {
      log('运行异常: ' + ((e && e.message) ? e.message : e), 'err');
      statText.textContent = '运行异常，请查看日志';
    } finally {
      running = false;
      btnStart.disabled = false; btnStop.disabled = true;
    }
  }

  // ---------------- 启动 ----------------
  function init() {
    buildPanel();
    log('妙手上架助手 ' + PLUGIN_VERSION + ' 已加载。品类(油画/帆布袋白米/T恤/连帽卫衣/圆领卫衣/短裤/套装/童装/CVC) × 普通/引流/定制/单主图(定制可与引流同时：引流锁第1规格、定制锁第2规格命名diseño personalizado；单主图可与引流/定制同时：只采集主图、无细节图时勾选，必须在主图链接填细节图直链，未填不发布)；帆布袋留白+米带印花，采集定制词与其它颜色词过滤；同图按URL去重，不再误杀接近印花；主图链接对服装与帆布袋生效(单主图模式全品类生效)。', 'ok');
    log('要按员工筛选先点「载入子账号」；默认主账号。');
    log('发布店铺：可在「发布店铺」指定一个预发布店铺，只处理已选该店铺的未发布商品并发布到该店；不选=自动（每个商品用它自己的第一个预发布店铺）。');
    log('授权：内部专用。点「授权」展开→复制本机机器码发给管理员→粘贴授权码激活；未授权/过期/机器码不符时「开始处理」会被拦截。', 'ok');
    log('更新：打开面板会自动向本机更新服务查 version.json，有强制新版时直接弹窗挡住并锁住「开始处理」（每5分钟复查一次）；升级方式=弹窗里点「立即更新（自动完成）」，自动下载覆盖并刷新页面（需本机更新助手在运行，首次由「更新插件.bat」装好）。', 'ok');
    licBoot();
    setTimeout(function () { checkUpdate(true); }, 1200);
    setInterval(function () { checkUpdate(true); }, 5 * 60 * 1000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
