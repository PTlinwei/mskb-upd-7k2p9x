// 妙手上架助手 V26.11.25.32 后台：向更新服务读 version.json，判断是否需要(强制)更新
// 只走公网：不再探测本机/同网段更新服务，直接 ghfast → gh-proxy → jsDelivr → raw。
// 解压安装的版本也能用：不依赖 Chrome 的 update_url 机制。
// 拉不到版本信息时返回 ok:false，前台不拦人（断网/服务没开不会把人锁死）。
// 另：面板点「立即更新（自动完成）」时，由本机更新助手（127.0.0.1:8790）下载并覆盖插件目录，
//     覆盖完把扩展重载一次、并把采集箱页面刷新一次，用户不用再手动开 bat。

var HELPER_PING = 'http://127.0.0.1:8790/ping';
var HELPER_UPDATE = 'http://127.0.0.1:8790/update';

var RAW_BASE = 'https://raw.githubusercontent.com/PTlinwei/mskb-upd-7k2p9x/refs/heads/main/version.json';

// 顺序：ghfast（国内最快）→ gh-proxy → jsDelivr（@main 有缓存放最后）→ raw 直连
var VERSION_SOURCES = [
  'https://ghfast.top/' + RAW_BASE,
  'https://gh-proxy.com/' + RAW_BASE,
  'https://cdn.jsdelivr.net/gh/PTlinwei/mskb-upd-7k2p9x@main/version.json',
  RAW_BASE
];

// 公网镜像给 8 秒；全部走公网，不再有本地短超时分支
var SRC_TIMEOUT = 8000;

var CACHE_MS = 60 * 1000;
var cache = { at: 0, data: null };

function parseVer(v) {
  return String(v || '').replace(/^v/i, '').split(/[.]/).map(function (x) {
    var n = parseInt(x, 10);
    return isNaN(n) ? 0 : n;
  });
}

function cmpVer(a, b) {
  var pa = parseVer(a), pb = parseVer(b);
  var len = Math.max(pa.length, pb.length);
  for (var i = 0; i < len; i++) {
    var x = pa[i] || 0, y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function fetchJson(url, timeoutMs) {
  return new Promise(function (resolve, reject) {
    var ctrl = null, timer = null;
    try {
      ctrl = new AbortController();
      timer = setTimeout(function () { try { ctrl.abort(); } catch (e) { } }, timeoutMs || 6000);
    } catch (e) { }
    var opt = { cache: 'no-store', credentials: 'omit' };
    if (ctrl) opt.signal = ctrl.signal;
    fetch(url, opt).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (j) {
      if (timer) clearTimeout(timer);
      resolve(j);
    }).catch(function (e) {
      if (timer) clearTimeout(timer);
      reject(e);
    });
  });
}

function getCurrentVersion() {
  try { return chrome.runtime.getManifest().version; } catch (e) { return ''; }
}

function checkVersion() {
  var now = Date.now();
  if (cache.data && now - cache.at < CACHE_MS) {
    return Promise.resolve(cache.data);
  }
  var current = getCurrentVersion();
  var i = 0;
  function next() {
    if (i >= VERSION_SOURCES.length) {
      return { ok: false, error: '所有更新地址都打不开', current: current };
    }
    var url = VERSION_SOURCES[i++];
    return fetchJson(url, SRC_TIMEOUT).then(function (j) {
      if (!j || !j.version) throw new Error('version.json 缺少 version 字段');
      var latest = String(j.version).replace(/^v/i, '');
      var outdated = cmpVer(latest, current) > 0;
      var data = {
        ok: true,
        current: current,
        latest: latest,
        outdated: outdated,
        force: (j.force !== false),
        note: j.note || '',
        zip: j.zip || '',
        source: url
      };
      cache = { at: Date.now(), data: data };
      return data;
    }).catch(function () { return next(); });
  }
  return Promise.resolve().then(next);
}

// 扩展被重载后（刚更新完插件文件），把仍然开着的采集箱页面刷新一次，让新版本立即生效
try {
  chrome.storage.local.get('mskbReloadTabs', function (o) {
    if (!o || !o.mskbReloadTabs) return;
    try { chrome.storage.local.remove('mskbReloadTabs'); } catch (e) { }
    setTimeout(function () {
      try {
        chrome.tabs.query({ url: ['*://erp.91miaoshou.com/*'] }, function (tabs) {
          (tabs || []).forEach(function (t) {
            try { chrome.tabs.reload(t.id, { bypassCache: true }); } catch (e) { }
          });
        });
      } catch (e) { }
    }, 500);
  });
} catch (e) { }

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg) return;
  // 面板里点「立即更新（自动完成）」：交给本机更新助手下载并覆盖插件目录
  if (msg.type === 'MSKB_APPLY_UPDATE') {
    fetchJson(HELPER_UPDATE, 120000).then(function (j) {
      if (!j || j.ok !== true) throw new Error((j && j.error) ? j.error : '更新助手返回失败');
      cache = { at: 0, data: null };
      try { sendResponse({ ok: true, version: j.version, count: j.count || 1 }); } catch (e) { }
      try { chrome.storage.local.set({ mskbReloadTabs: true }); } catch (e) { }
      setTimeout(function () { try { chrome.runtime.reload(); } catch (e) { } }, 800);
    }).catch(function (e) {
      var m = String(e && e.message ? e.message : e);
      if (/Failed to fetch|NetworkError|net::ERR/i.test(m)) {
        m = '本机更新助手没在运行：双击一次「一键安装.bat」就会装好（只需一次），之后都能点这里自动更新';
      }
      try { sendResponse({ ok: false, error: m }); } catch (err) { }
    });
    return true; // 异步回复
  }
  if (!msg || msg.type !== 'MSKB_CHECK_UPDATE') return;
  checkVersion().then(function (r) {
    try { sendResponse(r); } catch (e) { }
  }, function (e) {
    try { sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }); } catch (err) { }
  });
  return true; // 异步回复
});
